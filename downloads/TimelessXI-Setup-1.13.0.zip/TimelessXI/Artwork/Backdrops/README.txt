Backgrounds for the character portrait (your own in-game screenshots, UI hidden):
  misareaux.png  - Misareaux Coast, the waterfall
  zitah.png      - The Sanctuary of Zi'Tah
  bibiki.png     - Bibiki Bay
.jpg also works; the launcher crops to fit. Full-size originals are in source\.
