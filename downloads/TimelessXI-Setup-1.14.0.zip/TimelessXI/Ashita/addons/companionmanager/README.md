# companionmanager

An Ashita v4 addon for TimelessXI: call, save and manage your companions from one window.
It works next to **companionview** (`/cv`), which shows the companions' gear and stats.

Open it with `/cm`.

## Tabs

| Tab | What you can do |
|---|---|
| **Party** | See the companions with you: job, sub job, HP and MP, bond. **Fill party**, **Two-hour: all**, **Dismiss all**. Per companion: **Keep**, **2hr**, **Why** (what it's doing and why, and its last decisions, in chat), **Dismiss**. Downed companions show their time left, with **Raise** if your job can cast it. |
| **Call** | Every job by role (Tank, Healer, Support, Damage), each showing *ready*, *in party* or its cooldown counting down. Click a ready job to call one. The tooltip shows its sub job and which kept companion answers. |
| **Kept** | Your kept companions (up to 8, or 10 with slots from the Everglass Shop): bond rank, a bar showing progress within the rank (`20/400 to Veteran`), and where they are (with you, down, cooling down, ready, away on an errand, back). **Call**, **Errand** (pick Log, Mine, Harvest, Excavate, Dig or Crew; they're away an hour), **Collect** what the ones who are back brought, or **Forget**. |
| **Presets** | Your presets (up to 5) with their jobs: **Load**, **Edit**, **Delete**. **Save your party** under a name, or **Build a preset** by clicking up to 5 jobs, without calling them first. |
| **Tactics** | Rules for each job's companions, one job at a time (jobs you've changed are marked `*`): **Interrupts**, **Dispel**, **Weakness** (nuke the element the monster takes the most from), **Sleep adds** (on/off), **Area spells** (auto / never / free), **Caster range** (auto / close / far), **MP kept back** (none to 50%) and **Callouts** (on / quiet). **Defaults** puts a job back. Presets save these too. |
| **Settings** | Engage (Attack / Retail), Treasure Hunter, Nuke mode, Party chat callouts, Warrior / Paladin / Dark Knight roles, a sub job choice for every job, and buttons that print Status, the Fight report, Weapon skills and Gear in chat. |

Buttons that can't do anything right now are faded, and their tooltip says why (in town, party
full, cooling down, in battle...). **Dismiss**, **Forget** and **Delete** ask first: click again
within 3 seconds to confirm.

## Commands

| Command | What it does |
|---|---|
| `/cm` or `/companionmanager` | Show or hide the window |
| `/cm update` | Ask for new data now (same as **Refresh**) |
| `/cm auto [sec]` | Also update every `sec` seconds while the window is open (minimum 10; 0 = off, the default) |
| `/cm party`, `call`, `kept`, `presets`, `tactics`, `settings` | Open the window on that tab |

## How it works

**The buttons don't use chat.** Each button sends its action straight to the server in a packet
(`action.lua`). The companions module catches the packet, runs the action and consumes it, so
nothing is said in chat and no chat command runs. Typed `!companion` commands still work exactly
as before. An action has the same words as the command it stands for (`keep Brokk`, `th on`).

**Answers go to the window.** The server's answers to a button (*Preset "xp" saved...*) show at
the top of the window for 30 seconds, not in chat. Answers that come a few seconds later, like
companions arriving from a preset, follow the same rule for 12 seconds after the button. If the
window is closed by then, they show in chat as ordinary lines. Typing a `!companion` command
sends its answers to chat again at once. The **In chat** buttons in Settings (Status, Fight
report, Weapon skills, Gear) print in chat on purpose, since their answers are long.

**Data.** The window asks for its data when it opens. The server sends fresh data by itself right
after each button. Buttons that swap companions in or out, or call them a few seconds later, get
one more update 8 seconds on. Cooldowns and downed timers count down in the window without
asking again. Actions go out one at a time, half a second apart.

### The action packet

A 0x0B5 packet (the client's chat packet) whose text starts with the marker byte `0x7F` and
`CM|`, followed by the action:

| Action | What the server does |
|---|---|
| `fill` | Same as `!companion` (fill the party) |
| `mdata` | Sends the feed below |
| `data` | Sends companionview's feed |
| `<words>` | Runs `!companion <words>`; answers go to the window (`T` lines), then fresh data |
| `><words>` | Runs it; answers go to chat |
| `-<words>` | Runs it with no answer (companionview's switches) |

The server side is `onManagerAction` in `modules/companions/cpp/companions.cpp` (it ignores players
in jail, like chat commands do) and `CompanionsManagerAction` in `companions_commands.lua`.

### The feed

The server answers with lines like these on the system channel, which the addon reads and hides:

```
CM1|B|0|count=2
CM1|L|0|party=3,partymax=6,keptmax=8,presetmax=5,presetjobs=5,cd=1800,downed=180
CM1|C|0|can=1,battle=0,raise=0,reason=
CM1|M|0|th=1,nuke=0,chat=1,wardps=0,plddps=1,drktank=0,engage=retail
CM1|J|12|cmd=sam,role=DPS,wait=95,sub=1,party=0
CM1|P|1801|name=Brokk,job=7,lv=75,sjob=1,slv=37,hpp=50,mpp=0,kept=2,bond=Trusted
CM1|K|5|name=Ayame,job=12,race=7,points=40,rank=Acquaintance,at=0,next=Comrade,nextat=100,where=wait,wait=95
CM1|R|2|name=xp party,jobs=7.3.10.12
CM1|D|1|name=Zeid,job=1,left=150
CM1|X|4|interrupt=on,dispel=on,weakness=on,sleep=on,aoe=never,range=far,mp=30,talk=on
CM1|Z|0|count=2
CM1|T|0|text=Preset "xp party" saved: PLD WHM BRD SAM.
```

| Record | Holds |
|---|---|
| `B` / `Z` | Start and end of a batch. Nothing is used until `Z`; then the whole batch replaces what was shown. |
| `L` | Party size and limits, cooldown length. |
| `C` | Whether companions can be called here (and why not), whether your party is fighting, whether your job can Raise. |
| `M` | Your modes. |
| `J` | One per job: its command, role, cooldown left, chosen sub job, whether it's in your party. |
| `P` | One per companion in your party. |
| `K` | One per kept companion, by slot: bond points, rank, where the rank starts (`at`), the next rank and its points, and `where`: `party`, `down`, `wait` (job cooling down, `wait` seconds), `ready`, `errand` (away, back in `wait` seconds) or `back` (home with finds to collect). |
| `R` | One per preset, by slot; jobs are job ids joined with `.`. |
| `D` | One per downed companion. |
| `X` | A job's tactics rules, by job id, only for jobs not at the defaults (the rest use `protocol.TACTICS_DEFAULTS`). |

`P` and `K` lines also carry `pe` (the companion's personality, shown in the name's tooltip); `K` carries `kl` (monsters defeated together).
| `T` | Outside batches: one of the server's answers to a button. The text runs to the end of the line. |

A chat line holds at most 150 letters, so every line is kept shorter than that, and a long answer comes in more than one `T` line.

The tag is `CM1`, not companionview's `CV1`, so the two addons never read each other's lines.
The server side is `modules/companions/lua/companions_manage.lua`.

### Server commands added for it

These are also typed commands:

- `!companion mdata`: the feed above.
- `!companion release <name>`: send one companion home (plain `!companion release` still sends them all).
- `!companion define <job,job,...> <name>`: save a preset from a job list without calling the companions first.
- `!companion tactics <job> <rule> <value>` / `reset`: the Tactics tab's buttons.

## Files

| File | Contents |
|---|---|
| `companionmanager.lua` | Events, commands, settings, the send queue, reading the feed |
| `action.lua` | Builds and sends the action packet |
| `protocol.lua` | Reads the feed into a data model; no game or UI code |
| `ui.lua` | The window, one function per tab in `ui.tabs` |
| `tests/addon_test.lua` | Offline checks: the action packet, the feed and messages, and every tab drawn with a fake imgui |

Run the checks from this folder with `luajit tests/addon_test.lua`.

## Adding to it

- **A new tab:** add a function to `ui.tabs` and an entry to `ui.TAB_ORDER`.
- **New data:** add keys or record types on the server. This addon ignores what it doesn't
  know. Change the tag (`CM2`) only for a change older addons would read wrongly.

Ideas for later:

1. **A compact bar:** a small always-on strip with Fill, the presets and Dismiss.
2. **Rename a kept companion.**
3. **Preset order:** move presets up and down, and pick one to load with **Fill party**.
4. **Push updates:** the server sends a fresh batch when a companion joins, leaves or falls, so
   the window never has to ask.
