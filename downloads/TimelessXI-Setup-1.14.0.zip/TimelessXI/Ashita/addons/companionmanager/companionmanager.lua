--[[
* companionmanager - call, save and manage your TimelessXI companions from a window.
*
* Tabs: Party (who's with you, keep, two-hour, dismiss, raise), Call (every job and its cooldown),
* Kept (bond and call), Presets (load, save, build) and Settings (modes, roles, sub jobs).
*
* The buttons don't use chat or chat commands: each sends its action to the server in a packet
* the companions module takes and consumes (action.lua). The server's answers show at the top of
* the window instead of in chat, and it sends the window fresh data after each button. Typed
* !companion commands still work as before.
*
* Commands:
*   /cm                  show or hide the window (/companionmanager also works)
*   /cm update           ask for new data now (the window's Refresh button does the same)
*   /cm auto [sec]       also update every <sec> seconds while the window is open (0 = off, the default)
*   /cm <tab>            open on a tab: party, call, kept, presets, tactics, settings
*
* Works alongside companionview (/cv), which shows the companions' gear and stats.
--]]

addon.name    = 'companionmanager';
addon.author  = 'TimelessXI';
addon.version = '1.1';
addon.desc    = 'Call, save and manage your companions.';
addon.link    = '';

require('common');
local chat     = require('chat');
local settings = require('settings');
local action   = require('action');
local protocol = require('protocol');
local ui       = require('ui');

local defaults = T{
    auto_refresh = 0, -- seconds between automatic updates while open (0 = off)
};

local cm = {
    settings  = settings.load(defaults),
    model     = protocol.new_model(),
    visible   = false, -- always starts closed
    queue     = {},    -- actions waiting to be sent, one at a time
    next_send = 0,
    last_ask  = 0,
    asked_at  = 0,
    update_at = nil,
};

cm.state = {
    armed     = {},
    save_name = { '' },
    build     = { jobs = {}, name = { '' } },
    waiting   = false,
};

-- Seconds between actions the addon sends, so a busy click never floods the server
local SEND_GAP = 0.5;

local function msg(text)
    print(chat.header(addon.name):append(chat.message(text)));
end

local function in_game()
    local party = AshitaCore:GetMemoryManager():GetParty();
    return party ~= nil and party:GetMemberServerId(0) ~= 0;
end

local function ask()
    if (not in_game()) then
        return;
    end
    cm.last_ask = os.clock();
    cm.asked_at = os.time();
    cm.state.waiting = true;
    action.send('mdata');
end

-- Buttons call this with the !companion command they stand for. in_chat: the server answers in
-- chat (the "In chat" buttons); otherwise in this window, followed by fresh data.
cm.state.send = function(cmd, delay, in_chat)
    table.insert(cm.queue, { text = action.from_command(cmd, in_chat and '>' or ''), delay = delay or 0 });
end

settings.register('settings', 'settings_update', function(s)
    if (s ~= nil) then
        cm.settings = s;
    end
end);

ashita.events.register('unload', 'unload_cb', function()
    settings.save();
end);

-- Read the feed and hide it. The server's answers to the buttons go to the window while it is
-- open; when it is closed they show in chat as ordinary lines.
ashita.events.register('text_in', 'text_in_cb', function(e)
    local line = protocol.extract(e.message_modified) or protocol.extract(e.message);
    if (line == nil) then
        return;
    end

    local text = protocol.message_text(line);
    if (text ~= nil and not cm.visible) then
        e.message_modified = text;
        return;
    end

    e.blocked = true;
    if (protocol.feed(cm.model, line, os.time())) then
        cm.state.waiting = false;
        cm.state.updated_text = 'Updated ' .. os.date('%I:%M:%S %p');
    end
end);

local TABS = { party = true, call = true, kept = true, presets = true, tactics = true, settings = true };

ashita.events.register('command', 'command_cb', function(e)
    local args = e.command:args();
    if (#args == 0 or not (args[1]:any('/cm') or args[1]:any('/companionmanager'))) then
        return;
    end
    e.blocked = true;

    local sub = (args[2] or ''):lower();
    if (sub == '') then
        cm.visible = not cm.visible;
        if (cm.visible) then
            ask();
        end
    elseif (sub == 'update' or sub == 'refresh') then
        ask();
    elseif (sub == 'auto') then
        local n = tonumber(args[3]);
        if (n ~= nil) then
            -- At most every 10 seconds, so it never floods the server
            cm.settings.auto_refresh = (n <= 0) and 0 or math.max(10, n);
            settings.save();
        end
        msg(cm.settings.auto_refresh > 0 and ('Updates every %d seconds while the window is open.'):fmt(cm.settings.auto_refresh) or 'Automatic updates are off. Use Refresh or /cm update.');
    elseif (TABS[sub]) then
        cm.state.open_tab = sub;
        if (not cm.visible) then
            cm.visible = true;
            ask();
        end
    else
        msg('/cm | /cm update | /cm auto [sec] | /cm party|call|kept|presets|settings');
    end
end);

ashita.events.register('d3d_present', 'present_cb', function()
    if (not in_game()) then
        return;
    end

    local now = os.clock();

    -- Send queued actions one at a time (this keeps working if the window is closed meanwhile)
    if (#cm.queue > 0 and now >= cm.next_send) then
        local item = table.remove(cm.queue, 1);
        action.send(item.text);
        cm.next_send = now + SEND_GAP;
        if (item.delay > 0) then
            -- The server sends fresh data at once; actions that finish later get one more ask
            cm.update_at = math.max(cm.update_at or 0, now + item.delay);
        end
    end

    if (not cm.visible) then
        return;
    end

    if (cm.update_at ~= nil and now >= cm.update_at and #cm.queue == 0) then
        cm.update_at = nil;
        cm.state.update_requested = true;
    end

    if (cm.state.update_requested) then
        cm.state.update_requested = false;
        if (not cm.state.waiting) then
            ask();
        end
    elseif (cm.settings.auto_refresh > 0 and now - cm.last_ask >= cm.settings.auto_refresh) then
        ask();
    end

    -- No answer (e.g. a server without the companions module): stop showing "Updating..."
    if (cm.state.waiting and os.time() - cm.asked_at > 5) then
        cm.state.waiting = false;
    end

    if (not ui.render(cm.model, cm.state)) then
        cm.visible = false;
    end
end);
