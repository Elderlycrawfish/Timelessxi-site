--[[
* theme.lua - the shared look of the TimelessXI addons (timelessmenu, craftbook, companionmanager,
* companionview). Each addon carries its own identical copy, the same way icons.lua is shared,
* so an addon never depends on another one being installed.
*
*   theme.begin_window(title, open, size, flags)   style + window + text size; then theme.end_window()
*   theme.section(text, note)                      a gold heading with a rule under it
*   theme.subheading(text)                         a smaller heading inside a section
*   theme.button(label, kind, enabled, hint)       kind: nil, 'primary' (gold) or 'danger' (red)
*   theme.card(id, draw, width)                    a soft panel around draw(), as tall as its contents
*   theme.colors(extra)                            the palette, plus an addon's own colours
*   theme.progress(frac, color, width, text)       a progress bar that fits its text
*   theme.col(x)                                   same line at column x, never overlapping the item before
*
* Change the look in one place: the palette, spacing and text size below (then copy this file to
* the other addons).
--]]

local imgui = require('imgui');

local theme = {};

-- Text size for the whole window, panels included (1.0 = Ashita's default)
theme.FONT_SCALE = 1.1;

-- Palette: soft slate panels, warm gold accents, bright readable text
theme.COLOR = {
    gold   = { 0.97, 0.81, 0.45, 1.00 }, -- headings, highlights
    text   = { 0.95, 0.96, 0.98, 1.00 },
    dim    = { 0.72, 0.75, 0.82, 1.00 }, -- secondary text (brighter than before, easier to read)
    faint  = { 0.56, 0.59, 0.67, 0.95 },
    good   = { 0.50, 0.90, 0.60, 1.00 },
    bad    = { 0.98, 0.48, 0.48, 1.00 },
    warn   = { 0.99, 0.74, 0.38, 1.00 },
    info   = { 0.55, 0.80, 1.00, 1.00 },
    bond   = { 0.82, 0.67, 1.00, 1.00 },
    hp     = { 0.88, 0.38, 0.40, 1.00 },
    mp     = { 0.40, 0.62, 0.98, 1.00 },
    tp     = { 0.92, 0.78, 0.32, 1.00 },
};

local BG = {
    window = { 0.075, 0.082, 0.110, 0.97 },
    panel  = { 0.115, 0.125, 0.165, 1.00 },
    card   = { 0.135, 0.145, 0.190, 0.95 },
    frame  = { 0.160, 0.172, 0.225, 1.00 },
    hover  = { 0.215, 0.230, 0.300, 1.00 },
    active = { 0.270, 0.285, 0.365, 1.00 },
    border = { 0.300, 0.320, 0.410, 0.55 },
    accent = { 0.330, 0.270, 0.140, 1.00 }, -- dark gold
    accent_hover = { 0.470, 0.380, 0.180, 1.00 },
    accent_active = { 0.580, 0.460, 0.200, 1.00 },
};

local function v(name)
    return rawget(_G, name);
end

-- Style variables: roomier spacing and rounded corners
local function style_vars()
    return {
        { v('ImGuiStyleVar_WindowPadding'),    { 14, 12 } },
        { v('ImGuiStyleVar_FramePadding'),     { 9, 5 } },
        { v('ImGuiStyleVar_ItemSpacing'),      { 9, 7 } },
        { v('ImGuiStyleVar_ItemInnerSpacing'), { 6, 5 } },
        { v('ImGuiStyleVar_WindowRounding'),   8.0 },
        { v('ImGuiStyleVar_ChildRounding'),    6.0 },
        { v('ImGuiStyleVar_FrameRounding'),    5.0 },
        { v('ImGuiStyleVar_PopupRounding'),    6.0 },
        { v('ImGuiStyleVar_GrabRounding'),     4.0 },
        { v('ImGuiStyleVar_TabRounding'),      5.0 },
        { v('ImGuiStyleVar_ScrollbarSize'),    12.0 },
        { v('ImGuiStyleVar_WindowTitleAlign'), { 0.03, 0.5 } },
    };
end

local function style_colors()
    local c = theme.COLOR;
    return {
        { v('ImGuiCol_Text'),                 c.text },
        { v('ImGuiCol_TextDisabled'),         c.faint },
        { v('ImGuiCol_WindowBg'),             BG.window },
        { v('ImGuiCol_ChildBg'),              { 0, 0, 0, 0 } },
        { v('ImGuiCol_PopupBg'),              { 0.100, 0.108, 0.145, 0.98 } },
        { v('ImGuiCol_Border'),               BG.border },
        { v('ImGuiCol_FrameBg'),              BG.frame },
        { v('ImGuiCol_FrameBgHovered'),       BG.hover },
        { v('ImGuiCol_FrameBgActive'),        BG.active },
        { v('ImGuiCol_TitleBg'),              { 0.095, 0.100, 0.135, 1.0 } },
        { v('ImGuiCol_TitleBgActive'),        { 0.190, 0.160, 0.095, 1.0 } },
        { v('ImGuiCol_TitleBgCollapsed'),     { 0.095, 0.100, 0.135, 0.9 } },
        { v('ImGuiCol_ScrollbarBg'),          { 0.06, 0.065, 0.09, 0.6 } },
        { v('ImGuiCol_ScrollbarGrab'),        BG.hover },
        { v('ImGuiCol_ScrollbarGrabHovered'), BG.active },
        { v('ImGuiCol_ScrollbarGrabActive'),  BG.accent_hover },
        { v('ImGuiCol_CheckMark'),            c.gold },
        { v('ImGuiCol_SliderGrab'),           c.gold },
        { v('ImGuiCol_Button'),               BG.frame },
        { v('ImGuiCol_ButtonHovered'),        BG.accent_hover },
        { v('ImGuiCol_ButtonActive'),         BG.accent_active },
        { v('ImGuiCol_Header'),               BG.hover },
        { v('ImGuiCol_HeaderHovered'),        BG.accent },
        { v('ImGuiCol_HeaderActive'),         BG.accent_hover },
        { v('ImGuiCol_Separator'),            BG.border },
        { v('ImGuiCol_Tab'),                  BG.panel },
        { v('ImGuiCol_TabHovered'),           BG.accent_hover },
        { v('ImGuiCol_TabSelected') or v('ImGuiCol_TabActive'), BG.accent },
        { v('ImGuiCol_TabSelectedOverline'),  c.gold },
        { v('ImGuiCol_PlotHistogram'),        c.gold },
    };
end

-- Pushes the whole look; returns how many of each were pushed (for theme.pop)
function theme.push()
    local nv, nc = 0, 0;
    for _, entry in ipairs(style_vars()) do
        if (entry[1] ~= nil) then
            imgui.PushStyleVar(entry[1], entry[2]);
            nv = nv + 1;
        end
    end
    for _, entry in ipairs(style_colors()) do
        if (entry[1] ~= nil) then
            imgui.PushStyleColor(entry[1], entry[2]);
            nc = nc + 1;
        end
    end
    return { vars = nv, colors = nc };
end

function theme.pop(pushed)
    if (pushed == nil) then
        return;
    end
    if (pushed.colors > 0) then
        imgui.PopStyleColor(pushed.colors);
    end
    if (pushed.vars > 0) then
        imgui.PopStyleVar(pushed.vars);
    end
end

local window_stack = {};

--[[
* A themed window. Always call theme.end_window() afterwards, whatever this returns.
--]]
function theme.begin_window(title, open, size, flags)
    if (size ~= nil) then
        imgui.SetNextWindowSize(size, v('ImGuiCond_FirstUseEver'));
    end
    table.insert(window_stack, theme.push());
    local shown = imgui.Begin(title, open, flags or v('ImGuiWindowFlags_NoCollapse') or 0);
    if (shown) then
        -- In this imgui (1.92) the window's text size also applies to every panel inside it
        pcall(function() imgui.SetWindowFontScale(theme.FONT_SCALE); end);
    end
    return shown;
end

function theme.end_window()
    imgui.End();
    theme.pop(table.remove(window_stack));
end

-- A gold heading with a rule under it, and an optional dim note beside it
function theme.section(text, note)
    imgui.Spacing();
    imgui.TextColored(theme.COLOR.gold, text);
    if (note ~= nil and note ~= '') then
        imgui.SameLine();
        imgui.TextColored(theme.COLOR.faint, note);
    end
    imgui.Separator();
    imgui.Spacing();
end

function theme.subheading(text)
    imgui.Spacing();
    imgui.TextColored(theme.COLOR.dim, text);
end

local function tip(text)
    if (text ~= nil and text ~= '' and imgui.IsItemHovered()) then
        if (imgui.BeginTooltip() ~= false) then
            imgui.TextUnformatted(tostring(text));
            imgui.EndTooltip();
        end
    end
end
theme.tip = tip;

--[[
* A button. kind: nil (normal), 'primary' (gold, the main thing to press) or 'danger' (red).
* enabled == false fades it and it can't be pressed (the hint says why).
--]]
function theme.button(label, kind, enabled, hint)
    local colors = 0;
    if (kind == 'primary') then
        imgui.PushStyleColor(v('ImGuiCol_Button'), BG.accent);
        imgui.PushStyleColor(v('ImGuiCol_ButtonHovered'), BG.accent_hover);
        imgui.PushStyleColor(v('ImGuiCol_ButtonActive'), BG.accent_active);
        colors = 3;
    elseif (kind == 'danger') then
        imgui.PushStyleColor(v('ImGuiCol_Button'), { 0.36, 0.14, 0.15, 1.0 });
        imgui.PushStyleColor(v('ImGuiCol_ButtonHovered'), { 0.52, 0.19, 0.20, 1.0 });
        imgui.PushStyleColor(v('ImGuiCol_ButtonActive'), { 0.64, 0.23, 0.24, 1.0 });
        colors = 3;
    end
    if (enabled == false) then
        imgui.PushStyleVar(v('ImGuiStyleVar_Alpha'), 0.40);
    end
    local clicked = imgui.Button(label);
    if (enabled == false) then
        imgui.PopStyleVar(1);
    end
    if (colors > 0) then
        imgui.PopStyleColor(colors);
    end
    tip(hint);
    return clicked and enabled ~= false;
end

--[[
* A soft panel around draw(), as tall as what's inside. Errors in draw() are caught so the panel
* always closes (an open panel would stop the game on the next frame).
--]]
function theme.card(id, draw, width)
    imgui.PushStyleColor(v('ImGuiCol_ChildBg'), BG.card);
    imgui.PushStyleVar(v('ImGuiStyleVar_WindowPadding'), { 12, 10 });
    local flags = bit.bor(v('ImGuiChildFlags_Borders') or 1, v('ImGuiChildFlags_AutoResizeY') or 0);
    imgui.BeginChild(id, { width or 0, 0 }, flags);
    imgui.PopStyleVar(1);
    imgui.PopStyleColor(1);
    local ok, err = pcall(draw);
    imgui.EndChild();
    if (not ok) then
        print('[theme] ' .. tostring(err));
    end
end

--[[
* Columns that grow with the text. theme.col(x) puts the next item on the same line at column x
* (x is in unscaled pixels and grows with theme.FONT_SCALE), or right after the previous item when
* that one is wider, so a long name or label never runs into the next column. Use it instead of
* imgui.SameLine(x).
--]]
local COL_GAP = 8;

function theme.col(x)
    imgui.SameLine(0, 0);
    local finish = imgui.GetCursorPosX(); -- where the previous item ends
    imgui.SameLine(math.floor(x * theme.FONT_SCALE + 0.5));
    local at = imgui.GetCursorPosX();
    if (type(finish) == 'number' and type(at) == 'number' and finish + COL_GAP > at) then
        imgui.SameLine(0, COL_GAP); -- the previous item reaches the column: just after it
    end
end

--[[
* A progress bar: rounded track, the fill with a soft highlight, and its text centred with a
* shadow. width is the least width (unscaled pixels, grows with the text size); the bar widens to
* fit its text, so the label never spills out. As tall as a line of text plus a little room, and
* centred on that line. Returns true while it's hovered (for a tooltip, theme.tip works too).
--]]
local BAR = {
    track  = { 0.055, 0.062, 0.085, 1.00 },
    edge   = { 0.300, 0.320, 0.410, 0.70 },
    shadow = { 0.00, 0.00, 0.00, 0.85 },
    text   = { 1.00, 1.00, 1.00, 1.00 },
};

local function u32(c)
    return imgui.GetColorU32(c);
end

local function shade(c, f, a)
    return { math.min(1, c[1] * f), math.min(1, c[2] * f), math.min(1, c[3] * f), a or c[4] or 1 };
end

local function corners(which)
    if (which == 'top') then
        return v('ImDrawFlags_RoundCornersTop') or v('ImDrawCornerFlags_Top') or 0;
    end
    return v('ImDrawFlags_RoundCornersAll') or v('ImDrawCornerFlags_All') or 0;
end

function theme.progress(frac, color, width, text)
    frac  = math.max(0, math.min(tonumber(frac) or 0, 1));
    color = color or theme.COLOR.gold;
    text  = text or '';

    local lineH = imgui.GetTextLineHeight();
    local tw    = (text ~= '') and imgui.CalcTextSize(text) or 0;
    local x, y  = imgui.GetCursorScreenPos();
    local draw  = imgui.GetWindowDrawList();
    if (type(lineH) ~= 'number' or type(tw) ~= 'number' or type(x) ~= 'number' or type(y) ~= 'number' or not draw) then
        -- No drawing here (an old imgui, or the add-on tests' fake one): the plain bar
        imgui.PushStyleColor(v('ImGuiCol_PlotHistogram'), color);
        imgui.ProgressBar(frac, { width or 120, 13 }, text);
        imgui.PopStyleColor(1);
        return imgui.IsItemHovered() == true;
    end

    local w = math.floor(math.max((width or 120) * theme.FONT_SCALE, tw + 18) + 0.5);
    local h = math.floor(lineH + 5);
    -- Centred on the line of text it sits in (labels before and after it line up with its text)
    local top = math.floor(y - (h - lineH) / 2);

    imgui.Dummy({ w, lineH });
    local hovered = imgui.IsItemHovered() == true;
    local r = math.min(5, h / 2);

    -- Track
    draw:AddRectFilled({ x, top }, { x + w, top + h }, u32(BAR.track), r, corners());

    -- Fill, and a lighter top half for a little depth
    if (frac > 0) then
        local fw = math.max(r * 2, w * frac);
        local full = frac >= 1;
        draw:AddRectFilled({ x, top }, { x + fw, top + h }, u32(shade(color, full and 0.95 or 0.80)), r, corners());
        draw:AddRectFilled({ x + 1, top + 1 }, { x + fw - 1, top + h / 2 }, u32({ 1, 1, 1, hovered and 0.20 or 0.13 }), r - 1, corners('top'));
    end

    -- Edge: the bar's colour when it's full, the usual frame colour otherwise
    draw:AddRect({ x, top }, { x + w, top + h }, u32(frac >= 1 and shade(color, 1.15, 0.95) or BAR.edge), r, corners(), 1.0);

    -- Text, centred, with a shadow so it reads on any fill
    if (text ~= '') then
        local tx = math.floor(x + (w - tw) / 2);
        local ty = math.floor(top + (h - lineH) / 2);
        draw:AddText({ tx + 1, ty + 1 }, u32(BAR.shadow), text);
        draw:AddText({ tx, ty }, u32(BAR.text), text);
    end

    return hovered;
end

-- The palette plus an addon's own colours (its keys win)
function theme.colors(extra)
    local out = {};
    for k, c in pairs(theme.COLOR) do
        out[k] = c;
    end
    for k, c in pairs(extra or {}) do
        out[k] = c;
    end
    return out;
end

return theme;
