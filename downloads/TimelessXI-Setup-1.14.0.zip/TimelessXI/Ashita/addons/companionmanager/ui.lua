--[[
* companionmanager - ui.lua
*
* The window, one tab per part:
*   Party     the companions with you: bars, bond, keep, two-hour, why, dismiss; downed companions
*   Call      every job: ready or its cooldown, click to call one
*   Kept      the companions you keep: bond rank and progress, call, forget
*   Presets   load, delete, save your party, or build a preset from jobs
*   Tactics   rules for each job's companions: interrupts, dispel, weakness, sleep, area spells,
*             range, MP kept back, callouts (saved with presets)
*   Settings  modes, roles, engage, sub jobs, chat
*
* Nothing here talks to the game: buttons call state.send(command, refresh_delay, in_chat), which
* companionmanager.lua sends to the server as an action packet (action.lua), not as chat. The
* server's answers show at the top of the window (model.messages). Each tab is its own function
* in ui.tabs, drawn in the order of ui.TAB_ORDER, so tabs can be added without touching the others.
--]]

require('common');
local imgui    = require('imgui');
local theme    = require('theme');
local protocol = require('protocol');

local ui = {};

local JOBS = {
    [1] = { 'WAR', 'Warrior' },     [2] = { 'MNK', 'Monk' },          [3] = { 'WHM', 'White Mage' },
    [4] = { 'BLM', 'Black Mage' },  [5] = { 'RDM', 'Red Mage' },      [6] = { 'THF', 'Thief' },
    [7] = { 'PLD', 'Paladin' },     [8] = { 'DRK', 'Dark Knight' },   [9] = { 'BST', 'Beastmaster' },
    [10] = { 'BRD', 'Bard' },       [11] = { 'RNG', 'Ranger' },       [12] = { 'SAM', 'Samurai' },
    [13] = { 'NIN', 'Ninja' },      [14] = { 'DRG', 'Dragoon' },      [15] = { 'SMN', 'Summoner' },
    [16] = { 'BLU', 'Blue Mage' },  [17] = { 'COR', 'Corsair' },      [18] = { 'PUP', 'Puppetmaster' },
    [19] = { 'DNC', 'Dancer' },     [20] = { 'SCH', 'Scholar' },      [21] = { 'GEO', 'Geomancer' },
    [22] = { 'RUN', 'Rune Fencer' },
};

-- Colours: the shared TimelessXI palette (theme.lua)
local COLOR = theme.colors();

ui.ROLES = {
    { key = 'TANK',    label = 'Tank',    color = { 0.40, 0.65, 1.00, 1.0 } },
    { key = 'HEALER',  label = 'Healer',  color = { 0.45, 0.90, 0.55, 1.0 } },
    { key = 'SUPPORT', label = 'Support', color = { 0.80, 0.55, 1.00, 1.0 } },
    { key = 'DPS',     label = 'Damage',  color = { 1.00, 0.50, 0.40, 1.0 } },
};

local ROLE_BY_KEY = {};
for _, r in ipairs(ui.ROLES) do
    ROLE_BY_KEY[r.key] = r;
end

-- The server sends fresh data right after each button. Commands that swap companions out and back
-- in (or call them a few seconds later) finish later: ask again after SLOW seconds.
ui.SLOW = 8;
ui.FAST = 0;
ui.MESSAGE_SECONDS = 30; -- how long the server's answers stay at the top of the window

function ui.job_short(id) return (JOBS[id] or { '---' })[1]; end
function ui.job_long(id)  return (JOBS[id] or { nil, 'None' })[2]; end

function ui.role_of(model, jobId)
    local job = model.jobs[jobId];
    return ROLE_BY_KEY[job and job.role or 'DPS'] or ROLE_BY_KEY.DPS;
end

local function lower(s)
    return string.lower(s or '');
end

--[[
* Small widgets
--]]

-- Newer imgui (Ashita 4.3+) takes child flags as a number; older versions take a border boolean
local function begin_child(id, size, border)
    local flag = ImGuiChildFlags_Borders or ImGuiChildFlags_Border;
    if (flag ~= nil) then
        return imgui.BeginChild(id, size, border and flag or 0);
    end
    return imgui.BeginChild(id, size, border);
end

local function tip(text)
    if (text ~= nil and text ~= '' and imgui.IsItemHovered()) then
        if (imgui.BeginTooltip() ~= false) then
            imgui.TextUnformatted(tostring(text));
            imgui.EndTooltip();
        end
    end
end

-- A button that can be off: drawn faded, never clicks. Returns true when clicked.
local function button(label, enabled, hint, size)
    if (enabled == false) then
        imgui.PushStyleVar(ImGuiStyleVar_Alpha, 0.40);
    end
    local clicked = imgui.Button(label, size or { 0, 0 });
    if (enabled == false) then
        imgui.PopStyleVar(1);
    end
    tip(hint);
    return clicked and enabled ~= false;
end

-- One of a pair of switch buttons: lit when active; clicking the lit one does nothing
local function choice(label, active, hint, enabled)
    if (active) then
        imgui.PushStyleColor(ImGuiCol_Button, { 0.55, 0.42, 0.15, 1.0 });
        imgui.PushStyleColor(ImGuiCol_ButtonHovered, { 0.62, 0.48, 0.18, 1.0 });
        imgui.PushStyleColor(ImGuiCol_Text, { 1.0, 0.95, 0.80, 1.0 });
    else
        imgui.PushStyleColor(ImGuiCol_Button, { 0.12, 0.13, 0.18, 1.0 });
        imgui.PushStyleColor(ImGuiCol_ButtonHovered, { 0.20, 0.21, 0.28, 1.0 });
        imgui.PushStyleColor(ImGuiCol_Text, COLOR.dim);
    end
    local clicked = button(label, enabled, hint);
    imgui.PopStyleColor(3);
    return clicked and not active;
end

-- A button that asks again before it acts: the first click arms it for 3 seconds
local function confirm_button(state, key, label, hint, enabled)
    local armed = state.armed[key] ~= nil and os.clock() < state.armed[key];
    if (armed) then
        imgui.PushStyleColor(ImGuiCol_Button, { 0.60, 0.18, 0.18, 1.0 });
        imgui.PushStyleColor(ImGuiCol_ButtonHovered, { 0.72, 0.22, 0.22, 1.0 });
    end
    local clicked = button(armed and ('Sure?##' .. key) or (label .. '##' .. key), enabled, armed and 'Click again to confirm.' or hint);
    if (armed) then
        imgui.PopStyleColor(2);
    end

    if (clicked) then
        if (armed) then
            state.armed[key] = nil;
            return true;
        end
        state.armed[key] = os.clock() + 3;
    end
    return false;
end

local function bar(frac, color, width, text)
    theme.progress(frac, color, width, text); -- the shared bar (theme.lua): fits its text
end

local function heading(text, note)
    theme.section(text, note);
end

-- Party slots left, and whether companions can be called at all (and why not)
local function call_state(model)
    local L = model.limits;
    local free = (L.partymax or 6) - (L.party or 1);
    if (L.can == false) then
        return false, L.reason ~= '' and L.reason or 'Companions can\'t be called here.', free;
    end
    if (free <= 0) then
        return false, 'Your party is full.', free;
    end
    return true, nil, free;
end

ui.tabs = {};

--[[
* Party
--]]
function ui.tabs.party(model, state)
    local L = model.limits;
    local can, why, free = call_state(model);

    imgui.TextColored(COLOR.text, ('Party %d/%d'):fmt(L.party or 1, L.partymax or 6));
    if (L.battle) then
        imgui.SameLine();
        imgui.TextColored(COLOR.warn, '  In battle');
        tip('Role, gear and sub job changes wait until the fight is over.');
    end

    if (button('Fill party', can, can and ('Call companions for the %d open slots: tank, healer, support, then damage.'):fmt(free) or why)) then
        state.send('!companion', ui.SLOW);
    end
    imgui.SameLine();
    if (button('Two-hour: all', #model.party > 0, 'Every companion uses its two-hour ability now.')) then
        state.send('!companion 2hr all', ui.FAST);
    end
    imgui.SameLine();
    if (confirm_button(state, 'release_all', 'Dismiss all', 'Send all your companions home (regular Trusts stay).', #model.party > 0)) then
        state.send('!companion release', ui.SLOW);
    end
    if (not can and why ~= nil and free > 0) then
        imgui.TextColored(COLOR.bad, why);
    end

    imgui.Spacing();
    heading('With you');
    if (#model.party == 0) then
        imgui.TextColored(COLOR.dim, 'No companions in your party. Use Fill party, the Call tab, a preset or a kept companion.');
    end

    for _, c in ipairs(model.party) do
        local role = ui.role_of(model, c.job);
        imgui.PushID('party' .. c.id);

        imgui.TextColored(role.color, c.name);
        tip(('%s (%s)%s'):fmt(ui.job_long(c.job), role.label, (c.pe or '') ~= '' and ('\nPersonality: ' .. c.pe) or ''));
        theme.col(110);
        local sub = (c.sjob or 0) ~= 0 and ('/%s%d'):fmt(ui.job_short(c.sjob), c.slv) or '';
        imgui.TextColored(COLOR.dim, ('%s%d%s'):fmt(ui.job_short(c.job), c.lv, sub));

        theme.col(200);
        bar((c.hpp or 0) / 100, COLOR.hp, 70, ('%d%%'):fmt(c.hpp or 0));
        imgui.SameLine();
        if ((c.mpp or 0) > 0 or (c.job and ({ [3] = 1, [4] = 1, [5] = 1, [7] = 1, [8] = 1, [10] = 1, [15] = 1, [16] = 1, [20] = 1 })[c.job])) then
            bar((c.mpp or 0) / 100, COLOR.mp, 50, ('%d%%'):fmt(c.mpp or 0));
        else
            imgui.Dummy({ 50, 13 });
        end

        theme.col(340);
        if ((c.kept or 0) > 0) then
            imgui.TextColored(COLOR.bond, c.bond ~= '' and c.bond or 'Kept');
            tip('A companion you keep. Their bond grows with every monster you defeat together (Kept tab).');
        else
            local full = ui.kept_count(model) >= (L.keptmax or 8);
            if (button('Keep', not full, full and 'You keep as many companions as you can. Forget one first (Kept tab).' or
                ('Keep %s: they answer every call for a %s from now on and earn bond.'):fmt(c.name, ui.job_long(c.job)))) then
                state.send('!companion keep ' .. c.name, ui.FAST);
            end
        end

        theme.col(420);
        if (button('2hr', true, ('%s uses their two-hour ability now.'):fmt(c.name))) then
            state.send('!companion 2hr ' .. c.name, ui.FAST);
        end
        imgui.SameLine();
        if (button('Why', true, ('What %s is doing and why, and their last few decisions (in chat).'):fmt(c.name))) then
            state.send('!companion why ' .. c.name, 0, true);
        end
        imgui.SameLine();
        if (confirm_button(state, 'release_' .. c.id, 'Dismiss', ('Send %s home.'):fmt(c.name), true)) then
            state.send('!companion release ' .. c.name, ui.FAST);
        end

        imgui.PopID();
    end

    if (#model.downed > 0) then
        imgui.Spacing();
        heading('Downed');
        for i, d in ipairs(model.downed) do
            imgui.PushID('down' .. i);
            local left = protocol.remaining(model, d.left, state.now);
            imgui.TextColored(COLOR.bad, d.name);
            theme.col(110);
            imgui.TextColored(COLOR.dim, ('%s, %s left'):fmt(ui.job_short(d.job), protocol.clock(left)));
            tip('A healer companion who knows Raise brings them back between fights. If nobody does, they go home and their job can be called again at once.');
            theme.col(260);
            if (button('Raise', L.raise == true and left > 0, L.raise and ('Raise %s yourself.'):fmt(d.name) or 'Your job can\'t cast Raise.')) then
                state.send('!companion raise ' .. d.name, ui.SLOW);
            end
            imgui.PopID();
        end
    end
end

--[[
* Call: every job by role, click one to call it
--]]
function ui.tabs.call(model, state)
    local can, why = call_state(model);
    if (not can) then
        imgui.TextColored(COLOR.bad, why);
    else
        imgui.TextColored(COLOR.dim, 'Click a job to call a companion of it. A companion you keep answers for their job.');
    end
    imgui.Spacing();

    local keptByJob = {};
    for _, k in ipairs(model.kept) do
        keptByJob[k.job] = keptByJob[k.job] or k.name;
    end

    local size = { 64, 40 };
    for _, role in ipairs(ui.ROLES) do
        local ids = {};
        for _, id in ipairs(model.jobOrder) do
            if (ui.role_of(model, id) == role) then
                table.insert(ids, id);
            end
        end

        if (#ids > 0) then
            imgui.TextColored(role.color, role.label);
            for i, id in ipairs(ids) do
                local job  = model.jobs[id];
                local wait = protocol.remaining(model, job.wait, state.now);
                local label, ok, hint;
                local price = job.egp or 0;
                local more  = job.party and 'Call another one.' or 'Call one now.';
                if (wait > 0 and price > 0) then
                    -- On cooldown: it can still be called, for Everglass (the cooldown keeps running)
                    label, ok = ui.job_short(id) .. '\n' .. ('%d EG'):fmt(price), can;
                    hint = can and ('On cooldown for %s. %s for %d Everglass.'):fmt(protocol.clock(wait), more, price) or why;
                elseif (wait > 0) then
                    label, ok, hint = ui.job_short(id) .. '\n' .. protocol.clock(wait), false, ('Ready again in %s.'):fmt(protocol.clock(wait));
                else
                    label, ok, hint = ui.job_short(id) .. (job.party and '\nin party' or '\nready'), can, can and more or why;
                end

                local subText = (job.sub or 0) > 0 and ('/' .. ui.job_short(job.sub)) or 'default sub job';
                hint = ('%s, %s\n%s'):fmt(ui.job_long(id), subText, hint);
                if (keptByJob[id] ~= nil) then
                    hint = hint .. ('\n%s answers (kept).'):fmt(keptByJob[id]);
                end

                if ((i - 1) % 6 ~= 0) then
                    imgui.SameLine();
                end
                imgui.PushStyleColor(ImGuiCol_Text, ok and role.color or COLOR.dim);
                local clicked = button(label .. '##call' .. id, ok, hint, size);
                imgui.PopStyleColor(1);
                if (clicked) then
                    state.send('!companion ' .. job.cmd, ui.SLOW);
                end
            end
            imgui.Spacing();
        end
    end
end

--[[
* Kept companions
--]]
-- Kept companions that use up a slot: legendary companions (lg = 1) have their own
function ui.kept_count(model)
    local n = 0;
    for _, k in ipairs(model.kept) do
        if ((k.lg or 0) == 0) then
            n = n + 1;
        end
    end
    return n;
end

function ui.tabs.kept(model, state)
    local L = model.limits;
    local can, why = call_state(model);
    local legends = #model.kept - ui.kept_count(model);
    imgui.TextColored(COLOR.text, ('Kept %d/%d%s'):fmt(ui.kept_count(model), L.keptmax or 8,
        legends > 0 and (' + %d legend%s'):fmt(legends, legends == 1 and '' or 's') or ''));
    tip('Keep a companion from the Party tab. They answer every call for their job, as the same person, and grow in bond.');
    imgui.Spacing();

    if (#model.kept == 0) then
        imgui.TextColored(COLOR.dim, 'You keep no companions yet. Press Keep next to one in the Party tab.');
        return;
    end

    -- Errands: anyone back with finds?
    local back = 0;
    for _, k in ipairs(model.kept) do
        if (k.where == 'back') then
            back = back + 1;
        end
    end
    if (back > 0) then
        imgui.SameLine();
        if (button(('Collect (%d back)'):fmt(back), true, 'Take what your companions brought back from their errands.')) then
            state.send('!companion collect', ui.FAST);
        end
    end

    for _, k in ipairs(model.kept) do
        local role = ui.role_of(model, k.job);
        imgui.PushID('kept' .. k.slot);

        imgui.TextColored(role.color, k.name);
        tip(('%s%s%s'):fmt((k.lg or 0) > 0 and 'Legendary companion: has a place of their own, not one of your kept slots.\n' or '',
            (k.pe or '') ~= '' and ('Personality: ' .. k.pe .. '\n') or '',
            ('%d monsters defeated together. !companion history %s for more.'):fmt(k.kl or 0, k.name)));
        theme.col(110);
        imgui.TextColored(COLOR.dim, ui.job_short(k.job));
        theme.col(150);
        imgui.TextColored(COLOR.bond, k.rank);

        -- Bond progress within the current rank, to the next one
        theme.col(240);
        local points = k.points or 0;
        if (k.next ~= nil and k.next ~= '' and (k.nextat or 0) > 0) then
            local from = math.min(k.at or 0, points);
            local need = math.max(1, k.nextat - from);
            local done = math.min(points - from, need);
            bar(done / need, COLOR.bond, 150, ('%d/%d to %s'):fmt(done, need, k.next));
            tip(('%d bond in all. %s at %d.\nBond grows with every monster you defeat together.'):fmt(points, k.next, k.nextat));
        else
            bar(1, COLOR.bond, 150, ('%d (top rank)'):fmt(points));
            tip('The top rank. They use their two-hour by themselves in an emergency.');
        end

        theme.col(400);
        local wait = protocol.remaining(model, k.wait, state.now);
        local ok, hint;
        if (k.where == 'party') then
            imgui.TextColored(COLOR.good, 'with you');
            ok, hint = false, 'Already in your party.';
        elseif (k.where == 'down') then
            imgui.TextColored(COLOR.bad, 'down');
            ok, hint = false, 'Downed: raise them, or wait until they go home.';
        elseif (k.where == 'errand') then
            imgui.TextColored(COLOR.rested or COLOR.dim, ('away %s'):fmt(protocol.clock(wait)));
            ok, hint = false, ('On an errand, back in %s.'):fmt(protocol.clock(wait));
        elseif (k.where == 'back') then
            imgui.TextColored(COLOR.gold, 'back!');
            ok, hint = false, 'Back from an errand: Collect what they brought first.';
        elseif (wait > 0) then
            imgui.TextColored(COLOR.dim, protocol.clock(wait));
            local job   = model.jobs[k.job];
            local price = job and job.egp or 0;
            if (price > 0) then
                ok, hint = can, can and ('Their job is on cooldown for %s. Call %s now for %d Everglass.'):fmt(protocol.clock(wait), k.name, price) or why;
            else
                ok, hint = false, ('Their job is ready again in %s.'):fmt(protocol.clock(wait));
            end
        else
            imgui.TextColored(COLOR.text, 'ready');
            ok, hint = can, can and ('Call %s.'):fmt(k.name) or why;
        end

        theme.col(460);
        if (button('Call', ok, hint)) then
            state.send('!companion call ' .. k.name, ui.SLOW);
        end
        imgui.SameLine();
        local home = k.where ~= 'errand' and k.where ~= 'back' and k.where ~= 'down';
        if (button('Errand', home, home and ('Send %s away for an hour to gather, dig or help the expedition crew.'):fmt(k.name)
            or 'Not while they\'re away, back with finds, or down.')) then
            state.errand_for = (state.errand_for == k.slot) and nil or k.slot;
        end
        imgui.SameLine();
        if (confirm_button(state, 'forget_' .. k.slot, 'Forget', ('Stop keeping %s. Their bond is lost.'):fmt(k.name), true)) then
            state.send('!companion forget ' .. k.name, ui.FAST);
        end

        -- The errand choices, under the companion they're for
        if (state.errand_for == k.slot and home) then
            imgui.TextColored(COLOR.dim, '    Send to:');
            for _, e in ipairs(ui.ERRANDS) do
                imgui.SameLine();
                if (button(e.label, true, e.tip)) then
                    state.send(('!companion errand %s %s'):fmt(k.name, e.key), ui.SLOW);
                    state.errand_for = nil;
                end
            end
            imgui.SameLine();
            if (button('Cancel', true, nil)) then
                state.errand_for = nil;
            end
        end

        imgui.PopID();
    end
end

-- Errand kinds (modules/companions/lua/companions_errands.lua)
ui.ERRANDS = {
    { key = 'log',      label = 'Log',      tip = 'Logging in a zone you\'ve visited: logs and what grows there.' },
    { key = 'mine',     label = 'Mine',     tip = 'Mining in a zone you\'ve visited: ores and stones.' },
    { key = 'harvest',  label = 'Harvest',  tip = 'Harvesting in a zone you\'ve visited: plants and herbs.' },
    { key = 'excavate', label = 'Excavate', tip = 'Excavating in a zone you\'ve visited.' },
    { key = 'dig',      label = 'Dig',      tip = 'Chocobo digging in a zone you\'ve visited, at your digging rank.' },
    { key = 'crew',     label = 'Crew',     tip = 'Help the expedition crew: their chance goes up and you earn Everglass now.' },
};

--[[
* Presets
--]]
local function preset_jobs_text(jobs)
    local names = {};
    for _, id in ipairs(jobs) do
        table.insert(names, ui.job_short(id));
    end
    return table.concat(names, ' ');
end

-- What the server accepts as a name: letters, digits, spaces, - and ', up to 15
function ui.clean_name(name)
    name = (name or ''):gsub('[^%w %-\']', ''):gsub('^%s+', ''):gsub('%s+$', ''):gsub('%s+', ' ');
    return name:sub(1, 15);
end

function ui.tabs.presets(model, state)
    local L = model.limits;
    local can, why = call_state(model);
    local full = #model.presets >= (L.presetmax or 5);

    imgui.TextColored(COLOR.text, ('Presets %d/%d'):fmt(#model.presets, L.presetmax or 5));
    tip('Loading a preset sends home the companions not in it and calls the missing jobs.');
    imgui.Spacing();

    if (#model.presets == 0) then
        imgui.TextColored(COLOR.dim, 'No presets yet. Save your party or build one below.');
    end

    for _, p in ipairs(model.presets) do
        imgui.PushID('preset' .. p.slot);
        imgui.TextColored(COLOR.gold, p.name);
        theme.col(130);
        imgui.TextColored(COLOR.text, preset_jobs_text(p.jobs));
        theme.col(330);
        local loadable = L.can ~= false;
        if (button('Load', loadable, loadable and ('Call "%s".'):fmt(p.name) or why)) then
            state.send('!companion load ' .. p.name, ui.SLOW);
        end
        imgui.SameLine();
        if (button('Edit', true, 'Load these jobs into the builder below.')) then
            state.build = { jobs = {}, name = { p.name } };
            for _, id in ipairs(p.jobs) do
                table.insert(state.build.jobs, id);
            end
        end
        imgui.SameLine();
        if (confirm_button(state, 'delete_' .. p.slot, 'Delete', ('Forget "%s".'):fmt(p.name), true)) then
            state.send('!companion delete ' .. p.name, ui.FAST);
        end
        imgui.PopID();
    end

    -- Save the companions in the party now
    imgui.Spacing();
    heading('Save your party');
    imgui.PushItemWidth(150);
    imgui.InputText('##save_name', state.save_name, 16);
    imgui.PopItemWidth();
    imgui.SameLine();
    local name = ui.clean_name(state.save_name[1]);
    local exists = false;
    for _, p in ipairs(model.presets) do
        exists = exists or lower(p.name) == lower(name);
    end
    local ok, hint = true, ('Save the %d companions in your party as "%s".'):fmt(#model.party, name);
    if (#model.party == 0) then
        ok, hint = false, 'Call the companions you want first.';
    elseif (name == '') then
        ok, hint = false, 'Name the preset (letters, digits and spaces, up to 15).';
    elseif (full and not exists) then
        ok, hint = false, 'You have as many presets as you can. Delete one first.';
    elseif (exists) then
        hint = ('Replace "%s" with your party.'):fmt(name);
    end
    if (button(exists and 'Replace' or 'Save', ok, hint)) then
        state.send('!companion save ' .. name, ui.FAST);
        state.save_name[1] = '';
    end

    -- Build one from jobs
    imgui.Spacing();
    heading('Build a preset');
    local b = state.build;
    local max = L.presetjobs or 5;
    local picked = {};
    for _, id in ipairs(b.jobs) do
        picked[id] = true;
    end

    for i, id in ipairs(model.jobOrder) do
        if ((i - 1) % 10 ~= 0) then
            imgui.SameLine();
        end
        local on = picked[id] == true;
        local role = ui.role_of(model, id);
        imgui.PushStyleColor(ImGuiCol_Text, on and role.color or COLOR.faint);
        if (choice(ui.job_short(id) .. '##build' .. id, on, ui.job_long(id), on or #b.jobs < max)) then
            table.insert(b.jobs, id);
        end
        -- clicking a lit job takes it out
        if (on and imgui.IsItemClicked()) then
            for j, x in ipairs(b.jobs) do
                if (x == id) then
                    table.remove(b.jobs, j);
                    break;
                end
            end
        end
        imgui.PopStyleColor(1);
    end

    imgui.TextColored(#b.jobs > 0 and COLOR.text or COLOR.dim, #b.jobs > 0 and preset_jobs_text(b.jobs) or ('Pick up to %d jobs.'):fmt(max));
    imgui.PushItemWidth(150);
    imgui.InputText('##build_name', b.name, 16);
    imgui.PopItemWidth();
    imgui.SameLine();
    local bname = ui.clean_name(b.name[1]);
    local bexists = false;
    for _, p in ipairs(model.presets) do
        bexists = bexists or lower(p.name) == lower(bname);
    end
    local bok, bhint = true, ('Save %s as "%s".'):fmt(preset_jobs_text(b.jobs), bname);
    if (#b.jobs == 0) then
        bok, bhint = false, 'Pick the jobs first.';
    elseif (bname == '') then
        bok, bhint = false, 'Name the preset (letters, digits and spaces, up to 15).';
    elseif (full and not bexists) then
        bok, bhint = false, 'You have as many presets as you can. Delete one first.';
    end
    if (button(bexists and 'Replace##build' or 'Save##build', bok, bhint)) then
        local cmds = {};
        for _, id in ipairs(b.jobs) do
            table.insert(cmds, model.jobs[id] and model.jobs[id].cmd or ui.job_short(id):lower());
        end
        state.send(('!companion define %s %s'):fmt(table.concat(cmds, ','), bname), ui.FAST);
        state.build = { jobs = {}, name = { '' } };
    end
    imgui.SameLine();
    if (button('Clear', #b.jobs > 0 or b.name[1] ~= '', 'Start over.')) then
        state.build = { jobs = {}, name = { '' } };
    end
end

--[[
* Settings
--]]
local function row(label, hint)
    imgui.TextColored(COLOR.dim, label);
    tip(hint);
    theme.col(150);
end

-- A two-way switch row: sends cmd_a or cmd_b
local function switch(label, hint, a_label, a_on, a_hint, a_cmd, b_label, b_hint, b_cmd, state, delay)
    row(label, hint);
    if (choice(a_label .. '##' .. label, a_on, a_hint)) then
        state.send(a_cmd, delay);
    end
    imgui.SameLine();
    if (choice(b_label .. '##' .. label, not a_on, b_hint)) then
        state.send(b_cmd, delay);
    end
end

function ui.tabs.settings(model, state)
    local M = model.modes;
    if (model.limits.battle) then
        imgui.TextColored(COLOR.warn, 'In battle: role, gear and sub job changes wait until the fight is over.');
        imgui.Spacing();
    end

    heading('Fighting');
    switch('Engage', 'When companions join the fight.',
        'Attack', M.engage ~= 'retail', 'As soon as you engage.', '!companion engage attack',
        'Retail', 'After your first swing (applies to your regular Trusts too).', '!companion engage retail', state, ui.FAST);
    switch('Treasure Hunter', 'What Thieves wear. They swap out and back in with the new gear, between fights.',
        'On', M.th, 'Thieves wear the most Treasure Hunter.', '!companion th on',
        'Off', 'Thieves wear their best damage gear.', '!companion th off', state, ui.SLOW);
    switch('Nuke mode', 'Black Mages swap out and back in, between fights.',
        'On', M.nuke, 'Black Mages cast nukes nonstop.', '!companion nuke on',
        'Off', 'Black Mages nuke at their normal pace.', '!companion nuke off', state, ui.SLOW);
    switch('Party chat', 'Companions call out in party chat (skillchains, two-hours, low MP...).',
        'On', M.chat ~= false, 'Callouts on.', '!companion chat on',
        'Off', 'Callouts off.', '!companion chat off', state, ui.FAST);

    imgui.Spacing();
    heading('Roles');
    switch('Warrior', 'Warriors in your party swap for the new role, between fights.',
        'Tank', not M.wardps, 'Axe or sword and shield, tanking gear.', '!companion war tank',
        'Damage', 'Great axe and damage gear.', '!companion war dps', state, ui.SLOW);
    switch('Paladin', 'Paladins in your party swap for the new role, between fights.',
        'Tank', not M.plddps, 'Sword and shield.', '!companion pld tank',
        'Damage', 'Great sword and damage gear.', '!companion pld dps', state, ui.SLOW);
    switch('Dark Knight', 'Dark Knights in your party swap for the new role, between fights.',
        'Tank', M.drktank, 'Great sword and tanking gear; holds the monster.', '!companion drk tank',
        'Damage', 'Damage dealer (the default).', '!companion drk dps', state, ui.SLOW);

    imgui.Spacing();
    heading('Sub jobs');
    imgui.TextColored(COLOR.dim, 'The sub job companions of each job use. Ones in your party switch between fights.');
    local col = 0;
    for _, id in ipairs(model.jobOrder) do
        local job = model.jobs[id];
        if (col > 0) then
            imgui.SameLine(col * 160 + 8);
        end
        imgui.TextColored(ui.role_of(model, id).color, ui.job_short(id));
        imgui.SameLine(col * 160 + 50);
        imgui.PushItemWidth(90);
        local preview = (job.sub or 0) > 0 and ui.job_short(job.sub) or 'Default';
        if (imgui.BeginCombo('##sub' .. id, preview)) then
            if (imgui.Selectable('Default##' .. id, (job.sub or 0) == 0) and (job.sub or 0) ~= 0) then
                state.send(('!companion sub %s default'):fmt(job.cmd), ui.SLOW);
            end
            for _, sid in ipairs(model.jobOrder) do
                if (sid ~= id) then
                    if (imgui.Selectable(ui.job_short(sid) .. '##' .. id .. '_' .. sid, job.sub == sid) and job.sub ~= sid) then
                        state.send(('!companion sub %s %s'):fmt(job.cmd, model.jobs[sid].cmd), ui.SLOW);
                    end
                end
            end
            imgui.EndCombo();
        end
        imgui.PopItemWidth();
        col = (col + 1) % 3;
    end

    imgui.Spacing();
    heading('In chat');
    if (button('Status', true, 'Every job\'s cooldown, in the chat log.')) then
        state.send('!companion status', 0, true);
    end
    imgui.SameLine();
    if (button('Fight report', true, 'Damage, weapon skills and healing for the last fight.')) then
        state.send('!companion report', 0, true);
    end
    imgui.SameLine();
    if (button('Weapon skills', true, 'What each companion uses.')) then
        state.send('!companion ws', 0, true);
    end
    imgui.SameLine();
    if (button('Gear', true, 'What each companion wears (companionview, /cv, shows it in a window).')) then
        state.send('!companion gear', 0, true);
    end
end

--[[
* The server's answers to the buttons ("Preset "xp" saved..."), newest first, for a while
--]]
function ui.messages(model, state)
    local shown = 0;
    for i = #model.messages, 1, -1 do
        local m = model.messages[i];
        if (state.now - m.at <= ui.MESSAGE_SECONDS and shown < 3) then
            imgui.PushTextWrapPos(0);
            imgui.TextColored(shown == 0 and COLOR.gold or COLOR.dim, m.text);
            imgui.PopTextWrapPos();
            shown = shown + 1;
        end
    end
end

--[[
* Tactics: one job at a time, every rule a row of buttons
--]]
ui.TACTICS = {
    { key = 'interrupt', label = 'Interrupts', values = { 'on', 'off' },
      hint = 'Stun dangerous spells and TP moves (Stun, Shield Bash, Weapon Bash; a stun weapon skill for deadly ones).' },
    { key = 'dispel', label = 'Dispel', values = { 'on', 'off' },
      hint = 'Red Mages and Bards dispel buffs worth removing (Stoneskin, Blink, Haste...).' },
    { key = 'weakness', label = 'Weakness', values = { 'on', 'off' },
      hint = 'Nukers cast the element the monster takes the most from (resistances, day, weather).' },
    { key = 'sleep', label = 'Sleep adds', values = { 'on', 'off' },
      hint = 'Sleepers put monsters that join the fight to sleep.' },
    { key = 'aoe', label = 'Area spells', values = { 'auto', 'never', 'free' },
      hint = 'auto: no area spells while a monster sleeps near the target. never: single target only. free: no limits.' },
    { key = 'range', label = 'Caster range', values = { 'auto', 'close', 'far' },
      hint = 'How far casters stand. auto also steps back past area moves the monster has used.' },
    { key = 'talk', label = 'Callouts', values = { 'on', 'quiet' },
      hint = 'Tactics callouts in party chat (interrupts, weaknesses, dispels).' },
};

ui.MP_STEPS = { 0, 10, 20, 30, 40, 50 };

function ui.tabs.tactics(model, state)
    imgui.TextColored(COLOR.dim, 'Rules for each job\'s companions. Presets save them too.');
    imgui.Spacing();

    -- Job picker
    state.tactics_job = state.tactics_job or model.jobOrder[1];
    local col = 0;
    for _, id in ipairs(model.jobOrder) do
        if (col > 0) then
            imgui.SameLine();
        end
        local custom = model.tactics ~= nil and model.tactics[id] ~= nil;
        if (choice(ui.job_short(id) .. (custom and '*' or '') .. '##tj' .. id, state.tactics_job == id,
            ui.job_long(id) .. (custom and ' (changed from the defaults)' or ''))) then
            state.tactics_job = id;
        end
        col = (col + 1) % 10; -- ten to a line
    end

    local jobId = state.tactics_job;
    local job   = model.jobs[jobId];
    if (job == nil) then
        return;
    end

    imgui.Spacing();
    heading(ui.job_long(jobId));
    local rules = protocol.tactics_of(model, jobId);
    for _, r in ipairs(ui.TACTICS) do
        row(r.label, r.hint);
        for i, v in ipairs(r.values) do
            if (i > 1) then
                imgui.SameLine();
            end
            if (choice(v .. '##t_' .. r.key .. '_' .. v, rules[r.key] == v, r.hint)) then
                state.send(('!companion tactics %s %s %s'):fmt(job.cmd, r.key, v), ui.FAST);
            end
        end
    end

    row('MP kept back', 'No offensive magic below this much MP.');
    for i, v in ipairs(ui.MP_STEPS) do
        if (i > 1) then
            imgui.SameLine();
        end
        if (choice((v == 0 and 'none' or (v .. '%')) .. '##t_mp_' .. v, (rules.mp or 0) == v, 'Keep this much MP back.')) then
            state.send(('!companion tactics %s mp %d'):fmt(job.cmd, v), ui.FAST);
        end
    end

    imgui.Spacing();
    if (button('Defaults##t_reset', model.tactics ~= nil and model.tactics[jobId] ~= nil, 'Every rule back to its default for this job.')) then
        state.send(('!companion tactics %s reset'):fmt(job.cmd), ui.FAST);
    end
end

ui.TAB_ORDER = {
    { key = 'party',    label = 'Party' },
    { key = 'call',     label = 'Call' },
    { key = 'kept',     label = 'Kept' },
    { key = 'presets',  label = 'Presets' },
    { key = 'tactics',  label = 'Tactics' },
    { key = 'settings', label = 'Settings' },
};

--[[
* Draws the window. Returns false when the user closed it.
--]]
function ui.render(model, state)
    local open = { true };
    state.now = os.time();

    if (theme.begin_window('Companion Manager', open, { 640, 500 })) then
        if (button('Refresh', not state.waiting, 'Ask the server again.')) then
            state.update_requested = true;
        end
        imgui.SameLine();
        imgui.TextColored(COLOR.dim, state.waiting and 'Updating...' or (state.updated_text or ''));
        ui.messages(model, state);

        if (not model.loaded) then
            imgui.Separator();
            imgui.TextColored(COLOR.dim, state.waiting and 'Asking the server for your companions...' or 'No answer from the server yet. Press Refresh.');
        elseif (imgui.BeginTabBar('##cm_tabs')) then
            for _, t in ipairs(ui.TAB_ORDER) do
                -- /cm <tab> opens the window on that tab
                local flags = 0;
                if (state.open_tab == t.key) then
                    flags = ImGuiTabItemFlags_SetSelected or 0;
                end
                if (imgui.BeginTabItem(t.label, nil, flags)) then
                    state.tab = t.key;
                    begin_child('##tab_' .. t.key, { 0, 0 }, false);
                    ui.tabs[t.key](model, state);
                    imgui.EndChild();
                    imgui.EndTabItem();
                end
            end
            imgui.EndTabBar();
            state.open_tab = nil;
        end
    end
    theme.end_window();

    return open[1];
end

return ui;
