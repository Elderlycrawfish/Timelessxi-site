# companionview

(Formerly recruitview: recruits are now called **companions**.)

An Ashita v4 addon for TimelessXI. It shows each companion's equipment in the same
4 x 4 layout as the in-game equipment menu, with:

- name, role (Tank / Healer / Support / DPS) and race
- main job and support job with levels
- HP, MP and TP bars
- Attack, Defense, Accuracy, Evasion, ranged Attack and ranged Accuracy
- STR to CHR as base value plus the bonus from gear and effects (green or red)
- item icons from the game client, with the item's name, description and level on hover
- for Thieves, a **Gear for: Treasure Hunter / Damage** switch (the server's Treasure Hunter
  mode). Switching swaps the thief out and back in with the new gear, which takes a few
  seconds, and only works between fights
- for Warriors, Paladins and Dark Knights, a **Role: Tank / Damage** switch (`!companion war|pld|drk
  tank|dps`). The companion is swapped for the new role, also only between fights
- for companions you keep (`!companion keep`), your bond rank next to the name (Comrade, Trusted, ...)

## Commands

| Command | What it does |
|---|---|
| `/cv` or `/companionview` (the old `/rv` also works) | Show or hide the window |
| `/cv update` | Ask for new data now (same as the window's Update button) |
| `/cv auto [sec]` | Update automatically every `sec` seconds while the window is open (minimum 10; 0 = off, the default) |
| `/cv icons <16-64>` | Size of the item icons |

## How it gets the data

The window doesn't use chat or chat commands. Its Update button and its switches
send their action straight to the server in a packet (`action.lua`, the same as
companionmanager's). The companions module catches the packet and consumes it,
so nothing is said in chat. The switches are sent quietly; the window shows the
result. Typed `!companion` commands still work as before.

Nothing is sent at login. When you open the window the addon asks for the data
once, then again only when you press Update (or with `/cv auto`). The server
answers with lines like these on the system channel, which the addon reads and
hides from the chat log:

```
CV1|B|0|count=2
CV1|M|0|th=0,nuke=0,wardps=0,plddps=0,drktank=0
CV1|H|1801|name=Perrin,mjob=7,mlv=75,sjob=1,slv=37,race=1,tank=1,kept=1,bond=Trusted
CV1|G|1801|main=16535,sub=12503,ranged=12506,ammo=12504,head=...
CV1|G|1801|body=12504,hands=12505,ring1=12505,ring2=12505,back=...
CV1|S|1801|hp=1234,mhp=1300,mp=567,mmp=600,tp=3000,att=83,def=61,acc=85,eva=88,ratt=84,racc=86
CV1|A|1801|str=61+7,dex=62+7,vit=63+7,agi=64+7,int=65+7,mnd=66+7,chr=67+7
CV1|Z|0|count=2
```

`B` starts a batch, `Z` ends it, and the id is the companion's target index. `M` has the
player's modes (Treasure Hunter, nuke).
The server side is in `modules/companions/lua/companions_core.lua` (`companions.sheetLines`; the module keeps its internal name `companions`).

## Files

| File | Contents |
|---|---|
| `companionview.lua` | Events, commands, settings, asking for data |
| `action.lua` | Builds and sends the action packet (buttons don't use chat) |
| `protocol.lua` | Reads the feed into a data model; no game or UI code, so it can be tested on its own |
| `icons.lua` | Item icon textures, cached by item id |
| `ui.lua` | The window, built from separate panels |

## Adding to it

The feed and the window were built to grow without breaking older versions:

- **New data:** the server can add keys to any record, or new record types
  (for example `E` for status effects or `R` for resistances). Older addons
  ignore keys they don't know and keep unknown record types in `rec.extra`,
  so a new addon can use them without a protocol change. Change the version
  tag (`RV2`) only for a change older addons would read wrongly.
- **New panels:** add a function to `ui.panels` in `ui.lua` and call it from
  `ui.draw_detail`. Each panel gets the companion record and the window state.

Ideas for later:

1. **Item stats in tooltips:** the server already knows each item's mods and could send them.
2. **Gear compare:** show what a companion would gain from an item in your inventory.
3. **Commands from the window:** buttons for `!companion` commands (dismiss, respawn, set role).
4. **Party overview:** a compact view with every companion's bars and job side by side.
5. **Push updates:** the server sends a companion's lines on level-up or gear change, so the
   addon doesn't need to keep asking. The protocol already accepts records outside a batch.
6. **Themes:** colors are in one table at the top of `ui.lua`, ready to move into settings.
