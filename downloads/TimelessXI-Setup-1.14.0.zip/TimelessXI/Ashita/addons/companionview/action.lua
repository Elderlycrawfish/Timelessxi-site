--[[
* companionview - action.lua (the same as companionmanager's)
*
* Sends a button's action to the server without using chat. The action rides in a 0x0B5 packet
* whose text starts with the marker \x7F"CM|"; the companions module (companions.cpp) takes it,
* runs it and consumes the packet, so it never shows as chat and runs no chat command. Typed
* !companion commands still work as before.
*
* The action text is the words of a !companion command ('keep Brokk', 'th on'), with:
*   fill     fill the party (plain !companion)
*   >words   the server answers in chat (for the "In chat" buttons)
*   -words   the server doesn't answer at all
*   words    the server answers in this window, then sends a fresh feed
--]]

local action = {};

action.PACKET = 0x0B5;
action.MARKER = '\127CM|';
action.MAX    = 120; -- letters of action text (the server reads up to 120)

--[[
* '!companion keep Brokk' -> 'keep Brokk', '!companion' -> 'fill'. prefix: '', '>' or '-'.
--]]
function action.from_command(cmd, prefix)
    local text = (cmd or ''):gsub('^%s*!companion', ''):gsub('^%s+', ''):gsub('%s+$', '');
    if (text == '') then
        text = 'fill';
    end
    return (prefix or '') .. text;
end

--[[
* The packet bytes (a table, as Ashita's packet manager takes them).
* Header: id 0x0B5, size in 4-byte words (shifted left 1), sync 0 (Ashita fills it);
* then Kind 0 (say, never used: the server consumes the packet), a spare byte, the text.
--]]
function action.build(text)
    local payload = action.MARKER .. string.sub((text or ''):gsub('[^\32-\126]', ''), 1, action.MAX);
    local size = 4 + 2 + #payload + 1; -- + NUL
    size = math.ceil(size / 4) * 4;

    local packet = { action.PACKET % 256, (size / 4) * 2 + math.floor(action.PACKET / 256), 0, 0, 0, 0 };
    for i = 1, #payload do
        packet[#packet + 1] = string.byte(payload, i);
    end
    while (#packet < size) do
        packet[#packet + 1] = 0;
    end
    return packet;
end

function action.send(text)
    AshitaCore:GetPacketManager():AddOutgoingPacket(action.PACKET, action.build(text));
end

return action;
