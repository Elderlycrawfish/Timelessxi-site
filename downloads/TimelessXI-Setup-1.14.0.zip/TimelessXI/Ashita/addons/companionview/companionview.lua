--[[
* companionview - an equipment and stats window for TimelessXI companions.
*
* Asks the server for companion data when you open the window, hides those data
* lines from the chat log, and shows each companion's job, equipment, combat
* stats and attributes.
*
* The window's buttons (Update, the Treasure Hunter and role switches) don't use
* chat or chat commands: they send their action in a packet the companions module
* takes and consumes (action.lua). Typed !companion commands still work as before.
*
* Commands:
*   /cv                  show or hide the window (/companionview, and the old /rv, also work)
*   /cv update           ask for new data now (the window's Update button does the same)
*   /cv auto [sec]       update every <sec> seconds while the window is open (0 = off, the default)
*
* Nothing is sent at login. Data is asked for once when you open the window,
* then only when you press Update (or with /cv auto).
*   /cv icons <size>     icon size in the equipment grid (16 - 64)
--]]

addon.name    = 'companionview';
addon.author  = 'TimelessXI';
addon.version = '1.1';
addon.desc    = 'Shows the equipment, job and stats of your companions.';
addon.link    = '';

require('common');
local chat     = require('chat');
local settings = require('settings');
local action   = require('action');
local protocol = require('protocol');
local icons    = require('icons');
local ui       = require('ui');

local defaults = T{
    auto_refresh = 0,  -- seconds between automatic updates while open (0 = off)
    icon_size    = 32,
};

local rv = {
    settings  = settings.load(defaults),
    model     = protocol.new_model(),
    visible   = false, -- always starts closed
    state     = { selected = nil, icon_size = 32, bar_width = 260, waiting = false },
    last_ask  = 0,
    asked_at  = 0,
};

local function msg(text)
    print(chat.header(addon.name):append(chat.message(text)));
end

local function in_game()
    local party = AshitaCore:GetMemoryManager():GetParty();
    return party ~= nil and party:GetMemberServerId(0) ~= 0;
end

local function ask()
    if (not in_game()) then
        return;
    end
    rv.last_ask = os.clock();
    rv.asked_at = os.time();
    rv.state.waiting = true;
    action.send('data');
end

settings.register('settings', 'settings_update', function(s)
    if (s ~= nil) then
        rv.settings = s;
    end
end);

ashita.events.register('load', 'load_cb', function()
    rv.state.icon_size = rv.settings.icon_size;
end);

ashita.events.register('unload', 'unload_cb', function()
    settings.save();
    icons.clear();
end);

-- Hide the data lines and read them into the model
ashita.events.register('text_in', 'text_in_cb', function(e)
    local line = protocol.extract(e.message_modified) or protocol.extract(e.message);
    if (line == nil) then
        return;
    end

    e.blocked = true;
    if (protocol.feed(rv.model, line)) then
        rv.state.waiting = false;
        rv.state.updated_text = 'Updated ' .. os.date('%I:%M:%S %p');
    end
end);

ashita.events.register('command', 'command_cb', function(e)
    local args = e.command:args();
    if (#args == 0 or not (args[1]:any('/cv') or args[1]:any('/companionview') or args[1]:any('/rv') or args[1]:any('/companionview'))) then
        return;
    end
    e.blocked = true;

    local sub = (args[2] or ''):lower();
    if (sub == '') then
        rv.visible = not rv.visible;
        if (rv.visible) then
            ask();
        end
    elseif (sub == 'update') then
        ask();
    elseif (sub == 'auto') then
        local n = tonumber(args[3]);
        if (n ~= nil) then
            -- At most every 10 seconds, so it never floods the server or chat
            rv.settings.auto_refresh = (n <= 0) and 0 or math.max(10, n);
            settings.save();
        end
        msg(rv.settings.auto_refresh > 0 and ('Updates every %d seconds while the window is open.'):fmt(rv.settings.auto_refresh) or 'Automatic updates are off. Use Update or /cv update.');
    elseif (sub == 'icons') then
        local n = tonumber(args[3]);
        if (n ~= nil) then
            rv.settings.icon_size = math.min(64, math.max(16, n));
            rv.state.icon_size = rv.settings.icon_size;
            settings.save();
        end
        msg(('Icon size %d.'):fmt(rv.settings.icon_size));
    else
        msg('/cv | /cv update | /cv auto [sec] | /cv icons <16-64>');
    end
end);

ashita.events.register('d3d_present', 'present_cb', function()
    if (not rv.visible or not in_game()) then
        return;
    end

    -- A switch in the window (Treasure Hunter / Damage gear): send it (quietly: the window shows
    -- the result), then update once the companion is back with its new gear
    if (rv.state.command ~= nil) then
        local cmd = rv.state.command;
        rv.state.command = nil;
        action.send(action.from_command(cmd, '-'));
        rv.state.switching_until = os.clock() + 8;
        rv.update_at = os.clock() + 8;
    end
    if (rv.update_at ~= nil and os.clock() >= rv.update_at) then
        rv.update_at = nil;
        rv.state.update_requested = true;
    end

    if (rv.state.update_requested) then
        rv.state.update_requested = false;
        if (not rv.state.waiting) then
            ask();
        end
    elseif (rv.settings.auto_refresh > 0 and os.clock() - rv.last_ask >= rv.settings.auto_refresh) then
        ask();
    end

    -- No answer (e.g. the server doesn't have the feed): stop showing "asking"
    if (rv.state.waiting and os.time() - rv.asked_at > 5) then
        rv.state.waiting = false;
    end

    if (not ui.render(rv.model, rv.state)) then
        rv.visible = false;
    end
end);
