--[[
* companionview - ui.lua
*
* The window: companion list on the left; job, equipment grid and stats on the right.
* Each part of the right side is its own function in ui.panels, drawn in the
* order of ui.layout, so new panels can be added without touching the others.
--]]

require('common');
local imgui    = require('imgui');
local theme    = require('theme');
local icons    = require('icons');
local protocol = require('protocol');

local ui = {};

local JOBS = {
    [1] = { 'WAR', 'Warrior' },     [2] = { 'MNK', 'Monk' },          [3] = { 'WHM', 'White Mage' },
    [4] = { 'BLM', 'Black Mage' },  [5] = { 'RDM', 'Red Mage' },      [6] = { 'THF', 'Thief' },
    [7] = { 'PLD', 'Paladin' },     [8] = { 'DRK', 'Dark Knight' },   [9] = { 'BST', 'Beastmaster' },
    [10] = { 'BRD', 'Bard' },       [11] = { 'RNG', 'Ranger' },       [12] = { 'SAM', 'Samurai' },
    [13] = { 'NIN', 'Ninja' },      [14] = { 'DRG', 'Dragoon' },      [15] = { 'SMN', 'Summoner' },
    [16] = { 'BLU', 'Blue Mage' },  [17] = { 'COR', 'Corsair' },      [18] = { 'PUP', 'Puppetmaster' },
    [19] = { 'DNC', 'Dancer' },     [20] = { 'SCH', 'Scholar' },      [21] = { 'GEO', 'Geomancer' },
    [22] = { 'RUN', 'Rune Fencer' },
};

local RACES = {
    [1] = 'Hume', [2] = 'Hume', [3] = 'Elvaan', [4] = 'Elvaan',
    [5] = 'Tarutaru', [6] = 'Tarutaru', [7] = 'Mithra', [8] = 'Galka',
};

local SLOT_LABELS = {
    main = 'Main', sub = 'Sub', ranged = 'Range', ammo = 'Ammo',
    head = 'Head', neck = 'Neck', ear1 = 'Ear', ear2 = 'Ear',
    body = 'Body', hands = 'Hands', ring1 = 'Ring', ring2 = 'Ring',
    back = 'Back', waist = 'Waist', legs = 'Legs', feet = 'Feet',
};

-- Colors (r, g, b, a)
-- Colours: the shared TimelessXI palette (theme.lua), plus the equipment grid's own
local COLOR = theme.colors({
    bonus    = theme.COLOR.good,
    malus    = theme.COLOR.bad,
    faint    = { 0.56, 0.59, 0.67, 0.70 },
    slot_bg  = { 0.115, 0.125, 0.165, 0.95 },
    slot_bd  = { 0.36, 0.38, 0.48, 0.90 },
    slot_hov = theme.COLOR.gold,
});

local ROLE = {
    tank    = { label = 'Tank',    color = { 0.40, 0.65, 1.00, 1.0 } },
    healer  = { label = 'Healer',  color = { 0.45, 0.90, 0.55, 1.0 } },
    support = { label = 'Support', color = { 0.80, 0.55, 1.00, 1.0 } },
    dps     = { label = 'DPS',     color = { 1.00, 0.50, 0.40, 1.0 } },
};

local ROLE_BY_JOB = {
    [7] = 'tank', [13] = 'tank',
    [3] = 'healer', [5] = 'healer', [20] = 'healer',
    [10] = 'support', [15] = 'support', [17] = 'support',
};

function ui.job_short(id) return (JOBS[id] or { '---' })[1]; end
function ui.job_long(id)  return (JOBS[id] or { nil, 'None' })[2]; end

function ui.role(rec)
    if (rec.tank) then
        return ROLE.tank;
    end
    return ROLE[ROLE_BY_JOB[rec.mjob] or 'dps'];
end

-- Newer imgui (Ashita 4.3+) takes child flags as a number; older versions take a border boolean
local function begin_child(id, size, border)
    local flag = ImGuiChildFlags_Borders or ImGuiChildFlags_Border;
    if (flag ~= nil) then
        return imgui.BeginChild(id, size, border and flag or 0);
    end
    return imgui.BeginChild(id, size, border);
end

local function u32(c)
    return imgui.GetColorU32(c);
end

--[[
* Panels. Each takes (rec, state) and draws into the current window.
--]]
ui.panels = {};

function ui.panels.header(rec, state)
    local role = ui.role(rec);
    imgui.TextColored(COLOR.gold, rec.name);
    imgui.SameLine();
    imgui.TextColored(role.color, '[' .. role.label .. ']');
    if (rec.bond ~= nil and rec.bond ~= '') then
        imgui.SameLine();
        imgui.TextColored(COLOR.dim, rec.bond);
        if (imgui.IsItemHovered()) then
            if (imgui.BeginTooltip() ~= false) then
                imgui.TextUnformatted(tostring('A companion you keep, and your bond with them (!companion kept).'));
                imgui.EndTooltip();
            end
        end
    end

    local job = ('Lv%d %s'):fmt(rec.mlv, ui.job_long(rec.mjob));
    if (rec.sjob ~= 0) then
        job = job .. (' / Lv%d %s'):fmt(rec.slv, ui.job_long(rec.sjob));
    end
    imgui.TextColored(COLOR.text, job);
    if (RACES[rec.race] ~= nil) then
        imgui.SameLine();
        imgui.TextColored(COLOR.dim, '  ' .. RACES[rec.race]);
    end

    if (rec.mjob == 6) then
        ui.panels.thief_gear(rec, state);
    end

    if (ui.ROLE_SWITCH[rec.mjob] ~= nil) then
        ui.panels.role_switch(rec, state);
    end
end

-- Thieves: gear for Treasure Hunter or for damage (the server's Treasure Hunter mode).
-- Switching swaps the thief out and back in with the new gear, a few seconds.
local function choice(label, active, tip)
    if (active) then
        imgui.PushStyleColor(ImGuiCol_Button, { 0.55, 0.42, 0.15, 1.0 });
        imgui.PushStyleColor(ImGuiCol_ButtonHovered, { 0.62, 0.48, 0.18, 1.0 });
        imgui.PushStyleColor(ImGuiCol_Text, { 1.0, 0.95, 0.80, 1.0 });
    else
        imgui.PushStyleColor(ImGuiCol_Button, { 0.12, 0.13, 0.18, 1.0 });
        imgui.PushStyleColor(ImGuiCol_ButtonHovered, { 0.20, 0.21, 0.28, 1.0 });
        imgui.PushStyleColor(ImGuiCol_Text, COLOR.dim);
    end
    local clicked = imgui.Button(label);
    imgui.PopStyleColor(3);
    if (imgui.IsItemHovered() and tip ~= nil) then
        if (imgui.BeginTooltip() ~= false) then
            imgui.TextUnformatted(tostring(tip));
            imgui.EndTooltip();
        end
    end
    return clicked and not active;
end

function ui.panels.thief_gear(rec, state)
    local th = state.modes ~= nil and state.modes.th == true;
    imgui.Spacing();
    imgui.TextColored(COLOR.dim, 'Gear for');
    imgui.SameLine();

    if (state.switching_until ~= nil and os.clock() < state.switching_until) then
        imgui.TextColored(COLOR.gold, 'Switching gear...');
        return;
    end

    if (choice('Treasure Hunter', th, 'Wear the gear with the most Treasure Hunter (better drops).')) then
        state.command = '!companion th on';
    end
    imgui.SameLine();
    if (choice('Damage', not th, 'Wear the gear that does the most damage.')) then
        state.command = '!companion th off';
    end
end

-- Warriors, Paladins and Dark Knights: tank or deal damage (the server's !companion war|pld|drk
-- tank|dps). mode is the server's switch; on means the job's other role.
ui.ROLE_SWITCH = {
    [1] = { mode = 'wardps',  cmd = 'war', default = 'tank' },
    [7] = { mode = 'plddps',  cmd = 'pld', default = 'tank' },
    [8] = { mode = 'drktank', cmd = 'drk', default = 'dps' },
};

function ui.panels.role_switch(rec, state)
    local sw = ui.ROLE_SWITCH[rec.mjob];
    local on = state.modes ~= nil and state.modes[sw.mode] == true;
    local tanking = (sw.default == 'tank') ~= on;

    imgui.Spacing();
    imgui.TextColored(COLOR.dim, 'Role');
    imgui.SameLine();

    if (state.switching_until ~= nil and os.clock() < state.switching_until) then
        imgui.TextColored(COLOR.gold, 'Switching role...');
        return;
    end

    if (choice('Tank', tanking, 'Tank: shield (great sword for a Dark Knight) and tanking gear; holds the monster.')) then
        state.command = ('!companion %s tank'):fmt(sw.cmd);
    end
    imgui.SameLine();
    if (choice('Damage', not tanking, 'Damage dealer: two-handed weapon and damage gear.')) then
        state.command = ('!companion %s dps'):fmt(sw.cmd);
    end
end

function ui.panels.bars(rec, state)
    local s = rec.stats;
    local function bar(label, cur, max, color, text)
        cur, max = cur or 0, max or 0;
        local frac = (max > 0) and math.min(cur / max, 1.0) or 0;
        theme.progress(frac, color, state.bar_width / theme.FONT_SCALE, text or ('%s %d/%d'):fmt(label, cur, max));
    end

    bar('HP', s.hp, s.mhp, COLOR.hp);
    if ((s.mmp or 0) > 0) then
        bar('MP', s.mp, s.mmp, COLOR.mp);
    end
    bar('TP', s.tp, 3000, COLOR.tp, ('TP %d'):fmt(s.tp or 0));
end

--[[
* Item tooltip in the style of the game's item window: icon and name on top,
* then the item's description with its stats, weapon damage, level and jobs.
--]]
local tooltip_errors = {}; -- part -> true once its error has been printed

-- Draws one part of the tooltip; if it fails, the rest still shows and the error is printed once
local function part(name, fn, ...)
    local ok, err = pcall(fn, ...);
    if (not ok and not tooltip_errors[name]) then
        tooltip_errors[name] = true;
        print(('[companionview] tooltip %s error: %s'):format(name, tostring(err)));
    end
    return ok;
end

local function tooltip_body(slot, id)
    if (id == 0) then
        imgui.TextColored(COLOR.dim, SLOT_LABELS[slot]);
        imgui.TextColored(COLOR.faint, 'Nothing equipped');
        return;
    end

    local info = nil;
    part('info', function() info = icons.info(id); end);

    part('icon', function()
        local tex = icons.get(id);
        if (tex ~= nil) then
            imgui.Image(tex, { 32, 32 });
            imgui.SameLine();
        end
    end);

    imgui.TextColored(COLOR.gold, (info ~= nil and info.name) or ('Item %d'):fmt(id));
    imgui.TextColored(COLOR.dim, SLOT_LABELS[slot]);
    if (info == nil) then
        return;
    end

    imgui.Separator();
    part('description', function()
        if (info.description ~= '') then
            imgui.PushTextWrapPos(300);
            imgui.TextColored(COLOR.text, info.description);
            imgui.PopTextWrapPos();
        end
    end);

    part('weapon', function()
        if (info.weapon ~= nil) then
            imgui.TextColored(COLOR.text, info.weapon);
        end
    end);

    part('level', function()
        if (info.level > 0 or info.jobs ~= nil) then
            imgui.Spacing();
            local lv = (info.level > 0) and ('Lv.%d '):fmt(info.level) or '';
            imgui.TextColored(COLOR.dim, lv .. (info.jobs or ''));
        end
        if (info.item_level > 0) then
            imgui.TextColored(COLOR.dim, ('<Item Level: %d>'):fmt(info.item_level));
        end
    end);
end

function ui.item_tooltip(slot, id)
    imgui.PushStyleColor(ImGuiCol_PopupBg, { 0.05, 0.06, 0.12, 0.96 });
    imgui.PushStyleColor(ImGuiCol_Border, { 0.55, 0.50, 0.35, 1.0 });
    imgui.PushStyleVar(ImGuiStyleVar_WindowPadding, { 10, 8 });
    imgui.BeginTooltip();

    -- Whatever goes wrong inside, the tooltip is always closed again, so imgui never crashes
    if (not part('body', tooltip_body, slot, id)) then
        imgui.TextColored(COLOR.text, ('Item %d'):fmt(id));
    end

    imgui.EndTooltip();
    imgui.PopStyleVar(1);
    imgui.PopStyleColor(2);
end

function ui.panels.equipment(rec, state)
    local size = state.icon_size;
    local pad  = 4;
    local cell = size + pad * 2;
    local gap  = 3;

    local draw = imgui.GetWindowDrawList();

    -- Normal imgui layout (4 per row), no cursor moving: the window always knows the grid's size
    imgui.PushStyleVar(ImGuiStyleVar_ItemSpacing, { gap, gap });
    for i, slot in ipairs(protocol.SLOTS) do
        if ((i - 1) % 4 ~= 0) then
            imgui.SameLine();
        end
        local x, y = imgui.GetCursorScreenPos();

        imgui.InvisibleButton('##slot_' .. slot, { cell, cell });
        local hovered = imgui.IsItemHovered();

        draw:AddRectFilled({ x, y }, { x + cell, y + cell }, u32(COLOR.slot_bg), 4.0);
        draw:AddRect({ x, y }, { x + cell, y + cell }, u32(hovered and COLOR.slot_hov or COLOR.slot_bd), 4.0, (ImDrawFlags_RoundCornersAll or ImDrawCornerFlags_All or 0), hovered and 2.0 or 1.0);

        local id  = rec.gear[slot] or 0;
        local tex = icons.get(id);
        if (tex ~= nil) then
            draw:AddImage(tex, { x + pad, y + pad }, { x + pad + size, y + pad + size });
        else
            local label = SLOT_LABELS[slot];
            local tw = imgui.CalcTextSize(label);
            draw:AddText({ x + (cell - tw) / 2, y + cell / 2 - 7 }, u32(COLOR.faint), label);
        end

        if (hovered) then
            ui.item_tooltip(slot, id);
        end
    end

    imgui.PopStyleVar(1);
end

local function stat_row(label, value)
    imgui.TextColored(COLOR.dim, label);
    theme.col(110);
    imgui.TextColored(COLOR.text, tostring(value or '-'));
end

function ui.panels.combat(rec, state)
    local s = rec.stats;
    imgui.TextColored(COLOR.gold, 'Combat');
    imgui.Separator();
    stat_row('Attack', s.att);
    stat_row('Defense', s.def);
    stat_row('Accuracy', s.acc);
    stat_row('Evasion', s.eva);
    stat_row('Rng. Attack', s.ratt);
    stat_row('Rng. Accuracy', s.racc);
end

function ui.panels.attributes(rec, state)
    imgui.TextColored(COLOR.gold, 'Attributes');
    imgui.Separator();
    for _, key in ipairs(protocol.ATTRIBUTES) do
        local a = rec.attributes[key];
        imgui.TextColored(COLOR.dim, key:upper());
        theme.col(60);
        if (a == nil) then
            imgui.TextColored(COLOR.text, '-');
        else
            imgui.TextColored(COLOR.text, tostring(a.base));
            if (a.bonus ~= 0) then
                imgui.SameLine();
                imgui.TextColored(a.bonus > 0 and COLOR.bonus or COLOR.malus, ('%+d'):fmt(a.bonus));
            end
        end
    end
end

-- Right side: header and bars on top, then gear next to combat stats and attributes
function ui.draw_detail(rec, state)
    ui.panels.header(rec, state);
    imgui.Spacing();
    ui.panels.bars(rec, state);
    imgui.Spacing();
    imgui.Separator();
    imgui.Spacing();

    imgui.BeginGroup();
    ui.panels.equipment(rec, state);
    imgui.EndGroup();

    imgui.SameLine(0, 16);
    imgui.BeginGroup();
    ui.panels.combat(rec, state);
    imgui.Spacing();
    ui.panels.attributes(rec, state);
    imgui.EndGroup();
end

function ui.draw_list(model, state)
    for _, id in ipairs(model.order) do
        local rec = model.companions[id];
        local role = ui.role(rec);
        local selected = state.selected == id;

        imgui.PushStyleColor(ImGuiCol_Text, role.color);
        if (imgui.Selectable(('%s##rec%d'):fmt(rec.name, id), selected, 0, { 0, 0 })) then
            state.selected = id;
        end
        imgui.PopStyleColor(1);

        local sub = (rec.sjob ~= 0) and ('/%s%d'):fmt(ui.job_short(rec.sjob), rec.slv) or '';
        imgui.TextColored(COLOR.dim, ('  %s%d%s'):fmt(ui.job_short(rec.mjob), rec.mlv, sub));

    end
end

--[[
* Draws the window. Returns false when the user closed it.
--]]
function ui.render(model, state)
    local open = { true };

    if (theme.begin_window('Companions', open, { 640, 430 })) then
        if (theme.button('Update', 'primary', true, 'Ask the server for fresh data.')) then
            state.update_requested = true;
        end
        imgui.SameLine();
        imgui.TextColored(COLOR.dim, state.waiting and 'Updating...' or (state.updated_text or ''));
        imgui.Separator();

        if (#model.order == 0) then
            imgui.TextColored(COLOR.dim, state.waiting and 'Asking the server for your companions...' or 'No companions loaded. Press Update.');
        else
            -- Keep the selection valid
            if (model.companions[state.selected] == nil) then
                state.selected = model.order[1];
            end

            begin_child('##list', { 160, 0 }, true);
            ui.draw_list(model, state);
            imgui.EndChild();

            imgui.SameLine();
            begin_child('##detail', { 0, 0 }, false);
            state.modes = model.modes;
            ui.draw_detail(model.companions[state.selected], state);
            imgui.EndChild();
        end
    end
    theme.end_window();

    return open[1];
end

return ui;
