# craftbook

An Ashita v4 recipe book for TimelessXI. Open it with `/craft`.

## Recipes tab

- **Browse:** a craft between two levels. **My range** jumps to the levels just above your skill,
  where the skill-ups are, and picking a craft jumps there too. On first opening, the book starts on
  your best craft.
- **Search:** recipes whose result's name has the words you type (`/craft bronze` does the same).
- **Can make now:** every recipe your bags hold every ingredient and a crystal for.

Recipes are coloured for your **real** skill:

| Colour | Means |
|---|---|
| Blue | Below your skill: rarely breaks, can be high quality (the tooltip says which HQ tier) |
| Yellow | Above your skill: skill-ups (the tooltip gives the chance not to break) |
| Grey | Above your skill, but your rank is capped: rank up at your guild first |
| Red | Well above your skill: it will usually break |

Gear and image support raise your effective skill, so they make the real odds better than shown.

Pick a recipe to see:
- the crafts and levels it needs, and whether it needs a key item
- your mastery of it, with a bar to the next tier
- each ingredient: how many you have, auction house singles and stacks with the lowest prices, and
  the Artisans Guild's material pool
- its results, NQ and HQ1-3

## Status tab

- **Your crafts:** skill, rank and cap, with a nudge to rank up at the cap.
- **Bonuses:** rested synths, lessons, Flash of Insight (ready or its chance) and the guild-rank saving on breaks.
- **Today's craft orders:** delivered or open, for whom and for how much. Click one to see its recipe.
- **Recipe mastery:** the recipes you've made most, with HQ counts and progress to the next tier.

## Mog House tab

Your Mog House furniture's **hearth bonuses** (the server's `modules/hearth`). Open it with
`/craft mog` (or `/craft hearth`), or click the tab.

- **Your hearth:** how many placed pieces count, the tier thresholds, and your current retail
  moghancement (hover for what it does).
- **Each element:** a bar to the next tier, the tier you're at, and what it gives now, in green; below
  tier 1, what the first tier would give. Hover an element for the next tier and the craftable
  pieces worth most for it.
- **Placed furniture:** each piece that counts, how many, its element, its points, and whether it's
  craftable (those count double).
- **Harmony and Mog Tokens:** whether your home is Harmonious (every element at tier 1 or more, so
  each is one tier higher) and how many Mog Tokens you have (spend them with `!moogle` at home).
- **Moogle chores today:** each chore with its progress and token reward.
- **Furniture sets:** each set, how many of its pieces you've placed, and its perk. Hover for the
  pieces, placed ones ticked.
- **Worth crafting:** the three craftable pieces worth most for each element, with their craft and
  recipe level.

The server counts your furniture when you change zones; **Refresh** counts it again, so after
rearranging your room, press Refresh.

## Champions tab

Your **Champion hunting** (the server's `modules/champions`). Open it with `/craft champions` (or
`/craft bestiary`), or click the tab.

- **Your record:** Champions defeated (Elite and Legendary counted too), your trophies, and your
  chance of meeting one now (green while a lure runs).
- **Bestiary: affixes:** each affix with a bar to its next tier, the attack bonus you have against it,
  and your trophies of it. Hover an affix for what it does.
- **Bestiary: families:** each family you've defeated Champions of, with its tier and perk.
- **Trophy exchange:** every reward with its cost (any trophies, or one affix's); the ones you can
  afford are bright. Buy with `!trophies buy <n>` in game.

## Garden tab

Your **gardening level and crossbreeds** (the server's `modules/garden_plus`). Open it with
`/craft garden`, or click the tab.

- **Your flowerpots:** each placed pot: what's growing, its stage and a progress bar, the crystals
  it was fed, and what it needs. "Wants a crystal" and "Examine it within ..., or it will wilt" show
  in orange; ready ones in green. Then when the next stage comes and about when it's ready (counting
  down from your last Refresh), and a crossbreed you've found that it's on track for. Plants only
  update in your Mog House, so away from home a pot can say "Grown since you looked".
- **Your green thumb:** your gardening level with a bar to the next, and what it gives now: more
  crops, the chance of seeds back, the crossbreed bonus and how much later plants wilt.
- **From your Mog House:** extra crops from the Gardener's Rest set and a Harmonious Home, and the
  chance of a chocobo treat (only with the hearth module).
- **Crossbreeds:** every crossbreed with its level (red when yours is too low). Found ones show what
  they give, your chance now and the recipe (plant, crystals, flowerpot). Ones you came close to
  show the plant and crystal. The rest show only the plant. No spoilers.
- **How gardening works here:** which element each seed and each flowerpot has (feed a crystal that
  matches both for a stronger plant), which plants are trees, and a reminder to examine your plants.

Harvested or fed something? Press Refresh.

## How it works

The addon doesn't use chat. Requests go to the server in a 0x0B5 packet marked `0x7F` `CB|`
(`action.lua`). The craft_plus module (`modules/craft_plus`) consumes it and answers with `CB1|...`
lines, which the addon reads and hides. See `modules/craft_plus/lua/craft_book.lua` for the format.

Recipes come from the server's own `synth_recipes`, so the book always matches what the server
allows: only content this server has enabled. Item names and icons come from your game client.

## Files

| File | Contents |
|---|---|
| `craftbook.lua` | Events, `/craft`, the request queue, reading answers |
| `action.lua` | Builds and sends the request packet |
| `protocol.lua` | Reads answers; works out how a recipe stands for your skills |
| `ui.lua` | The window: `ui.tab_recipes`, `ui.tab_status`, `ui.tab_hearth`, `ui.tab_champions`, `ui.tab_garden` |
| `icons.lua` | Item names and icons from the client (the same as companionview's) |
| `tests/addon_test.lua` | Offline checks: `luajit tests/addon_test.lua` from this folder |

**Needs:** the server's craft_plus module, rebuilt. The Mog House tab also needs the hearth module,
the Champions tab the champions module, and the Garden tab the garden_plus module (without them, the
tabs say so).
