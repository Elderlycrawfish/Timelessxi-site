--[[
* craftbook - action.lua
*
* Sends the recipe book's requests to the server without using chat. A request rides in a 0x0B5
* packet whose text starts with the marker \x7F"CB|"; the craft_plus module (craft_plus.cpp)
* takes it, answers it and consumes the packet, so it never shows as chat.
*
* Requests: status, list <craft> <min> <max> <page>, search <page> <text>, make <craft> <page>,
* recipe <id> (modules/craft_plus/lua/craft_book.lua).
--]]

local action = {};

action.PACKET = 0x0B5;
action.MARKER = '\127CB|';
action.MAX    = 120; -- letters of action text (the server reads up to 120)

--[[
* The packet bytes (a table, as Ashita's packet manager takes them).
* Header: id 0x0B5, size in 4-byte words (shifted left 1), sync 0 (Ashita fills it);
* then Kind 0 (say, never used: the server consumes the packet), a spare byte, the text.
--]]
function action.build(text)
    local payload = action.MARKER .. string.sub((text or ''):gsub('[^\32-\126]', ''), 1, action.MAX);
    local size = 4 + 2 + #payload + 1; -- + NUL
    size = math.ceil(size / 4) * 4;

    local packet = { action.PACKET % 256, (size / 4) * 2 + math.floor(action.PACKET / 256), 0, 0, 0, 0 };
    for i = 1, #payload do
        packet[#packet + 1] = string.byte(payload, i);
    end
    while (#packet < size) do
        packet[#packet + 1] = 0;
    end
    return packet;
end

function action.send(text)
    AshitaCore:GetPacketManager():AddOutgoingPacket(action.PACKET, action.build(text));
end

return action;
