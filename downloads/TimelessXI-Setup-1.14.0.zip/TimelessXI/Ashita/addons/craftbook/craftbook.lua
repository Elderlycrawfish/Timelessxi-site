--[[
* craftbook - a recipe book for TimelessXI: every recipe on the server, coloured for your skills.
*
* Recipes   browse a craft by level ("My range" = where your skill-ups are), search by name, or
*           show everything your bags can make right now. Pick one for its ingredients (what you
*           have, auction house stock and prices, the Artisans Guild's pool), its results and
*           your mastery of it.
* Status    your crafts and ranks, rested synths, lessons, Flash of Insight, today's craft orders
*           and the recipes you've made most.
* Mog House your furniture's hearth bonuses (modules/hearth): each element's points, tier and
*           bonus, the pieces you've placed, and the craftable pieces worth most.
* Champions your Champion record, the Bestiary, trophies and the trophy exchange (modules/champions).
* Garden    your gardening level and bonuses (modules/garden_plus), the crossbreeds you've found
*           and hints at the rest, and which crystals and flowerpots suit which seeds.
*
* It asks the server directly (modules/craft_plus): requests go in a packet the server consumes,
* never as chat; the answers are hidden from the chat log.
*
* Commands:
*   /craft               show or hide the window (/craftbook also works)
*   /craft <words>       search the recipes for <words>
*   /craft status        open on the Status tab
*   /craft mog           open on the Mog House tab (/craft hearth also works)
*   /craft champions     open on the Champions tab (/craft bestiary also works)
*   /craft garden        open on the Garden tab
--]]

addon.name    = 'craftbook';
addon.author  = 'TimelessXI';
addon.version = '1.0';
addon.desc    = 'Recipe book: every recipe, coloured for your skills, with ingredients and the market.';
addon.link    = '';

require('common');
local chat     = require('chat');
local action   = require('action');
local protocol = require('protocol');
local icons    = require('icons');
local ui       = require('ui');

local cb = {
    model   = protocol.new_model(),
    visible = false,
    queue   = {},
    next_send = 0,
    asked_at = {},
};

cb.state = {
    mode     = 'list',
    craft    = 0,
    lo       = { 1 },
    hi       = { 10 },
    page     = 1,
    search   = { '' },
    selected = nil,
    waiting  = {},
};

local SEND_GAP = 0.3;

local function msg(text)
    print(chat.header(addon.name):append(chat.message(text)));
end

local function in_game()
    local party = AshitaCore:GetMemoryManager():GetParty();
    return party ~= nil and party:GetMemberServerId(0) ~= 0;
end

-- What kind of answer a request gets
local function kind_of(text)
    local word = text:match('^(%S+)') or '';
    if (word == 'status') then
        return 'status';
    elseif (word == 'recipe') then
        return 'recipe';
    elseif (word == 'hearth') then
        return 'hearth';
    elseif (word == 'garden') then
        return 'garden';
    elseif (word == 'champions') then
        return 'champions';
    end
    return 'page';
end

-- The UI asks through this; the same request twice in a row is sent once
cb.state.request = function(text)
    for _, q in ipairs(cb.queue) do
        if (q == text) then
            return;
        end
    end
    table.insert(cb.queue, text);
end

-- The first time the window opens: your status, then your best craft's skill-up range
local function first_look()
    cb.state.request('status');
    cb.state.first = true;
end

ashita.events.register('unload', 'unload_cb', function()
    icons.clear();
end);

ashita.events.register('text_in', 'text_in_cb', function(e)
    local line = protocol.extract(e.message_modified) or protocol.extract(e.message);
    if (line == nil) then
        return;
    end

    e.blocked = true;
    local done = protocol.feed(cb.model, line, os.time());
    if (done ~= nil) then
        cb.state.waiting[done] = nil;
        cb.state.updated_text = 'Updated ' .. os.date('%I:%M:%S %p');

        -- After the first status: open on the best craft's skill-up range
        if (done == 'status' and cb.state.first) then
            cb.state.first = nil;
            local best, at = 0, 0;
            for i, s in ipairs(cb.model.status.skills) do
                if (s.skill > best) then
                    best, at = s.skill, i;
                end
            end
            if (at > 0) then
                cb.state.craft = at;
                cb.state.lo[1], cb.state.hi[1] = ui.my_range(cb.model, at);
            end
            ui.ask_list(cb.state);
        end
    end
end);

ashita.events.register('command', 'command_cb', function(e)
    local args = e.command:args();
    if (#args == 0 or not (args[1]:any('/craft') or args[1]:any('/craftbook'))) then
        return;
    end
    e.blocked = true;

    local rest = e.command:match('^%S+%s+(.+)$');
    if (rest == nil or rest == '') then
        cb.visible = not cb.visible;
        if (cb.visible and cb.model.status == nil) then
            first_look();
        end
    elseif (rest:lower() == 'status') then
        cb.visible = true;
        cb.state.open_tab = 'status';
        cb.state.request('status');
    elseif (rest:lower() == 'mog' or rest:lower() == 'hearth' or rest:lower() == 'moghouse') then
        cb.visible = true;
        cb.state.open_tab = 'hearth';
        if (cb.model.status == nil) then
            cb.state.request('status');
        end
        cb.state.request('hearth');
    elseif (rest:lower() == 'champions' or rest:lower() == 'champion' or rest:lower() == 'bestiary') then
        cb.visible = true;
        cb.state.open_tab = 'champions';
        if (cb.model.status == nil) then
            cb.state.request('status');
        end
        cb.state.request('champions');
    elseif (rest:lower() == 'garden' or rest:lower() == 'gardening') then
        cb.visible = true;
        cb.state.open_tab = 'garden';
        if (cb.model.status == nil) then
            cb.state.request('status');
        end
        cb.state.request('garden');
    else
        cb.visible = true;
        cb.state.mode = 'search';
        cb.state.search[1] = rest;
        cb.state.page = 1;
        cb.state.tab_recipes = true;
        if (cb.model.status == nil) then
            cb.state.request('status');
        end
        ui.ask_list(cb.state);
    end
end);

ashita.events.register('d3d_present', 'present_cb', function()
    if (not in_game()) then
        return;
    end

    local now = os.clock();
    if (#cb.queue > 0 and now >= cb.next_send) then
        local text = table.remove(cb.queue, 1);
        local kind = kind_of(text);
        cb.state.waiting[kind] = true;
        cb.asked_at[kind] = os.time();
        action.send(text);
        cb.next_send = now + SEND_GAP;
    end

    -- No answer (e.g. a server without craft_plus): stop showing "Asking..."
    for kind, at in pairs(cb.asked_at) do
        if (cb.state.waiting[kind] and os.time() - at > 5) then
            cb.state.waiting[kind] = nil;
        end
    end

    if (not cb.visible) then
        return;
    end

    if (cb.state.refresh) then
        cb.state.refresh = nil;
        cb.state.request('status');
        ui.ask_list(cb.state);
        if (cb.state.selected ~= nil) then
            cb.state.request(('recipe %d'):fmt(cb.state.selected));
        end
        if (cb.model.hearth ~= nil or cb.state.on_hearth) then
            cb.state.request('hearth');
        end
        if (cb.model.garden ~= nil or cb.state.on_garden) then
            cb.state.request('garden');
        end
        if (cb.model.champions ~= nil or cb.state.on_champions) then
            cb.state.request('champions');
        end
    end

    if (not ui.render(cb.model, cb.state)) then
        cb.visible = false;
    end
end);
