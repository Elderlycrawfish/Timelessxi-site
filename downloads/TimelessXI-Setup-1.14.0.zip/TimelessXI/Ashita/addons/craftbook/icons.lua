--[[
* craftbook - icons.lua (the same as companionview's)
*
* Turns item ids into item icon textures, using the game's own item bitmaps
* (the same icons as the in-game equipment menu). Textures are cached by id.
--]]

require('common');
local d3d8 = require('d3d8');
local ffi  = require('ffi');
local C    = ffi.C;

local icons = {
    cache = {}, -- item id -> texture (false if the item has no icon)
};

local function load_texture(id)
    local item = AshitaCore:GetResourceManager():GetItemById(id);
    if (item == nil or item.Bitmap == nil or item.ImageSize == 0) then
        return false;
    end

    local device = d3d8.get_device();
    if (device == nil) then
        return nil; -- try again on a later frame
    end

    local ptr = ffi.new('IDirect3DTexture8*[1]');
    local res = C.D3DXCreateTextureFromFileInMemoryEx(device, item.Bitmap, item.ImageSize,
        0xFFFFFFFF, 0xFFFFFFFF, 1, 0, C.D3DFMT_A8R8G8B8, C.D3DPOOL_MANAGED,
        C.D3DX_DEFAULT, C.D3DX_DEFAULT, 0xFF000000, nil, nil, ptr);
    if (res ~= C.S_OK) then
        return false;
    end

    return d3d8.gc_safe_release(ffi.cast('IDirect3DTexture8*', ptr[0]));
end

--[[
* Returns a texture id that imgui can draw, or nil when there is no icon.
--]]
function icons.get(id)
    if (id == nil or id == 0) then
        return nil;
    end

    local tex = icons.cache[id];
    if (tex == nil) then
        tex = load_texture(id);
        if (tex == nil) then
            return nil;
        end
        icons.cache[id] = tex;
    end

    if (tex == false) then
        return nil;
    end
    return tonumber(ffi.cast('uint32_t', tex));
end

--[[
* Name and description of an item, for tooltips.
--]]
-- Reads a field of the item resource; missing fields (other Ashita versions) give nil
local function field(item, key)
    local ok, v = pcall(function() return item[key]; end);
    return ok and v or nil;
end

local function num(item, key)
    return tonumber(field(item, key)) or 0;
end

local JOB_SHORT = { 'WAR', 'MNK', 'WHM', 'BLM', 'RDM', 'THF', 'PLD', 'DRK', 'BST', 'BRD', 'RNG',
                    'SAM', 'NIN', 'DRG', 'SMN', 'BLU', 'COR', 'PUP', 'DNC', 'SCH', 'GEO', 'RUN' };

-- "All Jobs" or "WAR PLD DRK", like the game's item window
local function jobs_text(mask)
    if (mask == nil or mask == 0) then
        return nil;
    end
    local list, all = {}, true;
    for job = 1, #JOB_SHORT do
        if (bit.band(mask, bit.lshift(1, job)) ~= 0) then
            table.insert(list, JOB_SHORT[job]);
        else
            all = false;
        end
    end
    if (all) then
        return 'All Jobs';
    end
    return table.concat(list, ' ');
end

-- The game writes elements as icons: byte 0xEF followed by one of these
local ELEMENT_ICONS = {
    [0x1F] = 'Fire', [0x20] = 'Ice', [0x21] = 'Wind', [0x22] = 'Earth',
    [0x23] = 'Lightning', [0x24] = 'Water', [0x25] = 'Light', [0x26] = 'Dark',
};

local encoding = nil;
do
    local ok, lib = pcall(require, 'encoding');
    if (ok) then
        encoding = lib;
    end
end

--[[
* Makes the game's item text drawable: element icons become names ("Earth+5"),
* and any Japanese-encoded (Shift-JIS) characters are converted when Ashita's
* encoding library is available.
--]]
function icons.clean_text(text)
    text = string.gsub(text, '\239(.)', function(c)
        local name = ELEMENT_ICONS[string.byte(c)];
        return name or '';
    end);

    if (encoding ~= nil and string.find(text, '[\128-\255]') ~= nil) then
        local ok, out = pcall(function() return encoding:ShiftJIS_To_UTF8(text); end);
        if (ok and type(out) == 'string') then
            text = out;
        end
    end
    return text;
end

--[[
* What an item is, for tooltips: name, description (the game's own text, with its stats),
* weapon damage and delay, level and jobs.
--]]
function icons.info(id)
    local item = AshitaCore:GetResourceManager():GetItemById(id);
    if (item == nil) then
        return nil;
    end

    local desc = field(item, 'Description');
    desc = (desc ~= nil and tostring(desc[1] or '')) or '';
    desc = icons.clean_text(desc);
    local name = field(item, 'Name');
    name = (name ~= nil and name[1] ~= nil) and tostring(name[1]) or ('Item ' .. tostring(id));

    local info = {
        name        = name,
        description = desc,
        level       = num(item, 'Level'),
        item_level  = num(item, 'ItemLevel'),
        jobs        = jobs_text(num(item, 'Jobs')),
        damage      = num(item, 'Damage'),
        delay       = num(item, 'Delay'),
    };

    -- Weapons: add DMG and Delay unless the description already has them
    if (info.damage > 0 and not string.find(desc, 'DMG', 1, true)) then
        info.weapon = ('DMG:%d Delay:%d'):format(info.damage, info.delay);
    end
    return info;
end

function icons.clear()
    icons.cache = {}; -- gc_safe_release frees the textures
end

return icons;
