--[[
* craftbook - protocol.lua
*
* Reads the server's answers (modules/craft_plus/lua/craft_book.lua): CB1|<type>|<id>|key=value,...
* Each answer is a batch from B to Z; its kind says what it replaces:
*   status   S (skills), P (bonuses), O (orders), M (mastery)
*   page     R + G per recipe (a page of a list, search or what you can make)
*   recipe   D + G (the recipe), H (its HQ results), I (each ingredient, with the market)
*   hearth   P (header), E (each element), F (placed pieces), C (craftable pieces worth most),
*            S (furniture sets), K (moogle chores)  (modules/hearth: Mog House furniture bonuses)
*   champions P (your record), A (each affix in the Bestiary), F (each family), E (the trophy
*            exchange)  (modules/champions: Champion monsters)
*   garden   P (your gardening level and bonuses), X (each crossbreed: found, close or unknown),
*            T (each placed flowerpot: what's growing, its stage, crystals, timers, warnings)
*            (modules/garden_plus: gardening levels and crossbreeds)
* Unknown record types and keys are ignored. No game or UI code here.
--]]

local protocol = {};

protocol.VERSION = 'CB1';
protocol.CRAFTS  = { 'ww', 'sm', 'gs', 'cl', 'lt', 'bn', 'al', 'ck' };

function protocol.new_model()
    return {
        status = nil,  -- { skills, bonuses, orders, mastery }
        page   = nil,  -- { what, total, page, pages, recipes }
        recipe = nil,  -- { recipe, hq, ingredients }
        hearth = nil,  -- { on, pieces, tiers, mult, mog, harmony, tokens, elements, placed, best, sets, chores }
        champions = nil, -- { on, kills, elite, legendary, trophies, chance, lure, affixes, families, exchange }
        garden = nil,  -- { on, level, into, need, max, yield, seedBack, crossBonus, wilt, found, total, hearthCrops, treat, crosses, pots }
        pending = nil, -- { kind, data } being received
        received = {}, -- kind -> os.time() of the last complete answer
    };
end

local function split(str, sep)
    local out, pos = {}, 1;
    while (true) do
        local s = string.find(str, sep, pos, true);
        if (s == nil) then
            table.insert(out, string.sub(str, pos));
            return out;
        end
        table.insert(out, string.sub(str, pos, s - 1));
        pos = s + 1;
    end
end

local function parse_pairs(body)
    local out = {};
    for pair in string.gmatch(body or '', '[^,]+') do
        local k, v = string.match(pair, '^([%w_]+)=(.*)$');
        if (k ~= nil) then
            out[k] = v;
        end
    end
    return out;
end

local function n(v) return tonumber(v) or 0; end

-- "640.649*2" -> { { id = 640, qty = 1 }, { id = 649, qty = 2 } }
function protocol.items(text)
    local out = {};
    for part in string.gmatch(text or '', '[^%.]+') do
        local id, qty = string.match(part, '^(%d+)%*(%d+)$');
        if (id ~= nil) then
            table.insert(out, { id = tonumber(id), qty = tonumber(qty) });
        elseif (tonumber(part) ~= nil) then
            table.insert(out, { id = tonumber(part), qty = 1 });
        end
    end
    return out;
end

-- "3:15.7:10" -> { { craft = 3, level = 15 }, ... }
local function subs(text)
    local out = {};
    for c, l in string.gmatch(text or '', '(%d+):(%d+)') do
        table.insert(out, { craft = tonumber(c), level = tonumber(l) });
    end
    return out;
end

local function numbers(text)
    local out = {};
    for v in string.gmatch(text or '', '[^%.]+') do
        table.insert(out, tonumber(v) or 0);
    end
    return out;
end

function protocol.extract(message)
    if (type(message) ~= 'string') then
        return nil;
    end
    local start = string.find(message, protocol.VERSION .. '|', 1, true);
    if (start == nil) then
        return nil;
    end
    local line = string.sub(message, start);
    line = string.gsub(line, '[%c\128-\255]+.*$', '');
    return line;
end

local function recipe_from(id, kv)
    return {
        id      = id,
        name    = kv.n or '?',
        craft   = n(kv.c),
        level   = n(kv.l),
        keyItem = kv.k == '1',
        made    = n(kv.m),
        crystal = n(kv.x),
        subs    = subs(kv.s),
        ingredients = {},
        result  = { id = 0, qty = 1 },
    };
end

--[[
* Feeds one line. Returns the kind of answer that just completed, or nil.
--]]
function protocol.feed(model, line, now)
    local parts = split(line, '|');
    if (parts[1] ~= protocol.VERSION or #parts < 3) then
        return nil;
    end

    local kind = parts[2];
    local id   = tonumber(parts[3]) or 0;
    local kv   = parse_pairs(parts[4]);

    if (kind == 'B') then
        local k = kv.kind or '';
        local data;
        if (k == 'status') then
            data = { skills = {}, bonuses = {}, orders = {}, mastery = {} };
        elseif (k == 'page') then
            data = { what = kv.what or '', total = n(kv.total), page = n(kv.page), pages = math.max(1, n(kv.pages)), recipes = {}, byId = {} };
        elseif (k == 'recipe') then
            data = { recipe = nil, hq = {}, ingredients = {} };
        elseif (k == 'hearth') then
            data = { on = false, pieces = 0, tiers = {}, mult = 1, mog = '', harmony = false, tokens = 0,
                elements = {}, placed = {}, best = {}, sets = {}, chores = {} };
        elseif (k == 'champions') then
            data = { on = false, kills = 0, elite = 0, legendary = 0, trophies = 0, chance = 0, lure = false,
                affixes = {}, families = {}, exchange = {} };
        elseif (k == 'garden') then
            data = { on = false, level = 1, into = 0, need = 0, max = 100, yield = 0, seedBack = 0, crossBonus = 0,
                wilt = 0, found = 0, total = 0, hearthCrops = -1, treat = 0, crosses = {}, pots = {} };
        else
            return nil;
        end
        model.pending = { kind = k, data = data };
        return nil;
    end

    local p = model.pending;
    if (p == nil) then
        return nil;
    end
    local d = p.data;

    if (kind == 'Z') then
        model[p.kind] = d;
        model.received[p.kind] = now or os.time();
        model.pending = nil;
        return p.kind;
    end

    if (p.kind == 'status') then
        if (kind == 'S') then
            for i, key in ipairs(protocol.CRAFTS) do
                local skill, rank = string.match(kv[key] or '', '^(%d+):(%d+)$');
                d.skills[i] = { skill = tonumber(skill) or 0, rank = tonumber(rank) or 0 };
            end
        elseif (kind == 'P') then
            d.bonuses = {
                rested  = n(kv.rested), max = n(kv.max), gain = n(kv.gain),
                insight = n(kv.insight), ready = kv.ready == '1',
                lesson  = n(kv.lesson), lmax = n(kv.lmax), lessons = numbers(kv.l),
                loss    = n(kv.loss), tiers = numbers(kv.t),
            };
        elseif (kind == 'O') then
            table.insert(d.orders, { slot = id, recipe = n(kv.r), name = kv.n or '?', craft = n(kv.c), level = n(kv.l),
                qty = math.max(1, n(kv.q)), done = n(kv.d), who = kv.who or '', gil = n(kv.gil) });
        elseif (kind == 'M') then
            table.insert(d.mastery, { recipe = id, name = kv.n or '?', made = n(kv.made), hq = n(kv.hq) });
        end
    elseif (p.kind == 'page') then
        if (kind == 'R') then
            local r = recipe_from(id, kv);
            table.insert(d.recipes, r);
            d.byId[id] = r;
        elseif (kind == 'G' and d.byId[id] ~= nil) then
            d.byId[id].ingredients = protocol.items(kv.i);
            d.byId[id].result = protocol.items(kv.r)[1] or d.byId[id].result;
        end
    elseif (p.kind == 'recipe') then
        if (kind == 'D') then
            d.recipe = recipe_from(id, kv);
        elseif (kind == 'G' and d.recipe ~= nil) then
            d.recipe.ingredients = protocol.items(kv.i);
            d.recipe.result = protocol.items(kv.r)[1] or d.recipe.result;
        elseif (kind == 'H') then
            d.hq = protocol.items(kv.r);
        elseif (kind == 'I') then
            table.insert(d.ingredients, {
                id = id, need = n(kv.q), have = n(kv.h), crystal = kv.x == '1',
                ah = n(kv.a), ahPrice = n(kv.ap), stacks = n(kv.s), stackPrice = n(kv.sp), pool = n(kv.p),
            });
        end
    elseif (p.kind == 'hearth') then
        if (kind == 'P') then
            d.on     = kv.on == '1';
            d.pieces = n(kv.pieces);
            d.tiers  = numbers(kv.t);
            d.mult   = math.max(1, n(kv.x));
            d.mog    = kv.mog or '';
            d.harmony = kv.h == '1';
            d.tokens  = n(kv.tok);
        elseif (kind == 'E' and id >= 1 and id <= 8) then
            d.elements[id] = {
                id = id, name = kv.n or '?', label = kv.l or '', points = n(kv.p), tier = n(kv.t),
                bonus = kv.b or '', nextBonus = kv.nb or '', nextAt = n(kv.nt),
            };
        elseif (kind == 'F') then
            table.insert(d.placed, { id = id, element = n(kv.e), worth = n(kv.w), qty = math.max(1, n(kv.q)), craft = n(kv.c) });
        elseif (kind == 'C') then
            local e = n(kv.e);
            d.best[e] = d.best[e] or {};
            table.insert(d.best[e], { id = id, element = e, worth = n(kv.w), craft = n(kv.c), level = n(kv.l) });
        elseif (kind == 'S') then
            local pieces = {};
            for part in string.gmatch(kv.i or '', '[^%.]+') do
                local pid, mark = string.match(part, '^(%d+)(%*?)$');
                if (pid ~= nil) then
                    table.insert(pieces, { id = tonumber(pid), placed = mark == '*' });
                end
            end
            table.insert(d.sets, { id = id, name = kv.n or '?', text = kv.d or '', have = n(kv.h), need = math.max(1, n(kv.q)), pieces = pieces });
        elseif (kind == 'K') then
            table.insert(d.chores, { slot = id, text = kv.x or '', have = n(kv.h), need = math.max(1, n(kv.q)), done = kv.d == '1', reward = n(kv.r) });
        end
    elseif (p.kind == 'champions') then
        if (kind == 'P') then
            d.on        = kv.on == '1';
            d.kills     = n(kv.k);
            d.elite     = n(kv.e);
            d.legendary = n(kv.l);
            d.trophies  = n(kv.t);
            d.chance    = n(kv.ch);
            d.lure      = kv.lure == '1';
        elseif (kind == 'A') then
            table.insert(d.affixes, { id = id, name = kv.n or '?', text = kv.x or '', kills = n(kv.k), tier = n(kv.t),
                power = n(kv.pw), nextAt = n(kv.nx), trophies = n(kv.tr) });
        elseif (kind == 'F') then
            table.insert(d.families, { id = id, name = kv.n or '?', kills = n(kv.k), tier = n(kv.t) });
        elseif (kind == 'E') then
            table.insert(d.exchange, { id = id, label = kv.n or '?', cost = n(kv.c), affix = kv.a or '', ok = kv.ok == '1' });
        end
    elseif (p.kind == 'garden') then
        if (kind == 'P') then
            d.on          = kv.on == '1';
            d.level       = math.max(1, n(kv.lv));
            d.into        = n(kv['in']);
            d.need        = n(kv.nd);
            d.max         = math.max(1, n(kv.mx));
            d.yield       = n(kv.y);
            d.seedBack    = n(kv.sb);
            d.crossBonus  = n(kv.cb);
            d.wilt        = n(kv.w);
            d.found       = n(kv.f);
            d.total       = n(kv.t);
            d.hearthCrops = kv.hc ~= nil and n(kv.hc) or -1;
            d.treat       = n(kv.tr);
        elseif (kind == 'X') then
            table.insert(d.crosses, {
                id = id, state = n(kv.st), level = n(kv.l), plant = kv.p or '?', reachable = kv.ok == '1',
                name = kv.n or '', crystal = kv.c or '', crystal2 = kv.c2 or '', pot = kv.pot or '',
                item = n(kv.i), lo = n(kv.lo), hi = n(kv.hi), chance = n(kv.ch),
            });
        elseif (kind == 'T') then
            table.insert(d.pots, {
                id = id, pot = n(kv.pot), plant = kv.k or '', step = n(kv.s), progress = n(kv.p), stages = math.max(1, n(kv.q)),
                feed1 = kv.f1 or '', feed2 = kv.f2 or '',
                nextIn = kv.nx ~= nil and n(kv.nx) or -1, harvestIn = kv.eta ~= nil and n(kv.eta) or -1,
                due = kv.due == '1', dried = kv.d == '1', warn = kv.w or '', cross = kv.x or '',
            });
        end
    end

    return nil;
end

--[[
* How a recipe looks for your skills (status.skills): 'hq' (you're over it: high quality
* possible, tier 1-4), 'skillup' (above you: skill-ups, and some risk), 'capped' (above you but
* your rank is capped), 'hard' (well above you: likely to break). Real skill only.
--]]
function protocol.standing(recipe, skills)
    if (skills == nil or skills[recipe.craft] == nil) then
        return 'unknown', 0;
    end

    local worst, capped = -999, false;
    local function consider(craft, level)
        local s    = skills[craft] or { skill = 0, rank = 0 };
        local diff = level - math.floor(s.skill / 10);
        if (diff > worst) then
            worst = diff;
        end
        if (diff > 0 and s.skill >= (s.rank + 1) * 100) then
            capped = true;
        end
    end

    consider(recipe.craft, recipe.level);
    for _, sub in ipairs(recipe.subs or {}) do
        consider(sub.craft, sub.level);
    end

    if (worst >= 8) then
        return 'hard', worst;
    elseif (worst > 0) then
        return capped and 'capped' or 'skillup', worst;
    end

    local tier = 1;
    if (worst <= -51) then
        tier = 4;
    elseif (worst <= -31) then
        tier = 3;
    elseif (worst <= -11) then
        tier = 2;
    end
    return 'hq', tier;
end

-- Era success chance for a recipe diff levels above your skill (95% at or below it)
function protocol.success(diff)
    if (diff <= 0) then
        return 95;
    elseif (diff <= 3) then
        return 95 - 5 * diff;
    end
    return math.max(0, 80 - 10 * (diff - 3));
end

return protocol;
