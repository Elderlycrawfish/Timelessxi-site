--[[
* craftbook - ui.lua
*
* Five tabs:
*   Recipes   browse a craft by level, search by name, or show what your bags can make; pick one
*             to see its ingredients (what you have, the auction house and the guild's pool), its
*             results and your mastery of it. Recipes are coloured for your skills.
*   Status    your crafts, rested synths, lessons, Flash of Insight, today's craft orders and the
*             recipes you've made most.
*   Mog House your furniture's hearth bonuses (modules/hearth): each element's points, tier and
*             bonus, Harmony, your Mog Tokens and moogle chores, furniture sets, what you've placed,
*             and the craftable pieces worth most.
*   Champions your Champion record, the Bestiary (kills by affix and family, and what they give),
*             your trophies and the trophy exchange (modules/champions).
*   Garden    your flowerpots (what's growing, what it needs, when it's ready), your gardening level
*             and what it gives (modules/garden_plus), the Mog House's garden bonus, the crossbreeds
*             you've found (and hints at the rest), and how gardening works.
*
* Nothing here talks to the game: state.request(text) asks the server (craftbook.lua sends it).
--]]

require('common');
local imgui_raw = require('imgui');

--[[
* A Lua error halfway through drawing would leave windows, combos, tabs, IDs and style pushes
* open, and imgui then stops the whole game on the next frame. So the drawing code goes through
* this wrapper, which keeps a stack of what is open, in the order it was opened; when drawing
* fails, unwind() closes it again innermost first (an ID pushed inside a child is popped before
* that child ends) and the error is shown instead.
--]]
local opened = {};

local function opened_push(kind)
    opened[#opened + 1] = kind;
end

-- Removes the newest entry of this kind (colours and vars live on their own stacks in imgui)
local function opened_pop(kind, n)
    for _ = 1, (n or 1) do
        for i = #opened, 1, -1 do
            if (opened[i] == kind) then
                table.remove(opened, i);
                break;
            end
        end
    end
end

local CLOSE = {
    id      = function() imgui_raw.PopID(); end,
    color   = function() imgui_raw.PopStyleColor(1); end,
    var     = function() imgui_raw.PopStyleVar(1); end,
    width   = function() imgui_raw.PopItemWidth(); end,
    combo   = function() imgui_raw.EndCombo(); end,
    child   = function() imgui_raw.EndChild(); end,
    tabbar  = function() imgui_raw.EndTabBar(); end,
    tabitem = function() imgui_raw.EndTabItem(); end,
    tooltip = function() imgui_raw.EndTooltip(); end,
};

local imgui = setmetatable({
    PushID         = function(...) opened_push('id'); return imgui_raw.PushID(...); end,
    PopID          = function() opened_pop('id'); return imgui_raw.PopID(); end,
    PushStyleColor = function(...) opened_push('color'); return imgui_raw.PushStyleColor(...); end,
    PopStyleColor  = function(n) n = n or 1; opened_pop('color', n); return imgui_raw.PopStyleColor(n); end,
    PushStyleVar   = function(...) opened_push('var'); return imgui_raw.PushStyleVar(...); end,
    PopStyleVar    = function(n) n = n or 1; opened_pop('var', n); return imgui_raw.PopStyleVar(n); end,
    PushItemWidth  = function(...) opened_push('width'); return imgui_raw.PushItemWidth(...); end,
    PopItemWidth   = function() opened_pop('width'); return imgui_raw.PopItemWidth(); end,
    BeginCombo     = function(...)
        local isOpen = imgui_raw.BeginCombo(...);
        if (isOpen) then
            opened_push('combo');
        end
        return isOpen;
    end,
    EndCombo       = function() opened_pop('combo'); return imgui_raw.EndCombo(); end,
    -- BeginChild always needs its EndChild, whatever it returns
    BeginChild     = function(...) opened_push('child'); return imgui_raw.BeginChild(...); end,
    EndChild       = function() opened_pop('child'); return imgui_raw.EndChild(); end,
    BeginTabBar    = function(...)
        local isOpen = imgui_raw.BeginTabBar(...);
        if (isOpen) then
            opened_push('tabbar');
        end
        return isOpen;
    end,
    EndTabBar      = function() opened_pop('tabbar'); return imgui_raw.EndTabBar(); end,
    BeginTabItem   = function(...)
        local isOpen = imgui_raw.BeginTabItem(...);
        if (isOpen) then
            opened_push('tabitem');
        end
        return isOpen;
    end,
    EndTabItem     = function() opened_pop('tabitem'); return imgui_raw.EndTabItem(); end,
}, { __index = imgui_raw });

local function snapshot()
    return #opened;
end

-- Closes everything opened since the snapshot, newest first
local function unwind(mark)
    while (#opened > mark) do
        local kind = table.remove(opened);
        pcall(CLOSE[kind]);
    end
end

--[[
* Tooltips and wrapped text without a format string. SetTooltip and TextWrapped may treat their
* text as a printf format, and this window's texts have percentages in them: "About 85% not to
* break" holds "% n", which makes printf write to memory and crashes the game. These draw the
* text exactly as it is.
--]]
local function show_tooltip(text)
    text = tostring(text or '');
    if (text == '') then
        return;
    end
    if (imgui_raw.BeginTooltip() ~= false) then
        imgui_raw.TextUnformatted(text);
        imgui_raw.EndTooltip();
    end
end

local function wrapped_text(text)
    imgui_raw.PushTextWrapPos(0);
    imgui_raw.TextUnformatted(tostring(text or ''));
    imgui_raw.PopTextWrapPos();
end
local icons    = require('icons');
local theme    = require('theme');
local protocol = require('protocol');

local ui = {};

ui.CRAFTS = { 'Woodworking', 'Smithing', 'Goldsmithing', 'Clothcraft', 'Leathercraft', 'Bonecraft', 'Alchemy', 'Cooking' };
ui.SHORT  = { 'WW', 'SM', 'GS', 'CL', 'LT', 'BN', 'AL', 'CK' };
ui.RANKS  = { [0] = 'Amateur', 'Recruit', 'Initiate', 'Novice', 'Apprentice', 'Journeyman', 'Craftsman', 'Artisan', 'Adept', 'Veteran', 'Expert' };
ui.TIERS  = { 'Practiced', 'Mastered', 'Grandmaster' };

-- Colours: the shared TimelessXI palette (theme.lua), plus the recipe book's own
local COLOR = theme.colors({
    skillup = { 0.98, 0.86, 0.38, 1.0 },
    hq      = theme.COLOR.info,
    rested  = { 0.60, 0.78, 1.00, 1.0 },
});

local STANDING = {
    hq      = { color = COLOR.hq,      tip = 'Below your skill: it rarely breaks, and it can come out high quality.' },
    skillup = { color = COLOR.skillup, tip = 'Above your skill: skill-ups! It breaks a little more often.' },
    capped  = { color = COLOR.dim,     tip = 'Above your skill, but your rank is capped: no skill-ups until you rank up at your guild.' },
    hard    = { color = COLOR.bad,     tip = 'Well above your skill: it will usually break.' },
    unknown = { color = COLOR.text,    tip = nil },
};

local function commas(n)
    local s = tostring(math.floor(n or 0));
    local out = s:reverse():gsub('(%d%d%d)', '%1,'):reverse();
    return (out:gsub('^,', ''));
end

function ui.item_name(id)
    if (id == nil or id == 0) then
        return '-';
    end
    local info = icons.info(id);
    return info ~= nil and info.name or ('Item ' .. tostring(id));
end

local function tip(text)
    if (text ~= nil and text ~= '' and imgui.IsItemHovered()) then
        show_tooltip(text);
    end
end

local function begin_child(id, size, border)
    local flag = ImGuiChildFlags_Borders or ImGuiChildFlags_Border;
    if (flag ~= nil) then
        return imgui.BeginChild(id, size, border and flag or 0);
    end
    return imgui.BeginChild(id, size, border);
end

local function button(label, enabled, hint)
    if (enabled == false) then
        imgui.PushStyleVar(ImGuiStyleVar_Alpha, 0.40);
    end
    local clicked = imgui.Button(label);
    if (enabled == false) then
        imgui.PopStyleVar(1);
    end
    tip(hint);
    return clicked and enabled ~= false;
end

local function choice(label, active, hint)
    if (active) then
        imgui.PushStyleColor(ImGuiCol_Button, { 0.55, 0.42, 0.15, 1.0 });
        imgui.PushStyleColor(ImGuiCol_ButtonHovered, { 0.62, 0.48, 0.18, 1.0 });
        imgui.PushStyleColor(ImGuiCol_Text, { 1.0, 0.95, 0.80, 1.0 });
    else
        imgui.PushStyleColor(ImGuiCol_Button, { 0.12, 0.13, 0.18, 1.0 });
        imgui.PushStyleColor(ImGuiCol_ButtonHovered, { 0.20, 0.21, 0.28, 1.0 });
        imgui.PushStyleColor(ImGuiCol_Text, COLOR.dim);
    end
    local clicked = imgui.Button(label);
    imgui.PopStyleColor(3);
    tip(hint);
    return clicked and not active;
end

local function bar(frac, color, width, text)
    theme.progress(frac, color, width, text); -- the shared bar (theme.lua): fits its text
end

local function heading(text, note)
    theme.section(text, note);
end

local function skills_of(model)
    return model.status and model.status.skills or nil;
end

-- Your skill-up range in a craft: levels just above your skill
function ui.my_range(model, craft)
    local skills = skills_of(model);
    local s = skills and skills[craft];
    if (s == nil) then
        return 1, 10;
    end
    local level = math.floor(s.skill / 10);
    return math.max(0, level + 1), level + 8;
end

-- Asks for the current list (state.mode, craft, lo, hi, page, search text)
function ui.ask_list(state)
    if (state.mode == 'search') then
        local text = (state.search[1] or ''):gsub('^%s+', ''):gsub('%s+$', '');
        if (#text >= 2) then
            state.request(('search %d %s'):fmt(state.page, text));
        end
    elseif (state.mode == 'make') then
        state.request(('make %d %d'):fmt(state.craft, state.page));
    else
        state.request(('list %d %d %d %d'):fmt(state.craft, state.lo[1], state.hi[1], state.page));
    end
end

--[[
* Recipes
--]]
local function craft_combo(state)
    imgui.PushItemWidth(120);
    local preview = state.craft == 0 and 'All crafts' or ui.CRAFTS[state.craft];
    local changed = false;
    if (imgui.BeginCombo('##craft', preview)) then
        if (imgui.Selectable('All crafts', state.craft == 0) and state.craft ~= 0) then
            state.craft = 0;
            changed = true;
        end
        for i, name in ipairs(ui.CRAFTS) do
            if (imgui.Selectable(name .. '##c' .. i, state.craft == i) and state.craft ~= i) then
                state.craft = i;
                changed = true;
            end
        end
        imgui.EndCombo();
    end
    imgui.PopItemWidth();
    return changed;
end

function ui.filters(model, state)
    local ask = false;

    if (choice('Browse', state.mode == 'list', 'A craft\'s recipes between two levels.')) then
        state.mode, ask = 'list', true;
    end
    imgui.SameLine();
    if (choice('Search', state.mode == 'search', 'Recipes whose result\'s name has the words you type.')) then
        state.mode = 'search';
    end
    imgui.SameLine();
    if (choice('Can make now', state.mode == 'make', 'Everything your bags hold every ingredient and the crystal for.')) then
        state.mode, ask = 'make', true;
    end

    if (state.mode == 'search') then
        imgui.PushItemWidth(200);
        imgui.InputText('##search', state.search, 32);
        imgui.PopItemWidth();
        imgui.SameLine();
        if (button('Find', #(state.search[1] or '') >= 2, 'At least two letters.')) then
            state.page, ask = 1, true;
        end
    else
        if (craft_combo(state)) then
            state.page, ask = 1, true;
            if (state.mode == 'list' and state.craft > 0) then
                state.lo[1], state.hi[1] = ui.my_range(model, state.craft);
            end
        end

        if (state.mode == 'list') then
            imgui.SameLine();
            imgui.PushItemWidth(70);
            if (imgui.InputInt('##lo', state.lo, 1, 10)) then
                state.lo[1] = math.max(0, math.min(110, state.lo[1]));
                state.dirty = os.clock();
            end
            imgui.SameLine();
            imgui.TextColored(COLOR.dim, 'to');
            imgui.SameLine();
            if (imgui.InputInt('##hi', state.hi, 1, 10)) then
                state.hi[1] = math.max(state.lo[1], math.min(110, state.hi[1]));
                state.dirty = os.clock();
            end
            imgui.PopItemWidth();
            imgui.SameLine();
            if (button('My range', state.craft > 0 and skills_of(model) ~= nil, 'The levels just above your skill: where the skill-ups are.')) then
                state.lo[1], state.hi[1] = ui.my_range(model, state.craft);
                state.page, ask = 1, true;
            end
        end
    end

    -- Level boxes ask once you stop typing
    if (state.dirty ~= nil and os.clock() - state.dirty > 0.8) then
        state.dirty = nil;
        state.page, ask = 1, true;
    end

    if (ask) then
        ui.ask_list(state);
    end
end

function ui.recipe_line(model, state, r)
    local standing, n = protocol.standing(r, skills_of(model));
    local look = STANDING[standing];
    local selected = state.selected == r.id;

    imgui.PushStyleColor(ImGuiCol_Text, look.color);
    if (imgui.Selectable(('%s##r%d'):fmt(r.name, r.id), selected, 0, { 0, 0 })) then
        state.selected = r.id;
        state.request(('recipe %d'):fmt(r.id));
    end
    imgui.PopStyleColor(1);
    if (imgui.IsItemHovered()) then
        local lines = { ('%s %d%s'):fmt(ui.CRAFTS[r.craft] or '?', r.level, r.keyItem and ' (needs a key item)' or '') };
        for _, s in ipairs(r.subs) do
            table.insert(lines, ('  + %s %d'):fmt(ui.CRAFTS[s.craft] or '?', s.level));
        end
        if (look.tip) then
            table.insert(lines, look.tip);
        end
        if (standing == 'hq') then
            table.insert(lines, ('High quality tier %d of 4.'):fmt(n));
        elseif (standing ~= 'unknown') then
            table.insert(lines, ('About %d%% not to break (real skill; gear and image support help).'):fmt(protocol.success(n)));
        end
        if (r.made > 0) then
            table.insert(lines, ('You\'ve made it %d times.'):fmt(r.made));
        end
        show_tooltip(table.concat(lines, '\n'));
    end

    theme.col(220);
    imgui.TextColored(COLOR.dim, ('%s %d'):fmt(ui.SHORT[r.craft] or '?', r.level));
    if (r.made > 0) then
        theme.col(275);
        imgui.TextColored(COLOR.bond, ('x%d'):fmt(r.made));
    end
end

function ui.results(model, state)
    local page = model.page;
    if (page == nil) then
        imgui.TextColored(COLOR.dim, state.waiting.page and 'Asking the server...' or 'Pick a craft, search, or try "Can make now".');
        return;
    end

    imgui.TextColored(COLOR.dim, ('%d recipe%s'):fmt(page.total, page.total == 1 and '' or 's'));
    imgui.SameLine();
    if (button('<', page.page > 1, 'Previous page')) then
        state.page = page.page - 1;
        ui.ask_list(state);
    end
    imgui.SameLine();
    imgui.TextColored(COLOR.text, ('%d/%d'):fmt(page.page, page.pages));
    imgui.SameLine();
    if (button('>', page.page < page.pages, 'Next page')) then
        state.page = page.page + 1;
        ui.ask_list(state);
    end

    imgui.Separator();
    if (#page.recipes == 0) then
        imgui.TextColored(COLOR.dim, page.what == 'make' and 'Nothing you can make from your bags right now.' or 'No recipes here.');
    end
    for _, r in ipairs(page.recipes) do
        ui.recipe_line(model, state, r);
    end
end

function ui.detail(model, state)
    local d = model.recipe;
    if (state.selected == nil) then
        imgui.TextColored(COLOR.dim, 'Pick a recipe to see what goes in it.');
        return;
    end
    if (d == nil or d.recipe == nil or d.recipe.id ~= state.selected) then
        imgui.TextColored(COLOR.dim, state.waiting.recipe and 'Asking the server...' or 'No details for that recipe.');
        return;
    end

    local r = d.recipe;
    local standing, n = protocol.standing(r, skills_of(model));
    imgui.TextColored(STANDING[standing].color, r.name);
    local need = ('%s %d'):fmt(ui.CRAFTS[r.craft] or '?', r.level);
    for _, s in ipairs(r.subs) do
        need = need .. (', %s %d'):fmt(ui.CRAFTS[s.craft] or '?', s.level);
    end
    imgui.TextColored(COLOR.dim, need);
    if (r.keyItem) then
        imgui.TextColored(COLOR.warn, 'Needs a key item from your guild (an advanced technique).');
    end
    if (standing == 'hq') then
        imgui.TextColored(COLOR.hq, ('You\'re over it: high quality tier %d.'):fmt(n));
    elseif (standing == 'skillup') then
        imgui.TextColored(COLOR.skillup, ('Skill-ups! About %d%% not to break.'):fmt(protocol.success(n)));
    elseif (standing == 'capped') then
        imgui.TextColored(COLOR.dim, 'Above you, but your rank is capped: rank up at your guild.');
    elseif (standing == 'hard') then
        imgui.TextColored(COLOR.bad, ('Too hard for now: about %d%% not to break.'):fmt(protocol.success(n)));
    end

    -- Mastery
    local b = model.status and model.status.bonuses;
    local tiers = b and b.tiers or { 25, 50, 100 };
    local tierName, nextAt, nextName = nil, nil, nil;
    for i, at in ipairs(tiers) do
        if (r.made >= at) then
            tierName = ui.TIERS[i];
        elseif (nextAt == nil) then
            nextAt, nextName = at, ui.TIERS[i];
        end
    end
    imgui.Spacing();
    if (nextAt ~= nil) then
        bar(r.made / nextAt, COLOR.bond, 220, ('%d/%d to %s'):fmt(r.made, nextAt, nextName));
    else
        bar(1, COLOR.bond, 220, ('%d made: %s'):fmt(r.made, tierName or ''));
    end
    tip('Recipe mastery: every successful synth counts. Each tier raises your HQ chance on this recipe.');

    -- Ingredients
    imgui.Spacing();
    heading('Ingredients');
    for _, ing in ipairs(d.ingredients) do
        imgui.PushID('ing' .. ing.id);
        local tex = icons.get(ing.id);
        if (tex ~= nil) then
            imgui.Image(tex, { 16, 16 });
            imgui.SameLine();
        end
        local enough = ing.have >= ing.need;
        imgui.TextColored(enough and COLOR.good or COLOR.text, ('%s%s'):fmt(ui.item_name(ing.id), ing.need > 1 and (' x%d'):fmt(ing.need) or ''));
        theme.col(230);
        imgui.TextColored(enough and COLOR.good or COLOR.dim, ('have %d'):fmt(ing.have));
        theme.col(300);
        local market;
        if (ing.ah > 0 or ing.stacks > 0) then
            market = ('AH: %s'):fmt(ing.ah > 0 and ('%d from %sg'):fmt(ing.ah, commas(ing.ahPrice)) or '');
            if (ing.stacks > 0) then
                market = market .. (' %d stack%s from %sg'):fmt(ing.stacks, ing.stacks == 1 and '' or 's', commas(ing.stackPrice));
            end
            imgui.TextColored(COLOR.text, market);
        else
            imgui.TextColored(COLOR.faint, 'none on the AH');
        end
        if (ing.pool > 0) then
            imgui.SameLine();
            imgui.TextColored(COLOR.dim, ('(guild pool %d)'):fmt(ing.pool));
            tip('The Artisans Guild\'s material pool: the crafters craft from it and sell on the auction house.');
        end
        imgui.PopID();
    end

    -- Results
    imgui.Spacing();
    heading('Results');
    imgui.TextColored(COLOR.text, ('%s%s'):fmt(ui.item_name(r.result.id), r.result.qty > 1 and (' x%d'):fmt(r.result.qty) or ''));
    for i, h in ipairs(d.hq) do
        if (h.id ~= 0) then
            imgui.TextColored(COLOR.hq, ('HQ%d: %s%s'):fmt(i, ui.item_name(h.id), h.qty > 1 and (' x%d'):fmt(h.qty) or ''));
        end
    end
end

function ui.tab_recipes(model, state)
    ui.filters(model, state);
    imgui.Separator();

    begin_child('##results', { 340, 0 }, true);
    ui.results(model, state);
    imgui.EndChild();

    imgui.SameLine();
    begin_child('##detail', { 0, 0 }, false);
    ui.detail(model, state);
    imgui.EndChild();
end

--[[
* Status
--]]
function ui.tab_status(model, state)
    local s = model.status;
    if (s == nil) then
        imgui.TextColored(COLOR.dim, state.waiting.status and 'Asking the server...' or 'No answer from the server yet. Press Refresh.');
        return;
    end

    heading('Your crafts');
    local any = false;
    for i, sk in ipairs(s.skills) do
        if (sk.skill > 0) then
            any = true;
            local cap = (sk.rank + 1) * 10;
            imgui.TextColored(COLOR.text, ui.CRAFTS[i]);
            theme.col(110);
            local level = sk.skill / 10;
            bar((level - (cap - 10)) / 10, level >= cap and COLOR.dim or COLOR.skillup, 150, ('%.1f'):fmt(level));
            imgui.SameLine();
            imgui.TextColored(COLOR.dim, ('%s (cap %d)'):fmt(ui.RANKS[sk.rank] or '?', cap));
            if (level >= cap) then
                imgui.SameLine();
                imgui.TextColored(COLOR.warn, 'rank up at your guild!');
            end
        end
    end
    if (not any) then
        imgui.TextColored(COLOR.dim, 'No craft skill yet. Grab a crystal and try a level 1 recipe!');
    end

    local b = s.bonuses;
    imgui.Spacing();
    heading('Bonuses');
    imgui.TextColored(COLOR.text, 'Rested');
    theme.col(110);
    bar(b.max > 0 and b.rested / b.max or 0, COLOR.rested, 150, ('%d/%d'):fmt(b.rested, b.max));
    imgui.SameLine();
    imgui.TextColored(COLOR.dim, ('+%d%% skill-ups'):fmt(b.gain));
    tip('Every hour away from crafting banks rested synths. Only synths that can skill up use them.');

    local lessons = {};
    for i, n in ipairs(b.lessons) do
        if (n > 0) then
            table.insert(lessons, ('%s %d/%d (+%d%%)'):fmt(ui.CRAFTS[i], n, b.lmax, n * b.lesson));
        end
    end
    imgui.TextColored(COLOR.text, 'Lessons');
    theme.col(110);
    imgui.TextColored(#lessons > 0 and COLOR.warn or COLOR.dim, #lessons > 0 and table.concat(lessons, ', ') or 'none (a break that could skill up gives one)');

    imgui.TextColored(COLOR.text, 'Insight');
    theme.col(110);
    if (b.ready) then
        imgui.TextColored(COLOR.gold, 'Ready! Your next synth that can skill up or HQ gets it.');
    else
        imgui.TextColored(COLOR.dim, ('%d%% on every synth that can skill up or HQ'):fmt(b.insight));
    end

    if (b.loss > 0) then
        imgui.TextColored(COLOR.text, 'Guild rank');
        theme.col(110);
        imgui.TextColored(COLOR.dim, ('%d%% less chance to lose each material on a break'):fmt(b.loss));
    end

    imgui.Spacing();
    heading('Today\'s craft orders');
    if (#s.orders == 0) then
        imgui.TextColored(COLOR.dim, 'No orders today.');
    end
    local open = 0;
    for _, o in ipairs(s.orders) do
        imgui.PushID('order' .. o.slot);
        if (o.done > 0) then
            imgui.TextColored(COLOR.good, ('%s%s'):fmt(o.name, o.qty > 1 and (' x%d'):fmt(o.qty) or ''));
            theme.col(230);
            imgui.TextColored(COLOR.good, o.done == 2 and 'delivered (HQ!)' or 'delivered');
        else
            open = open + 1;
            if (imgui.Selectable(('%s%s##o%d'):fmt(o.name, o.qty > 1 and (' x%d'):fmt(o.qty) or '', o.slot), false, 0, { 220, 0 })) then
                state.tab_recipes = true;
                state.selected = o.recipe;
                state.request(('recipe %d'):fmt(o.recipe));
            end
            tip('Click to see the recipe.');
            theme.col(230);
            imgui.TextColored(COLOR.dim, ('%s %d, to %s: %sg (HQ double)'):fmt(ui.SHORT[o.craft] or '?', o.level, o.who, commas(o.gil)));
        end
        imgui.PopID();
    end
    if (#s.orders > 0) then
        imgui.TextColored(COLOR.faint, open == 0 and 'All done today. New ones tomorrow!' or
            'Hand them to the crafter in the Chamber of Commerce, Lower Jeuno. All done: a Flash of Insight.');
    end

    imgui.Spacing();
    heading('Recipe mastery');
    if (#s.mastery == 0) then
        imgui.TextColored(COLOR.dim, 'Nothing yet: every successful synth of a recipe counts.');
    end
    for _, e in ipairs(s.mastery) do
        local tierName, nextAt = nil, nil;
        for i, at in ipairs(b.tiers) do
            if (e.made >= at) then
                tierName = ui.TIERS[i];
            elseif (nextAt == nil) then
                nextAt = at;
            end
        end
        imgui.TextColored(COLOR.text, e.name);
        theme.col(200);
        bar(nextAt and e.made / nextAt or 1, COLOR.bond, 120, nextAt and ('%d/%d'):fmt(e.made, nextAt) or ('%d'):fmt(e.made));
        imgui.SameLine();
        imgui.TextColored(COLOR.dim, ('%s, %d HQ'):fmt(tierName or 'learning', e.hq));
    end
end

--[[
* Mog House (modules/hearth)
--]]
ui.ELEMENT_COLOR = {
    [1] = { 1.00, 0.50, 0.30, 1.0 }, -- Fire
    [2] = { 0.60, 0.85, 1.00, 1.0 }, -- Ice
    [3] = { 0.50, 0.90, 0.55, 1.0 }, -- Wind
    [4] = { 0.85, 0.70, 0.40, 1.0 }, -- Earth
    [5] = { 0.80, 0.55, 1.00, 1.0 }, -- Lightning
    [6] = { 0.40, 0.60, 1.00, 1.0 }, -- Water
    [7] = { 1.00, 0.97, 0.80, 1.0 }, -- Light
    [8] = { 0.65, 0.50, 0.75, 1.0 }, -- Dark
};

-- What each retail moghancement does (shown on hover)
ui.MOGHANCEMENTS = {
    ['Experience']   = 'Lose 5% less experience when knocked out.',
    ['Gardening']    = 'Plants are less likely to wither.',
    ['Desynthesis']  = 'Desynthesis succeeds a little more often.',
    ['Fishing']      = 'Fishing skill +1.',
    ['Conquest']     = 'More conquest points for you.',
    ['Region']       = 'More region points for your nation.',
    ['Money']        = 'A little more gil from monsters.',
    ['Money ii']     = 'More gil from monsters.',
    ['Skill gains']  = 'Better combat skill-up odds.',
};
for _, el in ipairs({ 'Fire', 'Ice', 'Wind', 'Earth', 'Lightning', 'Water', 'Light', 'Dark' }) do
    ui.MOGHANCEMENTS[el] = ('Lose fewer materials when a synthesis with a %s crystal fails.'):fmt(el:lower());
end
for _, craft in ipairs(ui.CRAFTS) do
    ui.MOGHANCEMENTS[craft] = ('%s skill +1.'):fmt(craft);
end

local function piece_line(b)
    return ('%s %d (%s %d)'):fmt(ui.item_name(b.id), b.worth, ui.SHORT[b.craft] or '?', b.level);
end

function ui.tab_hearth(model, state)
    state.on_hearth = true;
    local h = model.hearth;
    if (h == nil) then
        if (not state.hearth_asked) then
            state.hearth_asked = true;
            state.request('hearth');
        end
        imgui.TextColored(COLOR.dim, state.waiting.hearth and 'Asking the server...' or 'No answer from the server yet. Press Refresh.');
        return;
    end

    if (not h.on) then
        imgui.TextColored(COLOR.dim, 'Mog House bonuses aren\'t on this server (modules/hearth).');
        return;
    end

    heading('Your hearth');
    imgui.TextColored(COLOR.text, ('%d placed piece%s count.'):fmt(h.pieces, h.pieces == 1 and '' or 's'));
    imgui.SameLine();
    imgui.TextColored(COLOR.dim, ('Craftable pieces count x%d. Tiers at %s points.'):fmt(h.mult, table.concat(h.tiers, ' / ')));
    tip('Each piece of furniture you place in your Mog House adds its aura to its element.\nEach element boosts one thing, wherever you go.');

    imgui.TextColored(COLOR.text, 'Moghancement');
    theme.col(110);
    if (h.mog ~= '') then
        imgui.TextColored(COLOR.gold, h.mog);
        tip((ui.MOGHANCEMENTS[h.mog] or 'The retail bonus from your strongest element.') .. '\nRetail moghancements work as before, alongside these.');
    else
        imgui.TextColored(COLOR.dim, 'none (retail: from your strongest element, one at a time)');
    end

    imgui.TextColored(COLOR.text, 'Harmony');
    theme.col(110);
    if (h.harmony) then
        imgui.TextColored(COLOR.good, 'Harmonious Home: every element is one tier higher!');
    else
        imgui.TextColored(COLOR.dim, 'Get every element to tier 1 and each one goes up a tier.');
    end
    tip('A Harmonious Home: every element at tier 1 or more.\nEach element then counts one tier higher (up to the top).');

    imgui.TextColored(COLOR.text, 'Mog Tokens');
    theme.col(110);
    imgui.TextColored(COLOR.gold, ('%d'):fmt(h.tokens));
    imgui.SameLine();
    imgui.TextColored(COLOR.dim, '(spend them with !moogle in your Mog House)');
    tip('Earned from moogle chores. They buy rare furniture, seeds, flowerpots, chocobo treats and rested tonics.');

    imgui.Spacing();
    for element = 1, 8 do
        local e = h.elements[element];
        if (e ~= nil) then
            imgui.PushID('el' .. element);
            imgui.TextColored(ui.ELEMENT_COLOR[element], e.name);
            theme.col(90);

            local from = h.tiers[e.tier] or 0;
            if (e.nextAt > 0) then
                local span = math.max(1, e.nextAt - from);
                bar((e.points - from) / span, ui.ELEMENT_COLOR[element], 130, ('%d/%d'):fmt(e.points, e.nextAt));
            else
                bar(1, ui.ELEMENT_COLOR[element], 130, ('%d (top)'):fmt(e.points));
            end

            local lines = {};
            if (e.nextAt > 0) then
                table.insert(lines, ('Tier %d at %d points: %s %s.'):fmt(e.tier + 1, e.nextAt, e.nextBonus, e.label));
            else
                table.insert(lines, 'The top tier.');
            end
            local best = h.best[element] or {};
            if (#best > 0) then
                table.insert(lines, 'Worth crafting:');
                for _, b in ipairs(best) do
                    table.insert(lines, '  ' .. piece_line(b));
                end
            end
            tip(table.concat(lines, '\n'));

            theme.col(235);
            imgui.TextColored(e.tier > 0 and COLOR.text or COLOR.faint, ('Tier %d'):fmt(e.tier));
            theme.col(290);
            if (e.tier > 0) then
                imgui.TextColored(COLOR.good, ('%s %s'):fmt(e.bonus, e.label));
            else
                imgui.TextColored(COLOR.faint, ('%s %s at %d'):fmt(e.nextBonus, e.label, e.nextAt));
            end
            imgui.PopID();
        end
    end

    if (#h.chores > 0) then
        imgui.Spacing();
        heading('Moogle chores today');
        for i, c in ipairs(h.chores) do
            imgui.PushID('ch' .. i);
            imgui.TextColored(c.done and COLOR.good or COLOR.text, c.text);
            theme.col(420);
            if (c.done) then
                imgui.TextColored(COLOR.good, 'done');
            elseif (c.need > 1) then
                bar(c.have / c.need, COLOR.gold, 80, ('%d/%d'):fmt(c.have, c.need));
            else
                imgui.TextColored(COLOR.dim, 'to do');
            end
            theme.col(510);
            imgui.TextColored(COLOR.dim, ('%d token%s'):fmt(c.reward, c.reward == 1 and '' or 's'));
            imgui.PopID();
        end
        imgui.TextColored(COLOR.faint, 'Talk to your moogle to hear them; trade it what it asks for. !chores swap <n> swaps one a day.');
    end

    if (#h.sets > 0) then
        imgui.Spacing();
        heading('Furniture sets');
        for i, set in ipairs(h.sets) do
            imgui.PushID('set' .. i);
            local done = set.have >= set.need;
            imgui.TextColored(done and COLOR.gold or COLOR.text, set.name);
            local names = {};
            for _, piece in ipairs(set.pieces) do
                table.insert(names, (piece.placed and '[x] ' or '[ ] ') .. ui.item_name(piece.id));
            end
            local how = set.need < #set.pieces and ('Place any %d of these:\n'):fmt(set.need) or 'Place all of these:\n';
            tip(how .. table.concat(names, '\n'));
            theme.col(150);
            imgui.TextColored(done and COLOR.good or COLOR.dim, ('%d/%d'):fmt(set.have, set.need));
            theme.col(190);
            imgui.TextColored(done and COLOR.good or COLOR.faint, set.text);
            imgui.PopID();
        end
    end

    imgui.Spacing();
    heading('Placed furniture');
    if (#h.placed == 0) then
        imgui.TextColored(COLOR.dim, 'Nothing placed that counts yet. Place furniture in your Mog House, then press Refresh.');
    end
    for i, f in ipairs(h.placed) do
        imgui.PushID('pl' .. i);
        imgui.TextColored(COLOR.text, f.qty > 1 and ('%s x%d'):fmt(ui.item_name(f.id), f.qty) or ui.item_name(f.id));
        theme.col(230);
        local el = h.elements[f.element];
        imgui.TextColored(ui.ELEMENT_COLOR[f.element] or COLOR.dim, el and el.name or '?');
        theme.col(320);
        imgui.TextColored(COLOR.dim, ('%d point%s'):fmt(f.worth * f.qty, f.worth * f.qty == 1 and '' or 's'));
        if (f.craft > 0) then
            theme.col(410);
            imgui.TextColored(COLOR.hq, ('craftable (%s) x%d'):fmt(ui.SHORT[f.craft] or '?', h.mult));
        end
        imgui.PopID();
    end

    imgui.Spacing();
    heading('Worth crafting');
    for element = 1, 8 do
        local best = h.best[element] or {};
        local e = h.elements[element];
        if (#best > 0 and e ~= nil) then
            imgui.TextColored(ui.ELEMENT_COLOR[element], e.name);
            theme.col(90);
            local parts = {};
            for _, b in ipairs(best) do
                table.insert(parts, piece_line(b));
            end
            imgui.TextColored(COLOR.dim, table.concat(parts, ', '));
        end
    end

    imgui.Spacing();
    imgui.TextColored(COLOR.faint, 'Counted when you change zones, or press Refresh. Rearranged your room? Press Refresh.');
end

--[[
* Champions (modules/champions)
--]]
ui.FAMILY_TIERS = { 5, 15, 30 };
ui.FAMILY_PERKS = { 'counted', 'one more family material', '+25% gil' };

function ui.tab_champions(model, state)
    state.on_champions = true;
    local c = model.champions;
    if (c == nil) then
        if (not state.champions_asked) then
            state.champions_asked = true;
            state.request('champions');
        end
        imgui.TextColored(COLOR.dim, state.waiting.champions and 'Asking the server...' or 'No answer from the server yet. Press Refresh.');
        return;
    end

    if (not c.on) then
        imgui.TextColored(COLOR.dim, 'Champion monsters aren\'t on this server (modules/champions).');
        return;
    end

    heading('Your record');
    imgui.TextColored(COLOR.text, ('%d Champions defeated'):fmt(c.kills));
    imgui.SameLine();
    imgui.TextColored(COLOR.gold, ('(Elite %d, Legendary %d)'):fmt(c.elite, c.legendary));
    imgui.TextColored(COLOR.text, 'Trophies');
    theme.col(110);
    imgui.TextColored(COLOR.gold, ('%d'):fmt(c.trophies));
    imgui.SameLine();
    imgui.TextColored(COLOR.dim, '(spend them below with !trophies buy <n>)');
    imgui.TextColored(COLOR.text, 'Your chance');
    theme.col(110);
    local per = c.chance > 0 and math.floor(1000 / c.chance + 0.5) or 0;
    imgui.TextColored(c.lure and COLOR.good or COLOR.text, per > 0 and ('about 1 monster in %d'):fmt(per) or '-');
    if (c.lure) then
        imgui.SameLine();
        imgui.TextColored(COLOR.good, '(a lure is running)');
    end
    tip('A Champion lure from the Everglass Shop or the trophy exchange, Dark furniture in your Mog House\nand the Hunter\'s Hall set all make Champions more likely in your fights.');
    imgui.TextColored(COLOR.faint, 'Ranks: Champion (one affix), Elite (two, double rewards, level 20+), Legendary (three, five times, level 40+).');

    imgui.Spacing();
    heading('Bestiary: affixes');
    imgui.TextColored(COLOR.faint, 'At 10 / 25 / 50 kills: +3 / 6 / 10% attack and magic attack against that affix; from 25, one more trophy.');
    for i, a in ipairs(c.affixes) do
        imgui.PushID('af' .. i);
        imgui.TextColored(a.tier > 0 and COLOR.gold or COLOR.text, a.name);
        tip(a.text ~= '' and ('A %s Champion: %s.'):fmt(a.name, a.text) or nil);
        theme.col(100);
        if (a.nextAt > 0) then
            local from = ({ 0, 10, 25 })[a.tier + 1] or 0;
            bar((a.kills - from) / math.max(1, a.nextAt - from), COLOR.bond, 120, ('%d/%d'):fmt(a.kills, a.nextAt));
        else
            bar(1, COLOR.gold, 120, ('%d (top)'):fmt(a.kills));
        end
        theme.col(230);
        if (a.tier > 0) then
            imgui.TextColored(COLOR.good, ('Tier %d: +%d%%'):fmt(a.tier, a.power));
        else
            imgui.TextColored(COLOR.faint, 'Tier 0');
        end
        theme.col(340);
        imgui.TextColored(a.trophies > 0 and COLOR.text or COLOR.faint, ('%d troph%s'):fmt(a.trophies, a.trophies == 1 and 'y' or 'ies'));
        imgui.PopID();
    end

    imgui.Spacing();
    heading('Bestiary: families');
    if (#c.families == 0) then
        imgui.TextColored(COLOR.dim, 'No Champions defeated yet. Each kill counts toward its family too.');
    end
    for i, f in ipairs(c.families) do
        imgui.PushID('fa' .. i);
        imgui.TextColored(f.tier > 0 and COLOR.gold or COLOR.text, f.name);
        theme.col(100);
        local nextAt = ui.FAMILY_TIERS[f.tier + 1];
        if (nextAt ~= nil) then
            local from = ui.FAMILY_TIERS[f.tier] or 0;
            bar((f.kills - from) / math.max(1, nextAt - from), COLOR.bond, 120, ('%d/%d'):fmt(f.kills, nextAt));
        else
            bar(1, COLOR.gold, 120, ('%d (top)'):fmt(f.kills));
        end
        theme.col(230);
        imgui.TextColored(f.tier > 0 and COLOR.good or COLOR.faint, ('Tier %d%s'):fmt(f.tier, f.tier > 0 and (': ' .. ui.FAMILY_PERKS[f.tier]) or ''));
        tip('Tier 1 at 5 kills, tier 2 at 15 (one more family material when you defeat one), tier 3 at 30 (+25% gil from them).');
        imgui.PopID();
    end

    imgui.Spacing();
    heading('Trophy exchange');
    for _, e in ipairs(c.exchange) do
        imgui.PushID('ex' .. e.id);
        imgui.TextColored(COLOR.dim, ('%d.'):fmt(e.id));
        theme.col(30);
        imgui.TextColored(e.ok and COLOR.text or COLOR.faint, e.label);
        theme.col(280);
        imgui.TextColored(e.ok and COLOR.good or COLOR.faint, e.affix ~= '' and ('%d %s'):fmt(e.cost, e.affix) or ('%d any'):fmt(e.cost));
        tip(e.affix ~= '' and ('Takes %d %s trophies.'):fmt(e.cost, e.affix) or ('Takes %d trophies of any affix (from your biggest piles first).'):fmt(e.cost));
        imgui.PopID();
    end
    imgui.TextColored(COLOR.faint, 'In game: !trophies buy <n>. Also !champions, !champions bestiary and !champions look (your target).');
end

--[[
* Garden (modules/garden_plus)
--]]
ui.GARDEN_ELEMENT = {
    fire = 1, ice = 2, wind = 3, earth = 4, lightning = 5, water = 6, light = 7, dark = 8,
};

-- What raises a plant's strength (gardenutils.cpp: the crystal you feed counts once for itself, and
-- again when it matches the seed's element and the flowerpot's)
ui.GARDEN_SEEDS = {
    { 'Herb seeds', 'wind' }, { 'Grain seeds', 'fire' }, { 'Vegetable seeds', 'earth' }, { 'Fruit seeds', 'water' },
    { 'Cactus stems', 'light' }, { 'Tree cuttings', 'ice' }, { 'Tree saplings', 'dark' }, { 'Wildgrass seeds', 'lightning' },
};
ui.GARDEN_POTS = {
    { 'Porcelain', 'wind' }, { 'Brass', 'fire' }, { 'Earthen', 'earth' }, { 'Ceramic', 'water' },
    { 'Wooden', 'light' }, { 'Arcane', 'dark' },
};

local function element_color(name)
    return ui.ELEMENT_COLOR[ui.GARDEN_ELEMENT[name or ''] or 0] or COLOR.dim;
end

-- "tree sapling: dark > light, Wooden pot" (in feeding order: a tree's extra crystal comes first)
function ui.cross_recipe(c)
    local text = ('%s: %s'):fmt(c.plant, c.crystal);
    if (c.crystal2 ~= '') then
        text = ('%s: %s > %s'):fmt(c.plant, c.crystal2, c.crystal);
    end
    if (c.pot ~= '') then
        text = text .. ', ' .. (c.pot:gsub(' Flowerpot$', '')) .. ' pot';
    end
    return text;
end

local function slice(list, from, to)
    local out = {};
    for i = from, to do
        table.insert(out, list[i]);
    end
    return out;
end

local function element_list(list)
    for i, pair in ipairs(list) do
        if (i > 1) then
            imgui.SameLine();
            imgui.TextColored(COLOR.faint, '|');
            imgui.SameLine();
        end
        imgui.TextColored(COLOR.text, pair[1]);
        imgui.SameLine();
        imgui.TextColored(element_color(pair[2]), pair[2]);
    end
end

ui.POT_STAGE = {
    [0]  = 'Empty',
    [1]  = 'Seeds planted',
    [2]  = 'Sprouting',
    [3]  = 'Sprouting',
    [4]  = 'Wants a crystal',
    [5]  = 'Growing',
    [6]  = 'Growing',
    [7]  = 'Wants a crystal',
    [8]  = 'Nearly grown',
    [9]  = 'Nearly grown',
    [10] = 'Ready to harvest!',
    [11] = 'Wilted',
};

-- "2h 05m", "3d 4h", "45m"
function ui.duration(seconds)
    seconds = math.max(0, math.floor(seconds or 0));
    if (seconds < 60) then
        return 'under a minute';
    end
    local d = math.floor(seconds / 86400);
    local h = math.floor((seconds % 86400) / 3600);
    local m = math.floor((seconds % 3600) / 60);
    if (d > 0) then
        return ('%dd %dh'):fmt(d, h);
    elseif (h > 0) then
        return ('%dh %02dm'):fmt(h, m);
    end
    return ('%dm'):fmt(m);
end

-- A pot's stage label and its colour
function ui.pot_stage(p)
    if (p.step == 0) then
        return 'Empty', COLOR.faint;
    elseif (p.dried) then
        return 'Dried', COLOR.dim;
    elseif (p.step == 10) then
        return 'Ready to harvest!', COLOR.good;
    elseif (p.step == 11) then
        return 'Wilted', COLOR.bad;
    elseif (p.due) then
        return 'Grown since you looked', COLOR.gold;
    elseif (p.warn == 'crystal') then
        return 'Wants a crystal', COLOR.warn;
    end
    return ui.POT_STAGE[p.step] or '?', COLOR.text;
end

-- What to tell about a pot under its row (elapsed: seconds since the server answered)
function ui.pot_notes(p, elapsed)
    local notes = {};
    if (p.step == 0) then
        table.insert(notes, { COLOR.faint, 'Plant seeds in it.' });
        return notes;
    elseif (p.dried) then
        table.insert(notes, { COLOR.faint, 'Dried by your moogle: it won\'t grow any more. Uproot it to plant again.' });
        return notes;
    elseif (p.step == 11) then
        table.insert(notes, { COLOR.bad, 'It wilted (left too long unexamined). Uproot it and plant again.' });
        return notes;
    elseif (p.step == 10) then
        table.insert(notes, { COLOR.good, 'Harvest it in your Mog House.' });
    end

    local fed = {};
    if (p.feed1 ~= '') then table.insert(fed, p.feed1); end
    if (p.feed2 ~= '') then table.insert(fed, p.feed2); end
    if (#fed > 0) then
        table.insert(notes, { COLOR.dim, 'Fed ' .. table.concat(fed, ', then ') .. '.' });
    end

    if (p.due) then
        table.insert(notes, { COLOR.gold, 'It has grown since you last looked: plants only update in your Mog House.' });
    elseif (p.warn == 'crystal') then
        table.insert(notes, { COLOR.warn, 'Feed it a crystal: it waits for one (and feeding counts as examining it).' });
    elseif (p.warn == 'check') then
        local left = p.nextIn >= 0 and math.max(0, p.nextIn - elapsed) or 0;
        table.insert(notes, { COLOR.warn, ('Examine it within %s, or it will wilt.'):fmt(ui.duration(left)) });
    end

    if (p.step >= 1 and p.step <= 9 and not p.due) then
        local parts = {};
        if (p.nextIn >= 0 and p.warn ~= 'crystal') then
            table.insert(parts, 'next stage in ' .. ui.duration(math.max(0, p.nextIn - elapsed)));
        end
        if (p.harvestIn >= 0) then
            table.insert(parts, 'ready in about ' .. ui.duration(math.max(0, p.harvestIn - elapsed)));
        end
        if (#parts > 0) then
            local text = table.concat(parts, ', ');
            table.insert(notes, { COLOR.text, text:sub(1, 1):upper() .. text:sub(2) .. '.' });
        end
    end

    if (p.cross ~= '') then
        table.insert(notes, { COLOR.gold, ('On track for a crossbreed: %s.'):fmt(p.cross) });
    end
    return notes;
end

local function draw_pots(g, elapsed)
    heading('Your flowerpots');
    if (#g.pots == 0) then
        imgui.TextColored(COLOR.dim, 'No flowerpots placed. Place one in your Mog House (first floor), then plant seeds in it.');
        return;
    end
    for i, p in ipairs(g.pots) do
        imgui.PushID('pot' .. i);
        local label, color = ui.pot_stage(p);
        imgui.TextColored(p.step == 10 and COLOR.gold or COLOR.text, ui.item_name(p.pot));
        theme.col(160);
        imgui.TextColored(p.plant ~= '' and COLOR.text or COLOR.faint, p.plant ~= '' and p.plant or '-');
        theme.col(260);
        imgui.TextColored(color, label);
        if (p.step >= 1 and p.step <= 10 and not p.dried) then
            theme.col(430);
            bar(p.progress / p.stages, p.step == 10 and COLOR.good or COLOR.rested, 110, ('%d/%d'):fmt(p.progress, p.stages));
            tip('How far along it is: plants grow in stages.\nTrees (fruit, cactus, cuttings, saplings) have more of them, and two crystal feeds.');
        end
        for _, note in ipairs(ui.pot_notes(p, elapsed)) do
            imgui.SetCursorPosX(20);
            imgui.TextColored(note[1], note[2]);
        end
        imgui.PopID();
    end
    imgui.TextColored(COLOR.faint, 'Times count down from your last Refresh. "Ready in" assumes you feed each crystal when asked.');
end

function ui.tab_garden(model, state)
    state.on_garden = true;
    local g = model.garden;
    if (g == nil) then
        if (not state.garden_asked) then
            state.garden_asked = true;
            state.request('garden');
        end
        imgui.TextColored(COLOR.dim, state.waiting.garden and 'Asking the server...' or 'No answer from the server yet. Press Refresh.');
        return;
    end

    if (not g.on) then
        imgui.TextColored(COLOR.dim, 'Gardening levels aren\'t on this server (modules/garden_plus).');
        return;
    end

    local now = state.now or os.time();
    local at = model.received and model.received.garden or now;
    draw_pots(g, math.max(0, now - at));

    imgui.Spacing();
    heading('Your green thumb');
    imgui.TextColored(COLOR.text, ('Gardening %d'):fmt(g.level));
    theme.col(110);
    if (g.need > 0) then
        bar(g.into / g.need, COLOR.good, 160, ('%d/%d'):fmt(g.into, g.need));
        imgui.SameLine();
        imgui.TextColored(COLOR.dim, ('to level %d'):fmt(g.level + 1));
    else
        bar(1, COLOR.gold, 160, 'mastered');
    end
    tip('Every harvest gives experience: more for each crystal you fed, more for trees,\nand more again for a crossbreed. Every 10 levels the Artisans Guild sends seeds.');

    local rows = {
        { 'More crops',   ('+%d%%'):fmt(g.yield),      'More of the crop at every harvest (the extra goes to your bags).' },
        { 'Seeds back',   ('%d%%'):fmt(g.seedBack),    'The chance your moogle saves you a bag of the same seeds.' },
        { 'Crossbreeds',  ('+%d%%'):fmt(g.crossBonus), 'More chance of a crossbreed (the chances below already include it).' },
        { 'Wilting',      g.wilt > 0 and ('%d days later'):fmt(g.wilt) or 'as usual', 'Plants take this many more Vana\'diel days to wilt, even while you\'re away.\nThe gardening moghancement adds more on top.' },
    };
    for i, r in ipairs(rows) do
        imgui.PushID('gr' .. i);
        imgui.TextColored(COLOR.dim, r[1]);
        theme.col(110);
        imgui.TextColored(COLOR.good, r[2]);
        tip(r[3]);
        imgui.PopID();
    end
    imgui.TextColored(COLOR.faint, ('Everything grows with your level, up to level %d.'):fmt(g.max));

    if (g.hearthCrops >= 0) then
        imgui.Spacing();
        heading('From your Mog House');
        imgui.TextColored(COLOR.text, 'Extra crops');
        theme.col(110);
        if (g.hearthCrops > 0) then
            imgui.TextColored(COLOR.good, ('+%d at every harvest'):fmt(g.hearthCrops));
        else
            imgui.TextColored(COLOR.dim, 'none yet');
        end
        tip('The Gardener\'s Rest furniture set (Porcelain Flowerpot, Brass Flowerpot, Flower Stand): +2.\nA Harmonious Home (every element at tier 1): +1. See the Mog House tab.');
        if (g.treat > 0) then
            imgui.TextColored(COLOR.text, 'Chocobo treats');
            theme.col(110);
            imgui.TextColored(COLOR.good, ('%d%% a harvest'):fmt(g.treat));
            tip('Your moogle sometimes finds Sharug Greens, Azouph Greens or a Vomp Carrot among the leaves.');
        end
    end

    imgui.Spacing();
    heading(('Crossbreeds  (%d of %d found)'):fmt(g.found, g.total));
    imgui.TextColored(COLOR.faint, 'The right plant, crystal and flowerpot can bring a rare crop as well. Each needs a gardening level.');
    for i, c in ipairs(g.crosses) do
        imgui.PushID('cx' .. i);
        if (c.state == 2) then
            imgui.TextColored(COLOR.gold, c.name);
            tip(('%s\nGives %d-%d %s, a %d%% chance at each harvest that fits.'):fmt(ui.cross_recipe(c), c.lo, c.hi, ui.item_name(c.item), c.chance));
        elseif (c.state == 1) then
            imgui.TextColored(COLOR.warn, '???');
            tip(('You were close: %s fed %s, but you need gardening level %d.\nMaybe a second crystal or a flowerpot matters too.'):fmt(c.plant, c.crystal, c.level));
        else
            imgui.TextColored(COLOR.faint, '???');
            tip(('Something grows from %s. Try different crystals and flowerpots.'):fmt(c.plant));
        end

        theme.col(160);
        imgui.TextColored(c.reachable and COLOR.dim or COLOR.bad, ('lv %d'):fmt(c.level));
        if (not c.reachable) then
            tip(('You need gardening level %d.'):fmt(c.level));
        end

        theme.col(210);
        if (c.state == 2) then
            local gives = c.lo == c.hi and ('%d %s'):fmt(c.lo, ui.item_name(c.item)) or ('%d-%d %s'):fmt(c.lo, c.hi, ui.item_name(c.item));
            imgui.TextColored(COLOR.text, gives);
            theme.col(400);
            imgui.TextColored(COLOR.good, ('%d%%'):fmt(c.chance));
            theme.col(445);
            imgui.TextColored(COLOR.dim, ui.cross_recipe(c));
        elseif (c.state == 1) then
            imgui.TextColored(COLOR.warn, ('%s, fed %s... you were close'):fmt(c.plant, c.crystal));
        else
            imgui.TextColored(COLOR.faint, ('something from %s'):fmt(c.plant));
        end
        imgui.PopID();
    end

    imgui.Spacing();
    heading('How gardening works here');
    imgui.TextColored(COLOR.dim, 'A plant grows stronger (better and more crops) when the crystal you feed it matches');
    imgui.TextColored(COLOR.dim, 'its seed\'s element and its flowerpot\'s. Your Mog House\'s strongest furniture aura adds to it.');
    imgui.TextColored(COLOR.text, 'Seeds');
    theme.col(70);
    element_list(slice(ui.GARDEN_SEEDS, 1, 4));
    imgui.SetCursorPosX(70);
    element_list(slice(ui.GARDEN_SEEDS, 5, 8));
    imgui.TextColored(COLOR.text, 'Pots');
    theme.col(70);
    element_list(ui.GARDEN_POTS);
    imgui.TextColored(COLOR.dim, 'Fruit, cactus, cuttings and saplings are trees: they take a second crystal.');
    imgui.TextColored(COLOR.dim, 'Examine your plants now and then: ones left unchecked wilt sooner.');

    imgui.Spacing();
    imgui.TextColored(COLOR.faint, 'In game: !garden, !garden pots and !garden crosses. Harvested or fed something? Press Refresh.');
end

ui.TAB_ORDER = {
    { key = 'recipes', label = 'Recipes',   draw = function(model, state) ui.tab_recipes(model, state); end },
    { key = 'status',  label = 'Status',    draw = function(model, state) ui.tab_status(model, state); end },
    { key = 'hearth',  label = 'Mog House', draw = function(model, state) ui.tab_hearth(model, state); end },
    { key = 'champions', label = 'Champions', draw = function(model, state) ui.tab_champions(model, state); end },
    { key = 'garden',  label = 'Garden',    draw = function(model, state) ui.tab_garden(model, state); end },
};

local function draw_window(model, state)
    if (button('Refresh', true, 'Ask the server again (your skills, bonuses, orders and this list).')) then
        state.refresh = true;
    end
    imgui.SameLine();
    local waiting = state.waiting.status or state.waiting.page or state.waiting.recipe or state.waiting.hearth or state.waiting.garden or state.waiting.champions;
    imgui.TextColored(COLOR.dim, waiting and 'Asking...' or (state.updated_text or ''));

    state.on_hearth = false;
    state.on_garden = false;
    state.on_champions = false;
    if (imgui.BeginTabBar('##cb_tabs')) then
        -- A tab asked for (/craft status, an order clicked last frame) is selected once;
        -- one asked for while drawing this frame waits for the next
        local want = state.tab_recipes and 'recipes' or state.open_tab;
        state.tab_recipes, state.open_tab = nil, nil;
        for _, t in ipairs(ui.TAB_ORDER) do
            local flags = 0;
            if (want == t.key) then
                flags = ImGuiTabItemFlags_SetSelected or 0;
            end
            if (imgui.BeginTabItem(t.label, nil, flags)) then
                begin_child('##tab_' .. t.key, { 0, 0 }, false);
                local mark = snapshot();
                local ok, err = pcall(t.draw, model, state);
                if (not ok) then
                    -- Close what the tab left open, then say what went wrong (once in chat)
                    unwind(mark);
                    err = tostring(err);
                    imgui.TextColored(COLOR.bad, 'This tab ran into a problem and stopped drawing:');
                    wrapped_text(err);
                    imgui.TextColored(COLOR.dim, 'Refresh to try again. Please pass this message on.');
                    if (state.last_error ~= err) then
                        state.last_error = err;
                        print('[craftbook] ' .. t.label .. ' tab: ' .. err);
                    end
                end
                imgui.EndChild();
                imgui.EndTabItem();
            end
        end
        imgui.EndTabBar();
    end
end

--[[
* Draws the window. Returns false when the user closed it. Whatever goes wrong inside, the window
* and everything opened in it are closed again before this returns.
--]]
function ui.render(model, state)
    local open = { true };
    local mark = snapshot();

    if (theme.begin_window('Craftbook', open, { 800, 540 })) then
        local ok, err = pcall(draw_window, model, state);
        if (not ok) then
            unwind(mark);
            err = tostring(err);
            if (state.last_error ~= err) then
                state.last_error = err;
                print('[craftbook] ' .. err);
            end
        end
    end
    unwind(mark);
    theme.end_window();

    return open[1];
end

return ui;
