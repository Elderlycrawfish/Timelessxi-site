--[[
* Timeless XI UI fonts for Ashita add-ons: the same typefaces as https://timelessxi.gg
*   Inter               body text, labels, numbers   (site: --sans, weights 400 / 500 / 600)
*   Cormorant Garamond  site headings (weights 500 / 600, italic 500)
*   Raleway / Montserrat SemiBold  title choices for the add-ons (role 'title'; default Raleway; also Inter,
*                       Cormorant, or Ashita's own font)
* Files: addons/libs/timeless/fonts/ (Latin subsets, SIL Open Font License - see the OFL-*.txt files).
*
* Usage (ImGui 1.92 in Ashita: fonts have no fixed size; PushFont(font, size) picks the size):
*   local UF = require('timeless.ui_fonts');
*   UF.load(imgui);                     -- once, e.g. in the 'load' event; returns true when the fonts are in
*   imgui.PushFont(UF.get('body'), 15); ... imgui.PopFont();
*   imgui.PushFont(UF.get('serif'), UF.size('serif', 20)); dl:AddText({ x, y }, colour, 'Title'); imgui.PopFont();
*   UF.width(imgui, 'serif', 20, 'Title')   -- text width in that font and size
* Only select fonts with PushFont: AddText(font, ...) / ImFont:CalcTextSizeA crashed the client (2026-11-12).
* If loading fails, UF.get() returns nil and callers should keep ImGui's default font.
--]]

local M = { tried = false, loaded = false, fonts = {}, error = nil };

M.FILES = {
    body         = 'Inter-Regular.ttf',
    medium       = 'Inter-Medium.ttf',
    bold         = 'Inter-SemiBold.ttf',
    serif        = 'CormorantGaramond-Medium.ttf',
    serif_bold   = 'CormorantGaramond-SemiBold.ttf',
    serif_italic = 'CormorantGaramond-MediumItalic.ttf',
    raleway      = 'Raleway-SemiBold.ttf',      -- lining figures baked in (Raleway defaults to old-style numbers)
    montserrat   = 'Montserrat-SemiBold.ttf',
    raleway_reg  = 'Raleway-Regular.ttf',       -- (lining figures baked in too)
    montserrat_reg = 'Montserrat-Regular.ttf',
};

-- Text font (body text, labels): one shared choice like the title font
-- (saved in config\addons\timeless_text_font.txt). Roles 'body' and 'medium' resolve to it.
M.TEXT_CHOICES = { inter = 'body', raleway = 'raleway_reg', montserrat = 'montserrat_reg', cormorant = 'serif', ashita = 'default' };
M.TEXT_ORDER   = { 'inter', 'raleway', 'montserrat', 'cormorant', 'ashita' };
M.TEXT_DEFAULT = 'inter';
M.text = M.TEXT_DEFAULT;
M.TEXT_SCALE   = { inter = 1.0, raleway = 1.05, montserrat = 0.95, cormorant = 1.18, ashita = 1.0 };

-- Title font: one choice shared by every Timeless add-on (saved in config\addons\timeless_title_font.txt).
-- Role 'title' resolves to the chosen face.
M.TITLE_CHOICES = { raleway = 'raleway', montserrat = 'montserrat', inter = 'bold', cormorant = 'serif_bold', ashita = 'default' };
M.TITLE_ORDER   = { 'raleway', 'montserrat', 'inter', 'cormorant', 'ashita' };
M.TITLE_LABEL   = { raleway = 'Raleway', montserrat = 'Montserrat', inter = 'Inter', cormorant = 'Cormorant', ashita = 'Ashita' };
M.default_font  = nil;   -- Ashita's own ImGui font, captured at the start of a frame (capture_default)
M.TITLE_DEFAULT = 'raleway';
M.title = M.TITLE_DEFAULT;
-- Size factor per face so titles look the same size whichever is picked (Inter = 1).
M.TITLE_SCALE = { raleway = 1.06, montserrat = 0.95, inter = 1.0, cormorant = 1.18, ashita = 1.0 };

-- Remember Ashita's default ImGui font. Call at the start of d3d_present, before any PushFont.
function M.capture_default(imgui)
    if (M.default_font ~= nil or imgui == nil or imgui.GetFont == nil) then return; end
    local ok, f = pcall(imgui.GetFont);
    if (ok and f ~= nil) then M.default_font = f; end
end

-- Display name of the current (or a given) title choice.
function M.title_label(name) return M.TITLE_LABEL[name or M.title] or (name or M.title); end

-- Cormorant Garamond runs small for its point size; this keeps headings in step with Inter text.
M.SERIF_SCALE = 1.18;

local function install_dir()
    local base = '';
    pcall(function () base = AshitaCore:GetInstallPath(); end);
    if (base ~= '' and base:sub(-1) ~= '\\' and base:sub(-1) ~= '/') then base = base .. '\\'; end
    return base;
end
local function title_file() return install_dir() .. 'config\\addons\\timeless_title_font.txt'; end
local function text_file() return install_dir() .. 'config\\addons\\timeless_text_font.txt'; end

local function read_choice(file, choices)
    local f = io.open(file, 'r');
    if (f == nil) then return nil; end
    local v = (f:read('*l') or ''):lower():gsub('%s', '');
    f:close();
    if (choices[v] ~= nil) then return v; end
    return nil;
end
local function read_title()
    M.title = read_choice(title_file(), M.TITLE_CHOICES) or M.title;
    M.text  = read_choice(text_file(), M.TEXT_CHOICES) or M.text;
end

-- Pick the text face (inter / raleway / montserrat / cormorant / ashita) and save it for every Timeless add-on.
function M.set_text(name)
    name = (name or ''):lower();
    if (M.TEXT_CHOICES[name] == nil) then return false; end
    M.text = name;
    local f = io.open(text_file(), 'w');
    if (f ~= nil) then f:write(name, '\n'); f:close(); end
    return true;
end
function M.text_label(name) return M.TITLE_LABEL[name or M.text] or (name or M.text); end

-- Pick the title face (raleway / montserrat / inter / cormorant / ashita) and save it for every Timeless add-on.
function M.set_title(name)
    name = (name or ''):lower();
    if (M.TITLE_CHOICES[name] == nil) then return false; end
    M.title = name;
    local f = io.open(title_file(), 'w');
    if (f ~= nil) then f:write(name, '\n'); f:close(); end
    return true;
end

local function folder()
    local base = '';
    pcall(function () base = AshitaCore:GetInstallPath(); end);
    if (base ~= '' and base:sub(-1) ~= '\\' and base:sub(-1) ~= '/') then base = base .. '\\'; end
    return base .. 'addons\\libs\\timeless\\fonts\\';
end

function M.load(imgui)
    if (M.tried) then return M.loaded; end
    M.tried = true;
    if (imgui == nil or imgui.AddFontFromFileTTF == nil) then
        M.error = 'this Ashita has no AddFontFromFileTTF';
        return false;
    end
    local dir = folder();
    for key, file in pairs(M.FILES) do
        local f = io.open(dir .. file, 'rb');
        if (f ~= nil) then
            f:close();
            local ok, font = pcall(imgui.AddFontFromFileTTF, dir .. file, 32);
            if (ok and font ~= nil) then
                M.fonts[key] = font;
            elseif (M.error == nil) then
                M.error = ('could not load %s (%s)'):format(file, tostring(font));
            end
        elseif (M.error == nil) then
            M.error = 'missing ' .. dir .. file;
        end
    end
    M.loaded = M.fonts.body ~= nil;
    read_title();
    return M.loaded;
end

-- The font for a role (falls back to the body font, or nil when nothing loaded).
function M.get(name)
    if (name == 'title') then
        local role = M.TITLE_CHOICES[M.title] or 'bold';
        if (role == 'default') then return M.default_font or M.fonts.bold or M.fonts.body; end
        return M.fonts[role] or M.fonts.bold or M.fonts.body;
    end
    if (name == 'body' or name == 'medium') then
        local role = M.TEXT_CHOICES[M.text] or 'body';
        if (role == 'default') then return M.default_font or M.fonts.body; end
        if (role == 'body' and name == 'medium') then role = 'medium'; end   -- Inter has a Medium weight
        return M.fonts[role] or M.fonts.body;
    end
    return M.fonts[name] or M.fonts.body;
end

-- Size to use for a role: serif faces are scaled up a little to match Inter's x-height.
function M.size(name, size)
    if (name == 'title') then return size * (M.TITLE_SCALE[M.title] or 1); end
    if (name == 'body' or name == 'medium') then return size * (M.TEXT_SCALE[M.text] or 1); end
    if (name ~= nil and name:find('^serif') and M.fonts[name] ~= nil) then return size * M.SERIF_SCALE; end
    return size;
end

-- Width of a text in a font role and size: PushFont + CalcTextSize + PopFont (needs the ImGui table).
-- Never call ImFont:CalcTextSizeA or AddText(font, ...) directly: in Ashita that crashed with an access violation.
function M.width(imgui, name, size, text)
    local font = M.get(name);
    if (font == nil or imgui == nil) then return nil; end
    imgui.PushFont(font, M.size(name, size));
    local ok, w = pcall(imgui.CalcTextSize, text);
    imgui.PopFont();
    if (ok and type(w) == 'number') then return w; end
    return nil;
end

return M;
