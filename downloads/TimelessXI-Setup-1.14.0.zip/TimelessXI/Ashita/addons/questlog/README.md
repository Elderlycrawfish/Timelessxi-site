# Journal (questlog)

Your missions and quests, and what to do next, in one window. Open it with `/ql` (or `/journal`), or from the **Journal** card in TimelessMenu (`/tm`).

## Tabs

| Tab | Shows |
|---|---|
| Missions | Your nation, Rise of the Zilart, Chains of Promathia and Treasures of Aht Urhgan: the current mission (code and name), how many you've finished, and the next step. If you have no nation mission, the next one and whether a gate guard offers it yet. Storylines you can't start yet say what they need (rank 6 for Zilart, a Boarding Permit for Aht Urhgan). |
| Quests | The server's custom quests in progress, with the next step and counts like (3/10), then the ones you can start on your current job. Same list as `!journal`. |
| Retail | Retail quests you've accepted, by area, and how many you've finished. |

**Spoilers:** with **Show full steps** off (the default), missions only say where to go next ("Head to Zeruhn Mines."). Each storyline has a **Show step** button that reveals its full step for this session. `/ql spoilers` toggles the setting.

**Tracker:** a small panel that keeps each storyline's next step on screen (the **Tracker** checkbox, or `/ql tracker`).

**Best guess:** mission steps are matched on your mission status. When the server doesn't recognise your exact step (some missions pick an NPC at random), it shows the nearest step and says so.

## Updating

The Journal asks the server when it opens, a few seconds after you zone, and after a cutscene or conversation ends, while the window or tracker is shown. **Refresh** (or `/ql update`) asks at once. The request travels in a packet, not chat, and the answer lines are hidden from the chat log.

## Commands

| Command | Does |
|---|---|
| `/ql` | Show or hide the Journal (`/journal`, `/questlog` also work) |
| `/ql missions`, `/ql quests`, `/ql retail` | Open on a tab |
| `/ql tracker` | Show or hide the tracker |
| `/ql spoilers` | Show or hide full mission steps |
| `/ql update` | Ask for fresh data now |

## Needs

The server's `questlog` module, and the companions module's addon packet (`companions_commands.lua` with `xi.addonActions`). Without them the window says it got no answer. Players without the addon can type `!questlog` (or `!ql`) for the missions in chat.

## Files

- `questlog.lua`: events, commands, when to ask.
- `protocol.lua`: reads the `QL1|...` feed (no game code; tested on its own).
- `ui.lua`: the window and the tracker.
- `action.lua`: builds the request packet.
- `theme.lua`: the shared TimelessXI look (same as the other addons).
- `tests/addon_test.lua`: `luajit tests/addon_test.lua` from this folder.
