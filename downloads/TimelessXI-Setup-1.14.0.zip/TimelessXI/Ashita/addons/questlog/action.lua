--[[
* questlog - action.lua
*
* Asks the server for the quest log without using chat. The request rides the same addon packet as
* companionmanager (a 0x0B5 packet whose text starts with \x7F"CM|"): the companions module takes it
* and consumes it, so nothing shows in chat. "ql data" is handed to the questlog module.
--]]

local action = {};

action.PACKET = 0x0B5;
action.MARKER = '\127CM|';
action.MAX    = 120;

function action.build(text)
    local payload = action.MARKER .. string.sub((text or ''):gsub('[^\32-\126]', ''), 1, action.MAX);
    local size = 4 + 2 + #payload + 1; -- + NUL
    size = math.ceil(size / 4) * 4;

    local packet = { action.PACKET % 256, (size / 4) * 2 + math.floor(action.PACKET / 256), 0, 0, 0, 0 };
    for i = 1, #payload do
        packet[#packet + 1] = string.byte(payload, i);
    end
    while (#packet < size) do
        packet[#packet + 1] = 0;
    end
    return packet;
end

function action.send(text)
    AshitaCore:GetPacketManager():AddOutgoingPacket(action.PACKET, action.build(text));
end

return action;
