--[[
* questlog - your missions and quests, and what to do next, in one window (the Journal).
*
* Tabs:
*   Missions   your nation, Rise of the Zilart, Chains of Promathia and Treasures of Aht Urhgan:
*              the current mission, where to go and the next step
*   Quests     the server's custom quests in progress (with the next step) and those you can start
*   Retail     retail quests you've accepted
*
* Spoilers: with "Show full steps" off (the default), missions only say where to go next. Each
* storyline has a "Show step" button to reveal its step for this session.
*
* The tracker is a small panel that keeps your current missions on screen.
*
* The window asks the server for your progress when it opens, after you zone, and after a cutscene
* or conversation ends (while the window or tracker is shown). The request uses a packet, not chat,
* and the answer lines are hidden from the chat log. Needs the server's questlog module.
*
* Commands:
*   /ql                   show or hide the Journal (/journal and /questlog also work)
*   /ql missions|quests|retail   open on a tab
*   /ql tracker           show or hide the tracker
*   /ql spoilers          show or hide full mission steps
*   /ql update            ask for fresh data now
--]]

addon.name    = 'questlog';
addon.author  = 'TimelessXI';
addon.version = '1.0';
addon.desc    = 'Journal: your missions and quests, and what to do next.';
addon.link    = '';

require('common');
local chat     = require('chat');
local settings = require('settings');
local action   = require('action');
local protocol = require('protocol');
local ui       = require('ui');

local defaults = T{
    spoilers = false,
    tracker  = false,
};

local ql = {
    settings = settings.load(defaults),
    model    = protocol.new_model(),
    visible  = false,
    asked_at = 0,
    ask_at   = nil,  -- os.clock() of a scheduled ask
    zone     = nil,
};

ql.state = {
    settings = ql.settings,
    revealed = {},
    waiting  = false,
};

local function msg(text)
    print(chat.header(addon.name):append(chat.message(text)));
end

local function in_game()
    local party = AshitaCore:GetMemoryManager():GetParty();
    return party ~= nil and party:GetMemberServerId(0) ~= 0;
end

local function ask()
    if (not in_game()) then
        return;
    end
    ql.asked_at = os.clock();
    ql.state.waiting = true;
    action.send('ql data');
end
ql.state.ask = ask;
ql.state.save = function()
    settings.save();
end

local function wanted()
    return ql.visible or ql.settings.tracker;
end

-- Ask in a few seconds (several events in a row only ask once)
local function ask_soon(seconds)
    if (wanted()) then
        local at = os.clock() + seconds;
        if (ql.ask_at == nil or at < ql.ask_at) then
            ql.ask_at = at;
        end
    end
end

settings.register('settings', 'settings_update', function(s)
    if (s ~= nil) then
        ql.settings = s;
        ql.state.settings = s;
    end
end);

ashita.events.register('unload', 'unload_cb', function()
    settings.save();
end);

-- Read the feed and hide it from the chat log
ashita.events.register('text_in', 'text_in_cb', function(e)
    local line = protocol.extract(e.message_modified) or protocol.extract(e.message);
    if (line == nil) then
        return;
    end
    e.blocked = true;
    if (protocol.feed(ql.model, line, os.time())) then
        ql.state.waiting = false;
        ql.state.updated_text = 'Updated ' .. os.date('%I:%M %p');
    end
end);

-- A cutscene or conversation ended (0x052 releases the player): progress may have changed
ashita.events.register('packet_in', 'packet_in_cb', function(e)
    if (e.id == 0x052) then
        ask_soon(2.0);
    end
end);

local TABS = { missions = true, quests = true, retail = true };

ashita.events.register('command', 'command_cb', function(e)
    local args = e.command:args();
    if (#args == 0 or not (args[1]:any('/ql') or args[1]:any('/journal') or args[1]:any('/questlog'))) then
        return;
    end
    e.blocked = true;

    local sub = (args[2] or ''):lower();
    if (sub == '') then
        ql.visible = not ql.visible;
        if (ql.visible) then
            ask();
        end
    elseif (TABS[sub]) then
        ql.state.open_tab = sub;
        if (not ql.visible) then
            ql.visible = true;
            ask();
        end
    elseif (sub == 'tracker') then
        ql.settings.tracker = not ql.settings.tracker;
        settings.save();
        if (ql.settings.tracker) then
            ask();
        end
        msg(ql.settings.tracker and 'Tracker on.' or 'Tracker off.');
    elseif (sub == 'spoilers') then
        ql.settings.spoilers = not ql.settings.spoilers;
        settings.save();
        msg(ql.settings.spoilers and 'Full mission steps shown.' or 'Missions only say where to go next.');
    elseif (sub == 'update' or sub == 'refresh') then
        ask();
    else
        msg('/ql | /ql missions|quests|retail | /ql tracker | /ql spoilers | /ql update');
    end
end);

ashita.events.register('d3d_present', 'present_cb', function()
    if (not in_game()) then
        return;
    end

    local now = os.clock();

    -- Zoning: ask once the new zone has settled
    local party = AshitaCore:GetMemoryManager():GetParty();
    local zone = party and party:GetMemberZone(0) or 0;
    if (ql.zone ~= nil and zone ~= 0 and zone ~= ql.zone) then
        ask_soon(4.0);
    end
    if (zone ~= 0) then
        ql.zone = zone;
    end

    if (ql.ask_at ~= nil and now >= ql.ask_at) then
        ql.ask_at = nil;
        if (wanted()) then
            ask();
        end
    end

    -- First data for the tracker after logging in
    if (ql.settings.tracker and not ql.model.loaded and not ql.state.waiting and now - ql.asked_at > 15) then
        ask();
    end

    -- No answer (a server without the questlog module): stop showing "Updating..."
    if (ql.state.waiting and now - ql.asked_at > 5) then
        ql.state.waiting = false;
    end

    if (ql.settings.tracker) then
        ui.render_tracker(ql.model, ql.state);
    end

    if (ql.visible and not ui.render(ql.model, ql.state)) then
        ql.visible = false;
    end
end);
