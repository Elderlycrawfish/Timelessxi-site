--[[
* questlog - ui.lua: the Journal window and the small tracker.
*
* state (from questlog.lua):
*   settings   { spoilers = bool, tracker = bool, ... } (saved)
*   revealed   storyline log -> true: steps shown in full this session even with spoilers off
*   ask()      asks the server for fresh data
*   updated_text, waiting
--]]

require('common');
local imgui    = require('imgui');
local theme    = require('theme');
local protocol = require('protocol');

local ui = {};

local COLOR = theme.colors({
    done   = { 0.55, 0.80, 0.55, 1.0 },
    accept = { 0.95, 0.80, 0.45, 1.0 },
    locked = { 0.85, 0.55, 0.50, 1.0 },
});

local WIDTH = 560;

local STATE_TEXT = {
    active = 'In progress',
    accept = 'Next mission',
    locked = 'Not yet available',
    done   = 'Complete',
    none   = 'Not started',
};

local function wrapped(color, text)
    imgui.PushTextWrapPos(WIDTH - 40);
    if (color ~= nil) then
        imgui.TextColored(color, text);
    else
        imgui.TextWrapped(text);
    end
    imgui.PopTextWrapPos();
end

-- Where-only text when spoilers are hidden: "Head to <zone>." (a step with no zone shows a generic line)
function ui.step_text(step, full)
    if (full or step.w == nil or step.w == '') then
        return step.t;
    end
    return ('Head to %s.'):fmt(step.w);
end

local function story_full(state, story)
    return state.settings.spoilers or state.revealed[story.log] == true or story.state ~= 'active';
end

local function draw_story(state, story)
    theme.card('##story' .. tostring(story.log), function()
        imgui.TextColored(COLOR.gold, story.story or '');
        imgui.SameLine();
        local of = tonumber(story.of) or 0;
        if (of > 0) then
            imgui.TextColored(COLOR.faint, ('%d / %d missions'):fmt(tonumber(story.num) or 0, of));
        end

        local stateColor = (story.state == 'done' and COLOR.done) or (story.state == 'accept' and COLOR.accept)
            or (story.state == 'locked' and COLOR.locked) or COLOR.dim;
        local heading = (story.code ~= nil and story.code ~= '') and ('%s  %s'):fmt(story.code, story.title or '') or (story.title or '');
        if (heading ~= '') then
            imgui.Text(heading);
            imgui.SameLine();
        end
        imgui.TextColored(stateColor, STATE_TEXT[story.state] or '');

        local full = story_full(state, story);
        local steps = protocol.steps_of(story);
        for i, step in ipairs(steps) do
            local text = ui.step_text(step, full);
            wrapped(nil, (#steps > 1 and ('%d. '):fmt(i) or '') .. text);
        end

        if (story.guess and story.state == 'active') then
            wrapped(COLOR.faint, 'Best guess: your exact step wasn\'t recognised, so this is the nearest one.');
        end

        if (not full and #steps > 0) then
            if (theme.button('Show step##' .. tostring(story.log), nil, true, 'Shows the full step for this storyline (this session only). Turn on "Show full steps" to always see them.')) then
                state.revealed[story.log] = true;
            end
        end
    end, WIDTH);
    imgui.Spacing();
end

local function draw_missions(model, state)
    if (#model.stories == 0) then
        wrapped(COLOR.dim, 'No missions yet.');
        return;
    end
    for _, story in ipairs(model.stories) do
        draw_story(state, story);
    end
end

local function draw_quests(model, state)
    local active, available = {}, {};
    for _, q in ipairs(model.quests) do
        table.insert(q.state == 'active' and active or available, q);
    end

    local c = model.counts or {};
    theme.section('In progress', (tonumber(c.qtotal) or 0) > 0 and ('%d of %d finished'):fmt(tonumber(c.qdone) or 0, tonumber(c.qtotal) or 0) or nil);
    if (#active == 0) then
        wrapped(COLOR.dim, 'Nothing in progress.');
    end
    for _, q in ipairs(active) do
        local name = (q.job ~= nil and q.job ~= '') and ('[%s] %s'):fmt(q.job, q.name) or q.name;
        imgui.TextColored(COLOR.gold, name);
        wrapped(nil, (q.text ~= nil and q.text ~= '') and q.text or 'Talk to the quest giver.');
        imgui.Spacing();
    end

    theme.section('You can start', 'on your current job');
    if (#available == 0) then
        wrapped(COLOR.dim, 'Nothing new for this job right now.');
    end
    for _, q in ipairs(available) do
        local name = (q.job ~= nil and q.job ~= '') and ('[%s] %s'):fmt(q.job, q.name) or q.name;
        imgui.TextColored(COLOR.text or COLOR.gold, name);
        wrapped(COLOR.dim, q.text or '');
        imgui.Spacing();
    end
end

local function draw_retail(model, state)
    local c = model.counts or {};
    theme.section('Accepted', ('%d finished'):fmt(tonumber(c.rdone) or 0));
    if (#model.retail == 0) then
        wrapped(COLOR.dim, 'No retail quests in progress.');
        return;
    end
    local last = nil;
    for _, q in ipairs(model.retail) do
        if (q.area ~= last) then
            imgui.Spacing();
            imgui.TextColored(COLOR.gold, q.area or '');
            last = q.area;
        end
        imgui.BulletText(q.name or '');
    end
    imgui.Spacing();
    wrapped(COLOR.faint, 'Steps for retail quests aren\'t tracked yet: the game\'s own quest log has their descriptions.');
end

local TABS = { { 'missions', 'Missions' }, { 'quests', 'Quests' }, { 'retail', 'Retail' } };

--[[
* Draws the window. Returns false when the user closed it.
--]]
function ui.render(model, state)
    local open = { true };
    imgui.SetNextWindowPos({ 160, 140 }, ImGuiCond_FirstUseEver);
    local shown = theme.begin_window('Journal##questlog', open, { WIDTH + 30, 520 }, ImGuiWindowFlags_NoCollapse);
    if (shown) then
        if (theme.button('Refresh', 'primary', not state.waiting, 'Ask the server for your latest progress.')) then
            state.ask();
        end
        imgui.SameLine();
        local spoil = { state.settings.spoilers == true };
        if (imgui.Checkbox('Show full steps', spoil)) then
            state.settings.spoilers = spoil[1];
            state.save();
        end
        theme.tip('Off: missions only say where to go next, so the story isn\'t spoiled. "Show step" reveals one.');
        imgui.SameLine();
        local track = { state.settings.tracker == true };
        if (imgui.Checkbox('Tracker', track)) then
            state.settings.tracker = track[1];
            state.save();
        end
        theme.tip('A small panel with your current missions, kept on screen.');
        imgui.SameLine();
        imgui.TextColored(COLOR.faint, state.waiting and 'Updating...' or (state.updated_text or ''));

        if (not model.loaded) then
            imgui.Spacing();
            wrapped(COLOR.dim, state.waiting and 'Asking the server...' or 'No answer from the server yet. Press Refresh (the server needs the questlog module).');
        elseif (imgui.BeginTabBar('##questlog_tabs')) then
            for _, tab in ipairs(TABS) do
                local flags = 0;
                if (state.open_tab == tab[1]) then
                    flags = ImGuiTabItemFlags_SetSelected;
                end
                if (imgui.BeginTabItem(tab[2] .. '##ql', nil, flags)) then
                    if (state.open_tab == tab[1]) then
                        state.open_tab = nil;
                    end
                    if (tab[1] == 'missions') then
                        draw_missions(model, state);
                    elseif (tab[1] == 'quests') then
                        draw_quests(model, state);
                    else
                        draw_retail(model, state);
                    end
                    imgui.EndTabItem();
                end
            end
            imgui.EndTabBar();
        end
    end
    theme.end_window();
    return open[1];
end

--[[
* The tracker: one line per storyline in progress, plus custom quests in progress.
--]]
function ui.render_tracker(model, state)
    if (not model.loaded) then
        return;
    end

    imgui.SetNextWindowPos({ 20, 300 }, ImGuiCond_FirstUseEver);
    local pushed = theme.push();
    imgui.PushStyleColor(ImGuiCol_WindowBg, { 0.06, 0.07, 0.09, 0.60 });
    local flags = bit.bor(ImGuiWindowFlags_NoTitleBar, ImGuiWindowFlags_AlwaysAutoResize, ImGuiWindowFlags_NoFocusOnAppearing,
        ImGuiWindowFlags_NoScrollbar);
    if (imgui.Begin('##questlog_tracker', { true }, flags)) then
        imgui.PushTextWrapPos(360);
        local any = false;
        for _, story in ipairs(model.stories) do
            if (story.state == 'active' or story.state == 'accept') then
                any = true;
                imgui.TextColored(COLOR.gold, ('%s %s'):fmt(story.story or '', story.code or ''));
                local steps = protocol.steps_of(story);
                if (steps[1] ~= nil) then
                    imgui.TextColored(COLOR.dim, ui.step_text(steps[1], story_full(state, story)));
                end
            end
        end
        local active = 0;
        for _, q in ipairs(model.quests) do
            if (q.state == 'active') then
                active = active + 1;
            end
        end
        if (active > 0) then
            any = true;
            imgui.TextColored(COLOR.faint, ('%d custom quest%s in progress (/ql quests)'):fmt(active, active == 1 and '' or 's'));
        end
        if (not any) then
            imgui.TextColored(COLOR.faint, 'Nothing in progress.');
        end
        imgui.PopTextWrapPos();
    end
    imgui.End();
    imgui.PopStyleColor(1);
    theme.pop(pushed);
end

return ui;
