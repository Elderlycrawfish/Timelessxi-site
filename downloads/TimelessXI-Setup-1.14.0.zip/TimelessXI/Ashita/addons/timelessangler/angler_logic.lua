--[[
* Timeless Angler - calculations (no Ashita calls in here, so it can be tested on its own).
*
* Everything mirrors the Timeless XI server:
*   src/map/utils/fishingutils.cpp (Phoenix core + TIMELESS patches) and
*   modules/timeless_fishing/cpp/timeless_fishing.cpp (bar game, schools of fish).
* Fishing area / pool logic is based on GoFish by StrixNivea (BSD licence), rewritten
* to follow this server's code.
--]]

local L = {};

local floor, cos, max, min, abs, sqrt = math.floor, math.cos, math.max, math.min, math.abs, math.sqrt;
local function clamp(x, lo, hi) if x < lo then return lo elseif x > hi then return hi end return x; end
L.clamp = clamp;

-- Flag test without the bit library (small positive flags only).
local function has(flags, f) return floor((flags or 0) / f) % 2 == 1; end
L.has = has;

----------------------------------------------------------------------------
-- Vana'diel time and the moon
----------------------------------------------------------------------------
L.WEEKDAYS = { [0] = 'Firesday', 'Earthsday', 'Watersday', 'Windsday', 'Iceday', 'Lightningday', 'Lightsday', 'Darksday' };
L.MONTHS   = { 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec' };

-- Server moon buckets (fishingutils GetMoonPhase): 0 new ... 7 waning crescent.
L.MOON_NEW, L.MOON_FULL = 0, 4;
L.MOON_NAMES = { [0] = 'New Moon', 'Waxing Crescent', 'First Quarter', 'Waxing Gibbous', 'Full Moon', 'Waning Gibbous', 'Last Quarter', 'Waning Crescent' };

-- Date from the client's raw Vana'diel timestamp (same maths as Ashita's clock add-ons).
function L.vana_date(raw, day_offset)
    local ts  = (raw + 92514960) * 25;
    local day = floor(ts / 86400) + (day_offset or 0);
    local mphase = (day + 26) % 84;
    local pct = abs(((42 - mphase) * 100) / 42);
    local dir;
    if (mphase == 42 or mphase == 0) then dir = 0;           -- turning
    elseif (mphase < 42) then dir = 1;                        -- waning
    else dir = 2; end                                         -- waxing
    local d = {
        raw        = raw,
        weekday    = day % 8,
        hour       = floor(ts / 3600) % 24,
        minute     = floor(ts / 60) % 60,
        day        = (day % 30) + 1,
        month      = floor((day % 360) / 30) + 1,
        year       = floor(day / 360),
        moon_pct   = floor(pct + 0.5),
        moon_dir   = dir,
        day_frac   = (ts % 86400) / 86400,                    -- how far through the Vana'diel day
    };
    d.moon = L.moon_bucket(d.moon_pct, d.moon_dir);
    return d;
end

-- fishingutils::GetMoonPhase, exactly (gaps fall back to 0 = New Moon, as on the server).
function L.moon_bucket(phase, direction)
    if (phase <= 5 or (phase <= 10 and direction == 1)) then return 0; end
    if (phase >= 7 and phase <= 38 and direction == 2) then return 1; end
    if (phase >= 40 and phase <= 55 and direction == 2) then return 2; end
    if (phase >= 57 and phase <= 88 and direction == 2) then return 3; end
    if (phase >= 95 or (phase >= 90 and direction == 2)) then return 4; end
    if (phase >= 62 and phase <= 93 and direction == 1) then return 5; end
    if (phase >= 45 and phase <= 60 and direction == 1) then return 6; end
    if (phase >= 12 and phase < 43 and direction == 1) then return 7; end
    return 0;
end

-- Real minutes until the moon next turns `bucket` (1 Vana'diel day = 57.6 real minutes). nil = now.
function L.next_moon(raw, bucket)
    local now = L.vana_date(raw);
    if (now.moon == bucket) then return nil; end
    for d = 1, 84 do
        if (L.vana_date(raw, d).moon == bucket) then
            return (d - now.day_frac) * 57.6;
        end
    end
    return nil;
end

-- Real minutes the current bucket still lasts.
function L.moon_left(raw)
    local now = L.vana_date(raw);
    for d = 1, 84 do
        if (L.vana_date(raw, d).moon ~= now.moon) then return (d - now.day_frac) * 57.6; end
    end
    return 0;
end

----------------------------------------------------------------------------
-- Catch patterns (fishingutils.h)
----------------------------------------------------------------------------
local function cosp(x, a, b) return clamp(0.5 * cos(a * x + b) + 0.5, 0, 1); end
local HOUR = { [1] = function (x) return cosp(x, 0.82, 0.16); end, [5] = function (x) return cosp(x, 0.60, 3.50); end,
               [6] = function (x) return cosp(x, 0.53, 0.00); end, [7] = function (x) return cosp(x, 0.23, 3.53); end };
local MOON = { [1] = function (x) return cosp(x, 1.75, 0.10); end, [2] = function (x) return cosp(x, 1.75, 3.30); end,
               [3] = function (x) return clamp(1 - x / 7, 0, 1); end,
               [4] = function (x) return cosp(x, 0.90, 3.14); end, [5] = function (x) return cosp(x, 0.90, 0.00); end };
local MONTH = { [1] = { 0.40, -1.60 }, [2] = { 0.60, -1.00 }, [3] = { 0.50, 3.05 }, [4] = { 1.04, 0.00 }, [5] = { 0.40, 3.50 },
                [6] = { 0.90, -2.00 }, [7] = { 0.49, 1.63 }, [8] = { 1.04, -2.60 }, [9] = { 0.49, -1.25 }, [10] = { 0.50, 0.53 } };
L.MOONPAT = MOON;

function L.hour_mod(pat, hour)
    local m = 0.5;
    if (pat == 2) then if (hour ~= 5 and hour ~= 17) then m = 1.0; end
    elseif (pat == 3) then if (hour == 5 or hour == 17) then m = 1.0; end
    elseif (pat == 4) then if (hour > 19 or hour < 4) then m = 1.0; end
    elseif (HOUR[pat]) then m = HOUR[pat](hour); end
    return m + 0.25;
end
function L.moon_mod(pat, moon)
    local m = 1.0;
    if (MOON[pat]) then m = MOON[pat](moon); end
    return m + 0.25;
end
function L.month_mod(pat, month)     -- month 1..12
    local m = 0.5;
    if (MONTH[pat]) then m = cosp(month - 1, MONTH[pat][1], MONTH[pat][2]); end
    return m + 0.25;
end

L.HOUR_TEXT  = { [0] = 'Any time', 'Night, morning and afternoon', 'Any hour but 05:00 / 17:00', 'Turn of the tide (05:00 / 17:00)',
                 'Night (20:00-03:00)', 'Morning and afternoon', 'Day and night peaks', 'Daytime' };
L.MOON_TEXT  = { [0] = 'Any moon', 'New and Full Moon', 'Half moons (not New / Full)', 'New Moon, fading toward Full',
                 'Full Moon', 'New Moon' };
L.MONTH_TEXT = { [0] = 'All year', 'Spring and summer', 'Spring and winter', 'Summer', 'Winter and summer', 'Summer and fall',
                 'Late spring and late fall', 'Fall', 'Spring and fall', 'Spring', 'Winter' };

-- Best Vana'diel hours for a pattern (for "best time" hints): list of hours scoring >= 0.8 of the top.
function L.best_hours(pat)
    if (pat == 0 or pat == nil) then return nil; end
    local best, s = 0, {};
    for h = 0, 23 do s[h] = L.hour_mod(pat, h); if (s[h] > best) then best = s[h]; end end
    local out = {};
    for h = 0, 23 do if (s[h] >= best - 0.05) then out[#out + 1] = h; end end
    return out;
end

----------------------------------------------------------------------------
-- Fishing areas (fishingutils isInsideCylinder / isInsidePoly, first match by area id)
----------------------------------------------------------------------------
local MAX_POINTS = 10000;
local function on_segment(p, q, r)
    return q.x <= max(p.x, r.x) and q.x >= min(p.x, r.x) and q.z <= max(p.z, r.z) and q.z >= min(p.z, r.z);
end
local function round(x) if x >= 0 then return floor(x + 0.5) end return -floor(-x + 0.5); end
local function orientation(p, q, r)
    local v = round(q.z - p.z) * (r.x - q.x) - (q.x - p.x) * (r.z - q.z);
    if (v == 0) then return 0; end
    return (v > 0) and 1 or 2;
end
local function intersect(p1, q1, p2, q2)
    local o1, o2, o3, o4 = orientation(p1, q1, p2), orientation(p1, q1, q2), orientation(p2, q2, p1), orientation(p2, q2, q1);
    if (o1 ~= o2 and o3 ~= o4) then return true; end
    if (o1 == 0 and on_segment(p1, p2, q1)) then return true; end
    if (o2 == 0 and on_segment(p1, q2, q1)) then return true; end
    if (o3 == 0 and on_segment(p2, p1, q2)) then return true; end
    if (o4 == 0 and on_segment(p2, q1, q2)) then return true; end
    return false;
end
local function inside_poly(pts, p, cy, height)
    local half = floor(height / 2);
    if (p.y < cy - half or p.y > cy + half) then return false; end
    local n = #pts;
    if (n < 3) then return false; end
    local poly = {};
    for i = 1, n do poly[i] = { x = pts[i][1], y = pts[i][2], z = pts[i][3] }; end
    local extreme = { x = MAX_POINTS, y = p.z, z = 0 };   -- as the server has it
    local count, i = 0, 0;
    repeat
        local nx = (i + 1) % n;
        if (intersect(poly[i + 1], poly[nx + 1], p, extreme)) then
            if (orientation(poly[i + 1], p, poly[nx + 1]) == 0) then return on_segment(poly[i + 1], p, poly[nx + 1]); end
            count = count + 1;
        end
        i = nx;
    until i == 0;
    return count % 2 == 1;
end
local function inside_cyl(a, p)
    local half = floor(a.bh / 2);
    if (p.y < a.cy - half or p.y > a.cy + half) then return false; end
    local dx, dz = abs(p.x - a.cx), abs(p.z - a.cz);
    if (dx > a.br or dz > a.br) then return false; end
    if (dx + dz <= a.br) then return true; end
    return dx * dx + dz * dz <= a.br * a.br;
end

-- p = { x, y, z } in server coordinates (y = height, negative up). Returns area id, area.
function L.find_area(zone, p)
    if (zone == nil) then return nil; end
    local ids = {};
    for id in pairs(zone.areas) do ids[#ids + 1] = id; end
    table.sort(ids);
    for _, id in ipairs(ids) do
        local a = zone.areas[id];
        if (a.bt == 0) then return id, a; end
        if (a.bt == 1 and inside_cyl(a, p)) then return id, a; end
        if (a.bt == 2 and a.pts and inside_poly(a.pts, p, a.cy, a.bh)) then return id, a; end
    end
    return nil;
end

----------------------------------------------------------------------------
-- Hook chances (fishingutils CalculateHookChance / FishingCheck with the TIMELESS no-empty-catch patch)
----------------------------------------------------------------------------
L.BAIT_LURE = 1;
L.BAITFLAG_POOR_FISH, L.BAITFLAG_SHELLFISH = 0x08, 0x40;
L.ROD_LU_SHANG, L.ROD_EBISU = 17386, 17011;
L.ROD_LU_SHANG_1, L.ROD_EBISU_1 = 19320, 19321;
-- Rod family for the low-fish bite bonus: since timeless-server 2cbd7b25 the +1 rods count as their originals.
function L.rod_family(rodid)
    if (rodid == L.ROD_LU_SHANG or rodid == L.ROD_LU_SHANG_1) then return 'lushang'; end
    if (rodid == L.ROD_EBISU or rodid == L.ROD_EBISU_1) then return 'ebisu'; end
    return nil;
end
L.FISHERMANS_APRON, L.FISHERMANS_SMOCK, L.FISHERS_ROPE = 14400, 11337, 11768;

-- c = { skill, hour, moon, month }
function L.hook_chance(D, fishid, baitid, rod, c)
    local f, b = D.fish[fishid], D.bait[baitid];
    if (f == nil or b == nil) then return 0; end
    local power = (D.aff[fishid] or {})[baitid] or 0;
    local modifier = max(0, (L.moon_mod(f.mp, c.moon) * 3 + L.hour_mod(f.hp, c.hour) * 2 + L.month_mod(f.mo, c.month)) / 3);
    local hc = floor(25 * modifier);
    local lure = b.t == L.BAIT_LURE;
    if (power == 1) then hc = hc + (lure and 30 or 35);
    elseif (power == 2) then hc = hc + (lure and 60 or 65);
    elseif (power == 3) then hc = hc + (lure and 75 or 80); end
    if (f.lv > c.skill) then hc = hc - clamp(floor((f.lv - c.skill) * 0.25), 0, hc); end
    if (c.skill - 10 > f.lv) then hc = hc - clamp(floor((c.skill - 10 - f.lv) * 0.15), 0, hc); end
    if (rod ~= nil and rod.lg ~= 1) then
        if (f.sz < rod.sz) then hc = hc - clamp(3, 0, hc);
        elseif (rod.sz < f.sz) then hc = hc - clamp(5, 0, hc); end
    end
    if (has(b.fl, L.BAITFLAG_SHELLFISH) and has(f.fl, 1)) then hc = hc + 50; end
    if (f.rar < 1000) then hc = floor(hc * f.rar / 1000); end
    return clamp(hc, 20, 120);
end

--[[
  What this spot gives for the gear in hand.
  ctx = { zoneid, areaid, skill, baitid, rodid, hour, moon, month, weather, body, has_ki(fn) }
  Returns { fish = { {id, share, chance}... sorted }, other = { fish not hooked by this bait },
            items = {...}, mobs = {...}, mix = { fish, item, mob } (0..1), nothing = bool }
--]]
function L.spot(D, ctx)
    local zone = D.zones[ctx.zoneid];
    local res = { fish = {}, other = {}, items = {}, mobs = {}, mix = { fish = 0, item = 0, mob = 0 } };
    if (zone == nil) then return res; end
    local area = zone.areas[ctx.areaid];
    if (area == nil) then return res; end
    local rod  = D.rods[ctx.rodid or 0];
    local bait = D.bait[ctx.baitid or 0];
    local c    = { skill = ctx.skill or 0, hour = ctx.hour or 12, moon = ctx.moon or 0, month = ctx.month or 1 };
    local mp   = ctx.moon or 0;

    local fishW, itemW, mobW;
    if (zone.city) then
        fishW = floor(15 * MOON[4](mp)); itemW = 25 + floor(20 * MOON[2](mp)); mobW = 0;
    else
        fishW = floor(25 * MOON[4](mp)); itemW = 10 + floor(15 * MOON[2](mp)); mobW = 15 + floor(15 * MOON[3](mp));
    end

    local total, maxc = 0, 0;
    for _, row in ipairs(D.groups[area.g] or {}) do
        local id = row[1];
        local f = D.fish[id];
        if (f ~= nil and f.it == 0) then
            local ki_ok = (f.ki == 0) or (ctx.has_ki and ctx.has_ki(f.ki));
            local hooks = bait ~= nil and (D.aff[id] or {})[ctx.baitid] ~= nil;
            if (hooks and ki_ok) then
                local hc = L.hook_chance(D, id, ctx.baitid, rod, c);
                res.fish[#res.fish + 1] = { id = id, chance = hc };
                total = total + hc;
                if (hc > maxc) then maxc = hc; end
            else
                res.other[#res.other + 1] = { id = id, ki = not ki_ok, quest = f.qo ~= 0 };
            end
        elseif (f ~= nil and f.it == 1) then
            if (f.qo == 0) then res.items[#res.items + 1] = { id = id }; end
        end
    end
    for _, m in ipairs(zone.mobs or {}) do
        if (m.nm == 0 and m.qo == 0 and (m.a == 0 or m.a == ctx.areaid)) then res.mobs[#res.mobs + 1] = m; end
    end

    if (#res.fish > 0) then fishW = clamp(maxc + fishW, 10, 120); end
    local wmod = (ctx.weather == 6) and 1.1 or ((ctx.weather == 7) and 1.2 or 1.0);
    fishW = floor(fishW * wmod);
    if ((ctx.body == L.FISHERMANS_APRON or ctx.body == L.FISHERMANS_SMOCK) and itemW > 0) then
        itemW = itemW - floor(itemW * 0.25);
    end
    if (bait ~= nil and has(bait.fl, L.BAITFLAG_POOR_FISH) and fishW > 0) then
        fishW = fishW - floor(fishW * 0.25);
        itemW = fishW + floor(fishW * 0.10);
    end
    -- TIMELESS: a pool only counts if something in it can be picked; no empty catches.
    if (#res.fish == 0) then fishW = 0; end
    if (#res.items == 0) then itemW = 0; end
    if (#res.mobs == 0) then mobW = 0; end
    local all = fishW + itemW + mobW;
    res.nothing = all == 0;
    if (all > 0) then
        res.mix.fish, res.mix.item, res.mix.mob = fishW / all, itemW / all, mobW / all;
    end

    -- Lu Shang / Ebisu (fishingutils FishingCheck): once a fish is picked, FishPoolWeight gets
    --   initialBonus + uint8(floor(skilldiff * (1 + floor(skilldiff / divisor)) / (sizeType + 1)))
    -- for that cast (Lu Shang 10 / 15, Ebisu 15 / 13; only when skill > fish level + 7). The uint8 cast wraps
    -- at 256 on the server, so it is copied here. Per fish i (share s_i of the fish pool):
    --   P(fish i) = s_i * (F + a_i) / (F + a_i + I + M);   P(item) = sum s_i * I / (F + a_i + I + M); same for monsters.
    local mix_item, mix_mob, mix_fish = 0, 0, 0;
    for _, e in ipairs(res.fish) do
        local f = D.fish[e.id];
        e.share = (total > 0) and (e.chance / total) or 0;
        e.add = 0;
        local fam = L.rod_family(ctx.rodid);
        if (fam ~= nil and c.skill > f.lv + 7) then
            local diff = c.skill - f.lv;
            local ib, dv = 10, 15;
            if (fam == 'ebisu') then ib, dv = 15, 13; end
            e.add = ib + (floor((diff * (1 + floor(diff / dv))) / (f.sz + 1)) % 256);
        end
        local denom = fishW + e.add + itemW + mobW;
        if (fishW > 0 and denom > 0) then
            e.overall = e.share * (fishW + e.add) / denom;
            mix_item = mix_item + e.share * itemW / denom;
            mix_mob  = mix_mob  + e.share * mobW / denom;
            mix_fish = mix_fish + e.overall;
        else
            e.overall = 0;
        end
    end
    if (fishW > 0 and #res.fish > 0) then
        res.mix.fish, res.mix.item, res.mix.mob = mix_fish, mix_item, mix_mob;
    end
    table.sort(res.fish, function (a, b) return a.overall > b.overall; end);
    res.weights = { fish = fishW, item = itemW, mob = mobW };
    return res;
end

-- Real chance per cast from a spot() result and the fishing-hole state:
--   school    -> every cast hooks a fish (fish chances = share of the fish pool)
--   exhausted -> half the casts get no bite (cast 76+ at a hole)
-- Returns { fish = { [id] = p }, fishp, item, mob, none } (all per cast, summing to 1).
function L.cast_odds(sp, school, exhausted)
    local out = { fish = {}, fishp = 0, item = 0, mob = 0, none = 0 };
    if (sp == nil or sp.nothing) then out.none = 1; return out; end
    if (school and #sp.fish > 0) then
        for _, e in ipairs(sp.fish) do out.fish[e.id] = e.share; end
        out.fishp = 1;
        return out;
    end
    local k = exhausted and 0.5 or 1;
    for _, e in ipairs(sp.fish) do out.fish[e.id] = e.overall * k; end
    out.fishp, out.item, out.mob = sp.mix.fish * k, sp.mix.item * k, sp.mix.mob * k;
    out.none = 1 - k;
    return out;
end

----------------------------------------------------------------------------
-- Conditions right now (what the moon, hour, weather and gear are doing)
----------------------------------------------------------------------------
-- fishingutils::GetHookTime: seconds from the cast to the bite.
function L.bite_wait(moon, hour, waist, school)
    local w, why = 13, {};
    if (moon == L.MOON_NEW or moon == L.MOON_FULL) then w = w - 4; why[#why + 1] = { -4, L.MOON_NAMES[moon] }; end
    if (hour == 5 or hour == 17) then w = w - 1; why[#why + 1] = { -1, 'Turn of the tide (' .. string.format('%02d:00', hour) .. ')' }; end
    if (waist == L.FISHERS_ROPE) then w = w - 1; why[#why + 1] = { -1, "Fisher's Rope" }; end
    w = max(7, w);
    if (school) then w = max(4, floor(w * 0.5 + 0.5)); why[#why + 1] = { 0, 'School of fish: half the wait' }; end -- server SCHOOL_WAIT_SCALE 0.5 (was 0.85)
    return w, why;
end

-- Moon multipliers on the catch mix (0..1, 1 = the moon's best for that pool).
function L.moon_pools(moon)
    return { fish = MOON[4](moon), item = MOON[2](moon), mob = MOON[3](moon) };
end

-- Which fish in a group like this moon / hour / month (multiplier on their hook chance vs average).
function L.fish_time_mods(D, fishid, c)
    local f = D.fish[fishid];
    if (f == nil) then return 1, 1, 1; end
    return L.moon_mod(f.mp, c.moon), L.hour_mod(f.hp, c.hour), L.month_mod(f.mo, c.month);
end

----------------------------------------------------------------------------
-- Skill, ranks and the Timeless bar game
----------------------------------------------------------------------------
L.RANKS = { [0] = 'Amateur', 'Recruit', 'Initiate', 'Novice', 'Apprentice', 'Journeyman', 'Craftsman', 'Artisan', 'Adept', 'Veteran', 'Expert', 'Authority' };
function L.rank_cap(rank) return (rank + 1) * 10; end

-- timeless_fishing computeParams: difficulty 5..100 for a fish at this effective skill.
-- timeless_fishing gapOf: levels the fish is above the angler (negative = below).
--   skill = GetFishingSkill (own skill + gear), gear = Mod::FISH from gear: gear counts a second time.
--   Fish over 100: each level over 100 counts 0.4; gear + legendary rod (rod only against the over-100 part), no cap (2026-11-12).
L.HIGH_ROD_BONUS = { [17386] = 3, [19320] = 4, [17011] = 5, [19321] = 6 };
local function round_half_away(x) if x >= 0 then return floor(x + 0.5) end return -floor(-x + 0.5); end
function L.gap(D, fishid, skill, gear, rodid)
    local f = D.fish[fishid];
    if (f == nil) then return 0; end
    gear = max(0, gear or 0);
    if (f.it == 1 or f.lv <= 100) then return round_half_away(f.lv - skill - gear); end
    local over  = 0.4 * (f.lv - 100);
    local rod   = min(L.HIGH_ROD_BONUS[rodid or 0] or 0, over);
    local bonus = gear + rod;
    return round_half_away(100 + over - bonus - skill);
end

-- timeless_fishing computeParams: difficulty 5..100 (large fish +8, legendary +8 since 2026-11-12).
function L.difficulty(D, fishid, skill, gear, rodid)
    local f = D.fish[fishid];
    if (f == nil) then return 40; end
    local d = 40 + 1.5 * L.gap(D, fishid, skill, gear, rodid);
    if (f.sz == 1) then d = d + 8; end
    if (f.lg == 1) then d = d + 8; end
    return floor(clamp(d, 5, 100) + 0.5);
end

-- Labels from the server simulation (bot win rates).
function L.difficulty_label(d)
    if (d <= 40) then return 'Easy', 1; end
    if (d <= 55) then return 'Normal', 2; end
    if (d <= 70) then return 'Tricky', 3; end
    if (d <= 85) then return 'Hard', 4; end
    return 'Very hard', 5;
end

-- Fish 30+ levels below your skill land 2 per catch, 50+ land 3 (stack permitting).
function L.multi_catch(D, fishid, skill, gear, rodid)
    local f = D.fish[fishid];
    if (f == nil) then return 1; end
    local below = -L.gap(D, fishid, skill, gear, rodid);
    if (below >= 50) then return 3; end
    if (below >= 30) then return 2; end
    return 1;
end

-- fishingutils::FishingSkillup: chance (0..1) of a skill-up on a normal win, using the REAL skill (no gear).
function L.skillup_chance(fish_lv, real_skill, city, rodid)
    if (fish_lv <= real_skill) then return 0; end
    local diff = fish_lv - real_skill;
    if (diff > 50) then return 0; end
    local roll = 90;
    local nd = math.exp(-0.5 * math.log(2 * math.pi) - math.log(5) - ((diff - 11) ^ 2) / 50);
    local mx = max(4, floor(nd * 200) + floor((100 - real_skill) / 10) - floor(real_skill / 10));
    if (not city) then roll = roll - 10; end
    if (real_skill < 50) then roll = roll - (20 - floor(real_skill / 3)); end
    return clamp(mx / roll, 0, 1);
end
L.PERFECT_SKILLUP = 0.75;

----------------------------------------------------------------------------
-- Schools of fish: a mirror of the server's per-character fishing hole
----------------------------------------------------------------------------
L.HOLE_RADIUS, L.HOLE_IDLE, L.EXHAUSTED_AT = 20.0, 600, 76; -- radius 20 since 2026-11-12 (was 9)
-- Pond zones (server isPondZone): the only water is smaller than the spot radius. One spot for the whole pool,
-- it never wears out, 5% school chance per cast, and a new school 5 minutes after the last one ended.
L.POND_ZONES = {
    [142] = 'Yughott Grotto', [154] = "Dragon's Aery", [157] = "Middle Delkfutt's Tower", [158] = "Upper Delkfutt's Tower",
    [159] = 'Temple of Uggalepih', [166] = 'Ranguemont Pass', [174] = 'Kuftal Tunnel', [184] = "Lower Delkfutt's Tower",
    [196] = 'Gusgen Mines', [208] = 'Quicksand Caves',
};
L.POND_CHANCE, L.POND_COOLDOWN = 0.05, 300;
function L.is_pond(zone) return L.POND_ZONES[zone] ~= nil; end
L.MSG_LETGO = 'let the school of fish swim off';
L.SCHOOL_IDLE = 300; -- a school ends after 5 minutes without a cast at the spot (server: SCHOOL_IDLE_MINUTES)
L.SCHOOL_MIN, L.SCHOOL_MAX = 6, 12;
function L.school_chance(cast)  -- cast = 1-based count at the hole
    if (cast <= 15) then return 0.08; end   -- server: 8 / 5 / 3 since 2026-11-12 (was 5 / 3 / 1)
    if (cast <= 40) then return 0.05; end
    if (cast <= 75) then return 0.03; end
    return 0;
end

L.MSG_HIT  = 'hit a school of fish';
L.MSG_GONE = 'school of fish has moved on';
L.MSG_EXH  = 'appears to be exhausted'; -- server: 'This fishing spot appears to be exhausted...' (was 'fishing hole' before 2026-11-12)

function L.new_hole() return { zone = 0, x = 0, z = 0, casts = 0, last = 0, used = false, active = false, hit_at = 0, school_casts = 0, school_catches = 0, next_school = 0 }; end

-- A school just ended (any reason): remember how it went; pond zones start the cooldown.
function L.end_school(h, now)
    if (h.active) then h.last_school = { casts = h.school_casts, catches = h.school_catches }; end
    h.active = false;
    h.next_school = now + L.POND_COOLDOWN;
end

-- Would a cast here start a new hole?
function L.is_fresh(h, zone, x, z, now)
    if (h.casts == 0 or h.zone ~= zone) then return true; end
    local dx, dz = x - h.x, z - h.z;
    if (not L.is_pond(zone) and dx * dx + dz * dz >= L.HOLE_RADIUS * L.HOLE_RADIUS) then return true; end
    return now - h.last >= L.HOLE_IDLE;
end

-- A running school ends at once when you change zones, move 9+ yalms from the spot, or go 5 minutes
-- without casting there. Returns 'zone' / 'moved' / 'idle' when it just ended, else nil.
function L.school_check(h, zone, x, z, now)
    if (not h.active) then return nil; end
    local why = nil;
    if (h.zone ~= zone) then why = 'zone';
    else
        local dx, dz = x - h.x, z - h.z;
        if (not L.is_pond(zone) and dx * dx + dz * dz >= L.HOLE_RADIUS * L.HOLE_RADIUS) then why = 'moved';
        elseif (now - h.last >= L.SCHOOL_IDLE) then why = 'idle'; end
    end
    if (why) then L.end_school(h, now); end
    return why;
end

-- Count one accepted cast. Returns true when it started a new hole.
function L.hole_cast(h, zone, x, z, now)
    local fresh = L.is_fresh(h, zone, x, z, now);
    if (fresh) then
        local cooldown = h.next_school or 0; -- a pond's school cooldown survives zoning out and back in
        local n = L.new_hole();
        for k in pairs(h) do h[k] = nil; end
        for k, v in pairs(n) do h[k] = v; end
        h.zone, h.x, h.z, h.next_school = zone, x, z, cooldown;
    end
    h.casts = h.casts + 1;
    h.last = now;
    if (h.active) then h.school_casts = h.school_casts + 1; end
    return fresh;
end

function L.hole_message(h, text, now)
    if (text:find(L.MSG_HIT, 1, true)) then
        h.active, h.used, h.hit_at, h.school_casts, h.school_catches, h.started = true, true, h.casts, 1, 0, now;
        return 'hit';
    elseif (text:find(L.MSG_GONE, 1, true)) then
        -- Only a school we still think is running ends here; a late message (we already ended it on a zone
        -- change, a move or idling) must not touch the spot we are at now.
        if (not h.active) then return 'gone_quiet'; end
        L.end_school(h, now);
        return 'gone';
    elseif (text:find(L.MSG_LETGO, 1, true)) then
        if (h.active) then L.end_school(h, now); end
        return 'letgo';
    elseif (text:find(L.MSG_EXH, 1, true)) then
        if (h.casts < L.EXHAUSTED_AT) then h.casts = L.EXHAUSTED_AT; end
        h.active = false;
        return 'exhausted';
    end
    return nil;
end

-- Chance the next cast hits a school / any school before the hole runs dry.
function L.hole_odds(h, zone, x, z, now)
    local next_cast = (L.is_fresh(h, zone, x, z, now) and 1) or (h.casts + 1);
    local fresh = next_cast == 1;
    if (h.active and not fresh) then return { next = next_cast, now = 1, ahead = 1, fresh = false, active = true, pond = L.is_pond(zone) }; end
    if (L.is_pond(zone)) then
        local wait = max(0, (h.next_school or 0) - now);
        return { next = next_cast, now = (wait > 0) and 0 or L.POND_CHANCE, ahead = 1, fresh = fresh, pond = true, wait = wait };
    end
    if (h.used and not fresh) then return { next = next_cast, now = 0, ahead = 0, fresh = false, used = true }; end
    local p_now = L.school_chance(next_cast);
    local miss = 1;
    for k = next_cast, L.EXHAUSTED_AT - 1 do miss = miss * (1 - L.school_chance(k)); end
    return { next = next_cast, now = p_now, ahead = 1 - miss, fresh = fresh };
end

-- While a school runs: it lasts the hit cast + 6..12 more. done = school casts so far (incl. the hit).
-- Returns min / max casts left and the chance the NEXT cast is still in the school.
function L.school_left(done)
    local extra_done = done - 1;
    local lo, hi = max(0, L.SCHOOL_MIN - extra_done), max(0, L.SCHOOL_MAX - extra_done);
    -- N uniform 6..12; next cast is in the school if N >= extra_done + 1
    local ok, n = 0, 0;
    for N = L.SCHOOL_MIN, L.SCHOOL_MAX do
        if (N >= extra_done) then n = n + 1; if (N >= extra_done + 1) then ok = ok + 1; end end
    end
    return lo, hi, (n > 0) and (ok / n) or 0;
end

return L;
