--[[
* Timeless Angler - fishing companion HUD for Timeless XI (Ashita v4)
*
* A window with tabs and a small always-on HUD:
*   Here        what this spot gives for the rod and bait in hand (server maths), items and monsters
*   Conditions  Vana'diel time, the moon phase and what it is doing to fishing right now, weather, bite wait
*   Zones       every fishing zone and area with its fish
*   Fish        find a fish: baits (with power), rods, where it lives, best times, how hard it is for you
*   Skill       fishing skill, rank and cap, bonus from gear (equipped and owned)
*   Schools     your fishing hole: casts, school chances, distance, the school while it runs
*   Tracker     this session: casts, catches, skill-ups
* The HUD shows skill, spot, moon, the fishing-hole meter and the top bites; when a school of fish
* is running a gold banner shows its perks and how long it may last.
*
* Works alongside the timelessfishing add-on (it never sends packets and never blocks any).
* Fish data is generated from the Timeless XI server's own fishing tables (gen.py).
*
* Commands: /angler (toggle window)  /angler hud  /angler banner  /angler search <text>
*           /angler spot reset       /angler help        (also /fishhud)
--]]

addon.name    = 'timelessangler';
addon.author  = 'Timeless XI';
addon.version = '1.39';
addon.desc    = 'Fishing companion: fish per zone, bait / rod search, skill, moon and schools of fish.';
addon.link    = 'https://timelessxi.gg';

require('common');
local chat     = require('chat');
local imgui_raw = require('imgui');
-- Text goes through TextUnformatted / TextColored, which print the string as it is ('%' included).
-- (Ashita's BulletText is a printf format, so it is rebuilt from Bullet + TextUnformatted.)
-- Any ImGui function this Ashita build doesn't have (e.g. SetWindowFontScale) becomes a no-op
-- instead of an error.
local missing_warned = {};
local imgui = setmetatable({}, { __index = function (_, k)
    local v = imgui_raw[k];
    if (v == nil) then
        if (not missing_warned[k]) then
            missing_warned[k] = true;
            print(('[timelessangler] ImGui has no %s here; skipped.'):format(tostring(k)));
        end
        v = function () end;
    end
    return v;
end });
local DIM_TEXT = { 110 / 255, 120 / 255, 140 / 255, 1 };
imgui.Text = function (s) imgui_raw.TextUnformatted(tostring(s)); end
imgui.TextDisabled = function (s) imgui_raw.TextColored(DIM_TEXT, tostring(s)); end
imgui.TextWrapped = function (s)
    imgui_raw.PushTextWrapPos(0);
    imgui_raw.TextUnformatted(tostring(s));
    imgui_raw.PopTextWrapPos();
end
imgui.BulletText = function (s)
    imgui_raw.Bullet();
    imgui_raw.SameLine();
    imgui_raw.TextUnformatted(tostring(s));
end
imgui.SetTooltip = function (s)
    if (imgui_raw.BeginTooltip() ~= false) then
        imgui_raw.TextUnformatted(tostring(s));
        imgui_raw.EndTooltip();
    end
end
imgui.SetWindowFontScale = imgui_raw.SetWindowFontScale or function () end;

-- Unwind stack: every Begin*/Push* that needs a matching End*/Pop* is recorded, so a window whose
-- drawing hits an error can still close everything it opened (see safe_window).
local unwind = {};
local function closes(name) -- remove the most recent matching entry
    for i = #unwind, 1, -1 do if (unwind[i] == name) then table.remove(unwind, i); return; end end
end
local function track(open_fn, close_fn, always)
    local o, c = imgui_raw[open_fn], imgui_raw[close_fn];
    if (o == nil or c == nil) then return; end
    imgui[open_fn] = function (...)
        local r = o(...);
        if (always or r) then unwind[#unwind + 1] = close_fn; end
        return r;
    end
    imgui[close_fn] = function (...) closes(close_fn); return c(...); end
end
track('BeginChild', 'EndChild', true);
track('BeginTable', 'EndTable', false);
track('BeginTabBar', 'EndTabBar', false);
track('BeginTabItem', 'EndTabItem', false);
track('BeginCombo', 'EndCombo', false);
track('BeginGroup', 'EndGroup', true);
track('Indent', 'Unindent', true);
track('PushItemWidth', 'PopItemWidth', true);
do
    for _, pair in ipairs({ { 'PushStyleColor', 'PopStyleColor' }, { 'PushStyleVar', 'PopStyleVar' } }) do
        local o, c = imgui_raw[pair[1]], imgui_raw[pair[2]];
        imgui[pair[1]] = function (...) unwind[#unwind + 1] = pair[2]; return o(...); end
        imgui[pair[2]] = function (n) for _ = 1, (n or 1) do closes(pair[2]); end return c(n or 1); end
    end
end

-- Fonts: the website's Inter (text and, since 1.7, headings in SemiBold), shared with timelessfishing.
local UF = require('timeless.ui_fonts');
local font_on = { enabled = true, size = 16 };   -- set from the settings once they are loaded
local function fonts_ok() return font_on.enabled and UF.loaded; end

-- A heading in the title face (default Raleway SemiBold; /angler titlefont picks another): mult = size vs body.
local function heading(text, color, role, mult)
    role = role or 'title';
    mult = mult or 1.1;
    if (fonts_ok()) then
        imgui_raw.PushFont(UF.get(role), UF.size(role, font_on.size * mult));
        imgui_raw.TextColored(color, tostring(text));
        imgui_raw.PopFont();
    else
        imgui_raw.TextColored(color, tostring(text));
    end
end

local reported = {};
local function safe_window(name, open, flags, body, size_delta)
    local depth = #unwind;
    local pushed = false;
    if (fonts_ok()) then
        imgui_raw.PushFont(UF.get('body'), UF.size('body', font_on.size + (size_delta or 0)));
        pushed = true;
    end
    if (imgui_raw.Begin(name, open, flags)) then
        local ok, err = pcall(body);
        if (not ok and not reported[tostring(err)]) then
            reported[tostring(err)] = true;
            print(('[timelessangler] error drawing %s: %s'):format(name, tostring(err)));
        end
    end
    while (#unwind > depth) do        -- close whatever an error left open, newest first
        local f = table.remove(unwind);
        if (f == 'PopStyleColor' or f == 'PopStyleVar') then imgui_raw[f](1); else imgui_raw[f](); end
    end
    imgui_raw.End();
    if (pushed) then imgui_raw.PopFont(); end
end
local settings = require('settings');
local ffi      = require('ffi');
local d3d8     = require('d3d8');

local L = require('angler_logic');
local D = require('data');

local defaults = T{
    show_main   = false,
    show_hud    = true,
    hud_auto    = true,     -- HUD only while a rod is in hand (or a school is running)
    show_banner = true,
    hud_alpha   = 0.88,     -- HUD background opacity (0.2 - 1)
    main_alpha  = 0.94,     -- guide background opacity
    main_rect   = nil,      -- saved guide { x, y, w, h }
    hud_rect    = nil,      -- saved HUD { x, y, w, h }
    font        = true,     -- use the website's font (Inter; headings in Inter SemiBold)
    font_size   = 16,       -- body text size in pixels (16 since 1.7)
    font_v      = 1,        -- settings version (raised to 2 on load: saved size 15 -> 16)
    hole        = nil,      -- saved fishing hole (restored if still fresh)
};
local cfg = settings.load(defaults);

----------------------------------------------------------------------------
-- Colours (theme shared with timelessfishing)
----------------------------------------------------------------------------
local function rgba(r, g, b, a) return { r / 255, g / 255, b / 255, a or 1 }; end
local function col(r, g, b, a) return math.floor((a or 1) * 255 + 0.5) * 16777216 + b * 65536 + g * 256 + r; end
local K = {
    text   = rgba(230, 236, 245), muted = rgba(152, 163, 184), dim = rgba(110, 120, 140),
    gold   = rgba(232, 200, 120), blue  = rgba(143, 178, 230), green = rgba(126, 211, 140),
    red    = rgba(230, 96, 96),   amber = rgba(235, 170, 80),  white = rgba(245, 245, 250),
    bg     = rgba(10, 11, 18, 0.94), bg2 = rgba(17, 20, 29, 1), edge = rgba(40, 48, 64, 1),
    head   = rgba(24, 30, 44, 1), headHi = rgba(36, 46, 68, 1), tab = rgba(20, 25, 37, 1), tabHi = rgba(61, 95, 148, 1),
};
local U = {
    panel = col(10, 11, 18, 0.94), silver = col(214, 220, 232, 1), moon = col(236, 228, 196, 1), moonEdge = col(152, 163, 184, 1),
    gold = col(232, 200, 120, 1), goldDim = col(232, 200, 120, 0.25), blue = col(143, 178, 230, 1), track = col(17, 20, 29, 1),
    tier1 = col(126, 211, 140, 0.85), tier2 = col(143, 178, 230, 0.85), tier3 = col(152, 163, 184, 0.7), tier4 = col(110, 60, 60, 0.8),
    mark = col(245, 245, 250, 1), dark = col(30, 34, 46, 1),
};
local DIFF_COL = { K.green, K.blue, K.gold, K.amber, K.red };

local theme_pushed = { c = 0, v = 0 };
local function push_theme(alpha)
    local list = {
        { ImGuiCol_WindowBg, { K.bg[1], K.bg[2], K.bg[3], alpha or K.bg[4] } }, { ImGuiCol_Border, K.edge },
        { ImGuiCol_TitleBg, K.head }, { ImGuiCol_TitleBgActive, K.headHi }, { ImGuiCol_Tab, K.tab },
        { ImGuiCol_TabHovered, K.tabHi }, { ImGuiCol_TabActive, K.tabHi }, { ImGuiCol_Header, K.head },
        { ImGuiCol_HeaderHovered, K.headHi }, { ImGuiCol_HeaderActive, K.tabHi }, { ImGuiCol_FrameBg, K.bg2 },
        { ImGuiCol_Button, K.head }, { ImGuiCol_ButtonHovered, K.headHi }, { ImGuiCol_PlotHistogram, K.tabHi },
        { ImGuiCol_TableHeaderBg, K.head }, { ImGuiCol_TableRowBgAlt, { 1, 1, 1, 0.025 } }, { ImGuiCol_Text, K.text },
    };
    theme_pushed.c, theme_pushed.v = 0, 0;
    for _, e in ipairs(list) do
        if (e[1] ~= nil) then imgui.PushStyleColor(e[1], e[2]); theme_pushed.c = theme_pushed.c + 1; end
    end
    for _, e in ipairs({ { ImGuiStyleVar_WindowRounding, 6 }, { ImGuiStyleVar_FrameRounding, 4 } }) do
        if (e[1] ~= nil) then imgui.PushStyleVar(e[1], e[2]); theme_pushed.v = theme_pushed.v + 1; end
    end
end
local function pop_theme()
    if (theme_pushed.v > 0) then imgui.PopStyleVar(theme_pushed.v); end
    if (theme_pushed.c > 0) then imgui.PopStyleColor(theme_pushed.c); end
    theme_pushed.c, theme_pushed.v = 0, 0;
end

----------------------------------------------------------------------------
-- Game state helpers
----------------------------------------------------------------------------
local SLOT = { range = 2, ammo = 3, head = 4, body = 5, hands = 6, legs = 7, feet = 8, neck = 9, waist = 10 };
local SLOT_NAMES = { [2] = 'Ranged', [3] = 'Ammo', [4] = 'Head', [5] = 'Body', [6] = 'Hands', [7] = 'Legs', [8] = 'Feet', [9] = 'Neck', [10] = 'Waist' };
local GEAR_SLOT = { [10925] = 9, [11337] = 5, [13808] = 5, [13809] = 5, [14070] = 6, [14071] = 6, [14171] = 8, [14172] = 8,
                    [14195] = 8, [14292] = 7, [14293] = 7, [11768] = 10, [14400] = 5 };
-- Gear that helps without adding skill (fishingutils): the rope shortens the wait, apron / smock cut junk items.
local GEAR_OTHER = { [11768] = 'Fish bite 1 second faster', [14400] = 'Fewer junk items (25% fewer)', [11337] = 'Fewer junk items (25% fewer)' };
local ANIM_FISH_START = 56;
local CONTAINERS = { 0, 1, 2, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16 };

local mm = function () return AshitaCore:GetMemoryManager(); end
local res = function () return AshitaCore:GetResourceManager(); end

local function item_name(id)
    local it = res():GetItemById(id);
    if (it ~= nil and it.Name ~= nil and it.Name[1] ~= nil and it.Name[1] ~= '') then return it.Name[1]; end
    local f = D.fish[id];
    if (f) then return f.n; end
    local b = D.bait[id];
    if (b) then return b.n; end
    local r = D.rods[id];
    if (r) then return r.n; end
    return ('Item %d'):format(id);
end

local zone_cache = {};
local function zone_name(zid)
    if (zone_cache[zid]) then return zone_cache[zid]; end
    local n = nil;
    pcall(function () n = res():GetString('zones.names', zid); end);
    if (n == nil or n == '') then n = (D.zones[zid] and D.zones[zid].n) or ('Zone ' .. tostring(zid)); end
    -- The pirate ship routes (227 / 228) share their names with the regular ships (220 / 221) in the client.
    if (zid == 227 or zid == 228) then n = n:gsub('%s*[Pp]irates?$', '') .. ' (Pirates)'; end
    zone_cache[zid] = n;
    return n;
end

local function equipped(slot)
    local inv = mm():GetInventory();
    local e = inv:GetEquippedItem(slot);
    if (e == nil or e.Index == nil or e.Index == 0) then return 0; end
    local cont, idx = math.floor(e.Index / 256) % 256, e.Index % 256;
    local it = inv:GetContainerItem(cont, idx);
    if (it == nil or it.Id == nil or it.Id == 65535) then return 0; end
    return it.Id;
end

-- Vana'diel clock and weather (client memory, same signatures as the GoFish / clock add-ons).
local ptr = { vana = nil, weather = nil, tried = false };
local function find_pointers()
    ptr.tried = true;
    pcall(function () ptr.vana = ashita.memory.find('FFXiMain.dll', 0, 'B0015EC390518B4C24088D4424005068', 0x34, 0); end);
    pcall(function () ptr.weather = ashita.memory.find('FFXiMain.dll', 0, '66A1????????663D????72', 0x02, 0); end);
end
local function vana_raw()
    if (not ptr.tried) then find_pointers(); end
    local raw = nil;
    if (ptr.vana ~= nil and ptr.vana ~= 0) then
        pcall(function () raw = ashita.memory.read_uint32(ashita.memory.read_uint32(ptr.vana) + 0x0C); end);
    end
    return raw or (os.time() - 1009810800);
end
local function weather_now()
    local w = 0;
    if (ptr.weather ~= nil and ptr.weather ~= 0) then
        pcall(function () w = ashita.memory.read_uint8(ashita.memory.read_uint32(ptr.weather)); end);
    end
    return w or 0;
end
local WEATHER = { [0] = 'Clear', 'Sunshine', 'Clouds', 'Fog', 'Hot spell', 'Heat wave', 'Rain', 'Squall', 'Dust storm', 'Sandstorm',
                  'Wind', 'Gales', 'Snow', 'Blizzard', 'Thunder', 'Thunderstorm', 'Auroras', 'Stellar glare', 'Gloom', 'Darkness' };

----------------------------------------------------------------------------
-- State
----------------------------------------------------------------------------
local S = {
    zone = 0, pos = { x = 0, y = 0, z = 0 }, area_id = nil, area = nil,
    skill_raw = 0, rank = 0, capped = false, gear = 0, skill = 0, gear_list = {},
    rod = 0, bait = 0, body = 0, waist = 0, status = 0, fishing = false,
    date = nil, weather = 0, spot = nil, name = '',
    next_update = 0, next_owned = 0, owned = {},
};
local hole = L.new_hole();
local session = { start = os.time(), casts = 0, bites = 0, catches = 0, fish = 0, lost = 0, items = 0, monsters = 0, skill = 0, schools = 0, by = {}, log = {} };
local hooked = nil;           -- what is on the line (from the server's 0x115)
local last_cast_at = -100;    -- os.clock() of the last counted cast
local armed = true;           -- true while not fishing: the next status 56 (cast accepted) is a new cast
local function is_fishing_anim(a) return a ~= nil and a >= 50 and a <= 62; end
local function see_status(a)  -- returns true if this status starts a new cast
    if (a == ANIM_FISH_START and armed) then armed = false; return true; end
    if (not is_fishing_anim(a) and os.clock() - last_cast_at > 3) then armed = true; end
    return false;
end
local banner_msg = nil;       -- { text, until } after a school ends / hole exhausted
local ui = {
    tab_req = nil, search = { '' }, sel_fish = nil, zone_filter = { '' }, sel_zone = nil, open_main = { false },
    show_other = { false },
};

local function commas(n)
    local t = tostring(math.floor(n + 0.5));
    local k;
    repeat t, k = t:gsub('^(-?%d+)(%d%d%d)', '%1,%2'); until k == 0;
    return t;
end

-- "3-9 casts left" / "up to 9 casts left" / "1 cast left"
local function casts_left(lo, hi)
    if (hi <= 0) then return 'last cast'; end
    if (lo == hi) then return ('%d cast%s left'):format(hi, hi == 1 and '' or 's'); end
    if (lo <= 0) then return ('up to %d casts left'):format(hi); end
    return ('%d-%d casts left'):format(lo, hi);
end

local function reset_session()
    session = { start = os.time(), casts = 0, bites = 0, catches = 0, fish = 0, lost = 0, items = 0, monsters = 0, skill = 0, schools = 0, by = {}, log = {} };
end

-- Per-hour projections: hours since the first cast this session (at least 1 minute).
local function session_hours()
    return math.max(60, os.time() - (session.first or os.time())) / 3600;
end

-- Chat line as plain text: drop FFXI colour / auto-translate / end-of-line codes (2 bytes each),
-- other control bytes, and a timestamp add-on's "[hh:mm:ss]" prefix (with whatever code sat in front of it).
local function clean_chat(text)
    text = text:gsub('[\30\31\127\239].', ''):gsub('[%z\1-\31]', '');
    text = text:gsub('^.-%[%d%d?:%d%d:%d%d%]%s*', '', 1);
    return (text:gsub('^%s+', ''):gsub('%s+$', ''));
end

local function log(text, c)
    table.insert(session.log, 1, { t = os.date('%H:%M:%S'), text = text, c = c or K.text });
    while (#session.log > 60) do table.remove(session.log); end
end

local function msg(text) print(chat.header(addon.name):append(chat.message(text))); end

-- Owned items (bags + wardrobes), refreshed every few seconds while the window is open.
local function scan_owned()
    local inv = mm():GetInventory();
    local owned = {};
    for _, c in ipairs(CONTAINERS) do
        local n = inv:GetContainerCountMax(c) or 0;
        for i = 0, n do
            local it = inv:GetContainerItem(c, i);
            if (it ~= nil and it.Id ~= nil and it.Id > 0 and it.Id ~= 65535) then
                owned[it.Id] = (owned[it.Id] or 0) + math.max(1, it.Count or 1);
            end
        end
    end
    S.owned = owned;
end

local function update_state()
    local party, ent, player = mm():GetParty(), mm():GetEntity(), mm():GetPlayer();
    local idx = party:GetMemberTargetIndex(0);
    S.name = party:GetMemberName(0) or '';
    S.zone = party:GetMemberZone(0) or 0;
    if (idx ~= nil and idx > 0) then
        S.pos = { x = ent:GetLocalPositionX(idx), y = ent:GetLocalPositionZ(idx), z = ent:GetLocalPositionY(idx) };
        S.status = ent:GetStatus(idx) or 0;
    end
    local cs = player:GetCraftSkill(0);
    if (cs ~= nil) then
        S.skill_raw = cs:GetSkill() or 0;
        pcall(function () S.rank = cs:GetRank() or 0; end);
        pcall(function () S.capped = cs:IsCapped() and true or false; end);
    end
    S.rod, S.bait = equipped(SLOT.range), equipped(SLOT.ammo);
    S.body, S.waist = equipped(SLOT.body), equipped(SLOT.waist);
    local bonus, list = 0, {};
    for _, s in ipairs({ SLOT.head, SLOT.body, SLOT.hands, SLOT.legs, SLOT.feet, SLOT.neck, SLOT.waist }) do
        local id = equipped(s);
        if (id > 0 and (D.gear[id] or GEAR_OTHER[id])) then
            bonus = bonus + (D.gear[id] or 0);
            list[#list + 1] = { id = id, slot = s, bonus = D.gear[id] or 0 };
        end
    end
    S.gear, S.gear_list = bonus, list;
    S.skill = S.skill_raw + bonus;
    S.date = L.vana_date(vana_raw());
    S.weather = weather_now();
    S.zinfo = D.zones[S.zone];
    S.area_id, S.area = L.find_area(S.zinfo, S.pos);
    if (S.area_id ~= nil) then
        S.spot = L.spot(D, {
            zoneid = S.zone, areaid = S.area_id, skill = S.skill, baitid = S.bait, rodid = S.rod,
            hour = S.date.hour, moon = S.date.moon, month = S.date.month, weather = S.weather, body = S.body,
            has_ki = function (k) return player:HasKeyItem(k); end,
        });
    else
        S.spot = nil;
    end
    S.has_rod = D.rods[S.rod] ~= nil;
end

----------------------------------------------------------------------------
-- Fishing hole tracking (mirror of the server's schools of fish)
----------------------------------------------------------------------------
local function count_cast()
    local now = os.time();
    pcall(update_state);
    local fresh = L.hole_cast(hole, S.zone, S.pos.x, S.pos.z, now);
    last_cast_at = os.clock();
    session.casts = session.casts + 1;
    session.first = session.first or now;
    if (fresh and session.casts > 1) then log('New fishing spot started here.', K.blue); end
    
end

local function on_server_text(text)
    local kind = L.hole_message(hole, text, os.time());
    if (kind == nil) then return; end
    if (kind == 'hit') then
        -- The hit message follows the cast; if we haven't counted that cast yet, count it now.
        if (armed and os.clock() - last_cast_at > 3) then
            armed = false;
            hole.active = false;
            count_cast();
            L.hole_message(hole, text, os.time());
        end
        banner_msg = nil; -- a new school replaces any 'moved on' notice still showing
        session.schools = session.schools + 1;
        log(('Found a school of fish on cast %d!'):format(hole.casts), K.gold);
    elseif (kind == 'gone') then
        local s = hole.last_school;
        if (s) then
            banner_msg = { text = ('The school of fish moved on. You caught %d fish in %d casts.\nMove 20 or more yalms away to start a new fishing spot.'):format(s.catches, s.casts), till = os.clock() + 10 };
            log(('School of fish ended: %d fish in %d casts.'):format(s.catches, s.casts), K.gold);
        end
    elseif (kind == 'letgo') then
        -- our own button already ended it and showed the notice
    elseif (kind == 'exhausted') then
        banner_msg = { text = 'This fishing spot is exhausted (75 casts).\nMove 20 or more yalms away to start a new one.', till = os.clock() + 10 };
        log('Fishing spot exhausted: no more schools here, and only half your casts get a bite.', K.amber);
    end
end

-- The player lets the running school go (HUD / Schools tab button, /angler school end). The server is told with
-- 0x110 mode 5 para 11 (no fish on the line) and answers "You let the school of fish swim off."
local CANCEL_PARA = 11;
local function let_school_go()
    if (not hole.active) then msg('No school of fish is running.'); return; end
    pcall(function ()
        local party = AshitaCore:GetMemoryManager():GetParty();
        local id, index = party:GetMemberServerId(0), party:GetMemberTargetIndex(0);
        if (id == nil or id == 0) then return; end
        local b = struct.pack('<BBHIiHbBi', 0x10, 0x0B, 0, id, CANCEL_PARA, index, 5, 0, 0);
        AshitaCore:GetPacketManager():AddOutgoingPacket(0x110, { b:byte(1, -1) });
    end);
    L.end_school(hole, os.time());
    local s = hole.last_school or { catches = 0, casts = 0 };
    banner_msg = { text = ('You let the school of fish go.\nYou caught %d fish in %d casts.'):format(s.catches, s.casts), till = os.clock() + 6 };
    log(('You let the school of fish go: %d fish in %d casts.'):format(s.catches, s.casts), K.gold);
end

-- A school ends the moment you zone, walk 20+ yalms off the spot, or stop casting for 5 minutes.
local function check_school()
    if (not hole.active or S.zone == 0) then return; end
    local why = L.school_check(hole, S.zone, S.pos.x, S.pos.z, os.time());
    if (why == nil) then return; end
    local s = hole.last_school;
    local reason = (why == 'zone' and 'you changed zones') or (why == 'moved' and 'you left the fishing spot') or 'no casts for 5 minutes';
    banner_msg = { text = ('The school of fish moved on (%s).\nYou caught %d fish in %d casts.'):format(reason, s.catches, s.casts), till = os.clock() + 8 };
    log(('School of fish ended (%s): %d fish in %d casts.'):format(reason, s.catches, s.casts), K.gold);
end

-- Catch / skill-up messages as the client prints them.
local function on_text(text)
    if (text == nil or S.name == '') then return; end
    local function done() hooked = nil; end
    if (text:find(S.name .. ' caught ', 1, true) or text:find('You caught ', 1, true)) then
        local n = tonumber(text:match(' caught (%d+) ')) or 1;
        session.catches = session.catches + 1;
        local id = hooked and hooked.item or 0;
        if (hooked and hooked.monster) then
            session.monsters = session.monsters + 1;
        elseif (id > 0 and D.fish[id] and D.fish[id].it == 0) then
            session.fish = session.fish + n;
            session.by[id] = (session.by[id] or 0) + n;
        else
            session.items = session.items + 1;
            if (id > 0) then session.by[id] = (session.by[id] or 0) + n; end
        end
        if (hole.active) then hole.school_catches = hole.school_catches + n; end
        log(clean_chat(text), K.green);
        done();
    elseif (text:find('lost your catch', 1, true) or text:find('line snaps', 1, true) or text:find('rod breaks', 1, true)
            or text:find('You give up', 1, true) or text:find('didn\'t catch anything', 1, true)) then
        session.lost = session.lost + 1;
        log(clean_chat(text), K.muted);
        done();
    else
        local up = text:match('fishing skill rises ([%d%.]+) point');
        if (up) then
            session.skill = session.skill + (tonumber(up) or 0);
            log(('Fishing skill +%s'):format(up), K.gold);
        end
    end
end

----------------------------------------------------------------------------
-- Icons
----------------------------------------------------------------------------
local tex = { items = {}, count = 0 };
local function icon(id)
    if (id == nil or id <= 0 or id >= 65535) then return nil; end
    local c = tex.items[id];
    if (c ~= nil) then return c ~= false and c or nil; end
    if (tex.count > 160) then tex.items = {}; tex.count = 0; end
    tex.count = tex.count + 1;
    local it = res():GetItemById(id);
    if (it == nil or it.ImageSize == nil or it.ImageSize == 0) then tex.items[id] = false; return nil; end
    local p = ffi.new('IDirect3DTexture8*[1]');
    if (ffi.C.D3DXCreateTextureFromFileInMemoryEx(d3d8.get_device(), it.Bitmap, it.ImageSize, 0xFFFFFFFF, 0xFFFFFFFF, 1, 0,
            ffi.C.D3DFMT_A8R8G8B8, ffi.C.D3DPOOL_MANAGED, ffi.C.D3DX_DEFAULT, ffi.C.D3DX_DEFAULT, 0xFF000000, nil, nil, p) ~= ffi.C.S_OK) then
        tex.items[id] = false;
        return nil;
    end
    local t = d3d8.gc_safe_release(ffi.cast('IDirect3DTexture8*', p[0]));
    tex.items[id] = t;
    return t;
end
local function draw_icon(id, size)
    local t = icon(id);
    if (t ~= nil) then
        imgui.Image(tonumber(ffi.cast('uint32_t', t)), { size, size });
    else
        imgui.Dummy({ size, size });
    end
end

----------------------------------------------------------------------------
-- Small widgets
----------------------------------------------------------------------------
local function avail_w()
    local a = imgui.GetContentRegionAvail();
    if (type(a) == 'number') then return a; end
    if (a ~= nil and a.x ~= nil) then return a.x; end
    if (type(a) == 'table') then return a[1] or 300; end
    return 300;
end
local function tip(text)
    if (imgui.IsItemHovered()) then imgui.SetTooltip(text); end
end
local function stars(n)
    return string.rep('*', n) .. string.rep('.', 3 - n);
end
local function pct(x) return ('%d%%'):format(math.floor(x * 100 + 0.5)); end
local function pct1(x)
    if (x > 0 and x < 0.01) then return '<1%'; end
    return pct(x);
end
local function mins(m)
    if (m == nil) then return 'now'; end
    if (m < 60) then return ('%d min'):format(math.floor(m + 0.5)); end
    return ('%dh %02dm'):format(math.floor(m / 60), math.floor(m % 60));
end

-- The moon drawn as a disc with its shadow. pct 0..100, dir 1 waning (lit on the left) / 2 waxing (lit on the right).
local function draw_moon(r, p, dir)
    local x, y = imgui.GetCursorScreenPos();
    local dl = imgui.GetWindowDrawList();
    local cx, cy = x + r, y + r;
    dl:AddCircleFilled({ cx, cy }, r, U.moon, 32);
    local off = (p / 100) * 2 * r;
    local sx = (dir == 1) and (cx + off) or (cx - off);
    dl:PushClipRect({ x - 1, y - 1 }, { x + 2 * r + 1, y + 2 * r + 1 }, true);
    if (p < 99) then dl:AddCircleFilled({ sx, cy }, r * 1.02, U.dark, 32); end
    dl:PopClipRect();
    dl:AddCircle({ cx, cy }, r, U.moonEdge, 32, 1.2);
    imgui.Dummy({ 2 * r, 2 * r });
end

-- Fishing-hole meter: 75 casts in three bands (5% / 3% / 1%) then exhausted; a marker at the current cast.
local function draw_hole_meter(w, h)
    local x, y = imgui.GetCursorScreenPos();
    local dl = imgui.GetWindowDrawList();
    local span = 80;
    local function px(c) return x + w * math.min(c, span) / span; end
    dl:AddRectFilled({ x, y }, { x + w, y + h }, U.track, 3);
    dl:AddRectFilled({ px(0), y }, { px(15), y + h }, U.tier1, 3);
    dl:AddRectFilled({ px(15), y }, { px(40), y + h }, U.tier2, 0);
    dl:AddRectFilled({ px(40), y }, { px(75), y + h }, U.tier3, 0);
    dl:AddRectFilled({ px(75), y }, { px(span), y + h }, U.tier4, 3);
    if (hole.used and not hole.active) then dl:AddRectFilled({ x, y }, { x + w, y + h }, col(10, 11, 18, 0.55), 3); end
    if (hole.active) then dl:AddRect({ x - 1, y - 1 }, { x + w + 1, y + h + 1 }, U.gold, 3, 0, 2); end
    local mx = px(hole.casts);
    dl:AddRectFilled({ mx - 1.5, y - 3 }, { mx + 1.5, y + h + 3 }, U.mark, 1);
    imgui.Dummy({ w, h });
    if (imgui.IsItemHovered()) then
        imgui.SetTooltip('Casts at this fishing spot (white line = you)\nGreen, casts 1-15: 8% school chance per cast\nBlue, casts 16-40: 5% per cast\nGrey, casts 41-75: 3% per cast\nRed, cast 76+: exhausted (no schools, only half your casts get a bite)\nEach fishing spot can have one school.');
    end
end

----------------------------------------------------------------------------
-- Fish detail (Fish tab, also opened from other tabs)
----------------------------------------------------------------------------
local function fish_where(id)
    local out = {};
    for zid, z in pairs(D.zones) do
        for aid, a in pairs(z.areas) do
            for _, row in ipairs(D.groups[a.g] or {}) do
                if (row[1] == id) then out[#out + 1] = { zid = zid, aid = aid, area = a.n, rarity = row[2] }; break; end
            end
        end
    end
    table.sort(out, function (a, b)
        local na, nb = zone_name(a.zid), zone_name(b.zid);
        if (na ~= nb) then return na < nb; end
        return a.aid < b.aid;
    end);
    return out;
end

local function open_fish(id)
    ui.sel_fish = id;
    ui.tab_req = 'Fish';
    cfg.show_main = true;
end

local function fish_tags(f)
    local t = {};
    t[#t + 1] = (f.sz == 1) and 'Large' or 'Small';
    if (f.lg == 1) then t[#t + 1] = 'Legendary'; end
    if (f.it == 1) then t[#t + 1] = 'Item'; end
    if (f.ki > 0) then t[#t + 1] = 'Needs a key item'; end
    if (f.qo == 1) then t[#t + 1] = 'Quest only'; end
    if (L.has(f.fl, 1)) then t[#t + 1] = 'Shellfish'; end
    return table.concat(t, '  |  ');
end

local function difficulty_text(id)
    local d = L.difficulty(D, id, S.skill, S.gear, S.rod);
    local lbl, i = L.difficulty_label(d);
    return d, lbl, DIFF_COL[i];
end

-- Skill-ups stop at the guild rank's cap and at 100 (the highest fishing skill).
local function skill_capped()
    return S.capped or S.skill_raw >= math.min(100, L.rank_cap(S.rank));
end
local function skillup_now(f)
    if (skill_capped()) then return 0; end
    return L.skillup_chance(f.lv, S.skill_raw, S.zinfo and S.zinfo.city, S.rod);
end
local function no_skillup_reason(f)
    if (skill_capped()) then
        if (S.skill_raw >= 100) then return 'No skill-ups: your fishing skill is maxed at 100.'; end
        return ('No skill-ups: you are at your guild rank\'s cap (%d). Rank up at the Fishermen\'s Guild.'):format(L.rank_cap(S.rank));
    end
    if (f.lv <= S.skill_raw) then return 'No skill-ups: this fish is at or below your skill.'; end
    return 'No skill-ups yet: more than 50 levels above your skill.';
end

local function draw_fish_detail(id)
    local f = D.fish[id];
    if (f == nil) then imgui.TextDisabled('Pick a fish on the left.'); return; end
    draw_icon(id, 32);
    imgui.SameLine();
    imgui.BeginGroup();
    heading(item_name(id), K.gold, 'title', 1.35);
    imgui.TextColored(K.muted, fish_tags(f));
    imgui.EndGroup();
    local each = D.sell[id] or 0;
    imgui.TextColored(K.muted, 'NPC sell:'); imgui.SameLine();
    if (each > 0) then imgui.TextColored(K.gold, ('%s gil each'):format(commas(each)));
    else imgui.TextDisabled('can\'t be sold to a vendor'); end
    imgui.Separator();

    -- For you
    if (f.it == 0) then
        local d, lbl, c = difficulty_text(id);
        imgui.Text(('Fish level %d'):format(f.lv));
        imgui.SameLine(); imgui.TextColored(K.muted, ('(your fishing skill: %d)'):format(S.skill));
        imgui.Text('Mini-game difficulty for you:'); imgui.SameLine(); imgui.TextColored(c, ('%s (%d out of 100)'):format(lbl, d));
        tip('Based on how far this fish is above or below your skill. Fishing gear counts twice here.\nLarge fish +8, legendary fish +8.');
        local up = skillup_now(f);
        if (up > 0) then
            imgui.Text('Skill-up chance per catch:'); imgui.SameLine(); imgui.TextColored(K.green, pct(up));
            imgui.SameLine(); imgui.TextColored(K.gold, ('(%d%% with a Perfect catch)'):format(L.PERFECT_SKILLUP * 100));
            tip('Perfect catch: the fish never leaves your catch zone after the first half second.');
        else
            local n = L.multi_catch(D, id, S.skill, S.gear, S.rod);
            imgui.TextColored(K.muted, 'Skill-up: N/A  -  ' .. no_skillup_reason(f));
            if (f.lv <= S.skill_raw) then
                imgui.TextColored(K.green, ('A Perfect catch gives you 1 extra fish.%s'):format(n > 1 and (' You also catch %d at a time.'):format(n) or ''));
            elseif (skill_capped()) then
                imgui.TextColored(K.dim, 'A Perfect catch gives no bonus on this fish while your skill is capped.');
            end
        end
    else
        imgui.TextColored(K.muted, 'This is an item, not a fish: no mini-game, just press ENTER to reel it in.');
    end
    imgui.Spacing();

    -- Best times
    if (imgui.CollapsingHeader('Best Time', ImGuiTreeNodeFlags_DefaultOpen)) then
        local c = { moon = S.date and S.date.moon or 0, hour = S.date and S.date.hour or 12, month = S.date and S.date.month or 1 };
        local mm_, hm, mo = L.fish_time_mods(D, id, c);
        local function line(label, text, now)
            imgui.TextColored(K.muted, label); imgui.SameLine(90); imgui.Text(text);
            imgui.SameLine();
            local cc = (now >= 1.1) and K.green or ((now <= 0.6) and K.red or K.muted);
            imgui.TextColored(cc, (now >= 1.1) and '  good right now' or ((now <= 0.6) and '  poor right now' or '  average right now'));
            tip(('Bite multiplier right now: x%.2f (range 0.25 to 1.25)'):format(now));
        end
        line('Hours', L.HOUR_TEXT[f.hp] or 'Any time', hm);
        line('Moon', L.MOON_TEXT[f.mp] or 'Any moon', mm_);
        line('Season', L.MONTH_TEXT[f.mo] or 'All year', mo);
    end

    -- Bait
    if (imgui.CollapsingHeader('Bait and Lures', ImGuiTreeNodeFlags_DefaultOpen)) then
        local baits = {};
        for b, p in pairs(D.aff[id] or {}) do baits[#baits + 1] = { id = b, p = p }; end
        table.sort(baits, function (a, b) if (a.p ~= b.p) then return a.p > b.p; end return a.id < b.id; end);
        if (#baits == 0) then imgui.TextDisabled('No bait hooks this.'); end
        if (#baits > 0 and imgui.BeginTable('##baits', 4, bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit))) then
            imgui.TableSetupColumn('Bait', ImGuiTableColumnFlags_WidthStretch);
            imgui.TableSetupColumn('Type');
            imgui.TableSetupColumn('Strength');
            imgui.TableSetupColumn('You Have');
            imgui.TableHeadersRow();
            for _, b in ipairs(baits) do
                local bd = D.bait[b.id];
                imgui.TableNextRow();
                imgui.TableNextColumn(); draw_icon(b.id, 16); imgui.SameLine();
                imgui.TextColored((S.bait == b.id) and K.gold or K.text, item_name(b.id));
                imgui.TableNextColumn(); imgui.TextColored(K.muted, (bd and bd.t == 1) and 'Lure' or 'Bait');
                imgui.TableNextColumn(); imgui.TextColored(b.p >= 3 and K.green or (b.p == 2 and K.blue or K.muted), stars(b.p));
                tip(('Strength %d of 3: +%d to the hook chance'):format(b.p, ({ 35, 65, 80 })[b.p] or 0));
                imgui.TableNextColumn();
                local n = S.owned[b.id] or 0;
                if (S.bait == b.id) then imgui.TextColored(K.gold, 'Equipped');
                elseif (n > 0) then imgui.TextColored(K.green, tostring(n));
                else imgui.TextDisabled('-'); end
            end
            imgui.EndTable();
        end
    end

    -- Rods
    if (f.it == 0 and imgui.CollapsingHeader('Rods', ImGuiTreeNodeFlags_DefaultOpen)) then
        imgui.TextColored(K.muted, 'On Timeless, winning the mini-game always lands the fish: rods never break and lines never snap.');
        imgui.TextColored(K.muted, 'Using a rod sized for this fish avoids a small hook-chance penalty.');
        local rods = {};
        for rid, r in pairs(D.rods) do
            local fit, rank;
            if (r.lg == 1) then fit, rank = 'Good for any fish', 0;
            elseif (r.sz == f.sz) then fit, rank = 'Right size', 1;
            elseif (r.sz > f.sz) then fit, rank = 'Too big (-3 hook chance)', 2;
            else fit, rank = 'Too small (-5 hook chance)', 3; end
            rods[#rods + 1] = { id = rid, fit = fit, rank = rank };
        end
        table.sort(rods, function (a, b) if (a.rank ~= b.rank) then return a.rank < b.rank; end return a.id > b.id; end);
        if (imgui.BeginTable('##rods', 3, bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit))) then
            imgui.TableSetupColumn('Rod', ImGuiTableColumnFlags_WidthStretch);
            imgui.TableSetupColumn('Fit');
            imgui.TableSetupColumn('You Have');
            imgui.TableHeadersRow();
            for _, r in ipairs(rods) do
                if (r.rank <= 1 or S.rod == r.id or (S.owned[r.id] or 0) > 0) then
                    imgui.TableNextRow();
                    imgui.TableNextColumn(); draw_icon(r.id, 16); imgui.SameLine();
                    imgui.TextColored((S.rod == r.id) and K.gold or K.text, item_name(r.id));
                    imgui.TableNextColumn(); imgui.TextColored(r.rank <= 1 and K.green or K.amber, r.fit);
                    if (L.rod_family(r.id) ~= nil) then tip('Also makes fish well below your skill bite more often.'); end
                    imgui.TableNextColumn();
                    if (S.rod == r.id) then imgui.TextColored(K.gold, 'Equipped');
                    elseif ((S.owned[r.id] or 0) > 0) then imgui.TextColored(K.green, 'Yes');
                    else imgui.TextDisabled('-'); end
                end
            end
            imgui.EndTable();
        end
    end

    -- Where
    if (imgui.CollapsingHeader('Where to Find It', ImGuiTreeNodeFlags_DefaultOpen)) then
        local w = fish_where(id);
        if (#w == 0) then imgui.TextDisabled('Not in any fishing spot on this server.'); end
        for i, e in ipairs(w) do
            local here = (e.zid == S.zone and e.aid == S.area_id);
            local label = ('%s  -  %s##w%d'):format(zone_name(e.zid), e.area, i);
            if (here) then imgui.PushStyleColor(ImGuiCol_Text, K.gold); end
            if (imgui.Selectable(label, false)) then ui.sel_zone = e.zid; ui.tab_req = 'Zones'; end
            if (here) then imgui.PopStyleColor(); end
            tip(here and 'You are fishing here now.' or 'Open in the Zones tab.');
        end
    end
end

----------------------------------------------------------------------------
-- Tabs
----------------------------------------------------------------------------
-- A side panel with room around its contents (padding on all four sides).
local function panel_begin(id, width, border)
    imgui.PushStyleVar(ImGuiStyleVar_WindowPadding, { 14, 12 });
    imgui.BeginChild(id, { width, 0 }, bit.bor(ImGuiChildFlags_AlwaysUseWindowPadding or 0, border and (ImGuiChildFlags_Borders or 1) or 0));
    imgui.PopStyleVar();
end

-- Real per-cast odds right now (fish, items, monsters, no bite), with the fishing-hole state applied.
local function odds_now()
    local o = L.hole_odds(hole, S.zone, S.pos.x, S.pos.z, os.time());
    local exhausted = (not o.fresh) and (not hole.active) and (not o.pond) and o.next >= L.EXHAUSTED_AT;
    return L.cast_odds(S.spot, hole.active, exhausted), exhausted;
end

local function fish_row_table(list, id_prefix, show_share)
    local cols = show_share and 7 or 6;
    if (not imgui.BeginTable(id_prefix, cols, bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit))) then return; end
    imgui.TableSetupColumn('Fish', ImGuiTableColumnFlags_WidthStretch);
    imgui.TableSetupColumn('Lv');
    imgui.TableSetupColumn('Size');
    imgui.TableSetupColumn('Difficulty');
    imgui.TableSetupColumn('Skill-Up');
    imgui.TableSetupColumn('Per Catch');
    if (show_share) then imgui.TableSetupColumn('Chance'); end
    imgui.TableHeadersRow();
    for i, e in ipairs(list) do
        local f = D.fish[e.id];
        imgui.TableNextRow();
        imgui.TableNextColumn(); draw_icon(e.id, 18); imgui.SameLine();
        if (imgui.Selectable(('%s##%s%d'):format(item_name(e.id), id_prefix, i), false, ImGuiSelectableFlags_SpanAllColumns)) then open_fish(e.id); end
        tip('Click for bait, rods, where to find it and best times.');
        imgui.TableNextColumn(); imgui.Text(tostring(f.lv));
        imgui.TableNextColumn(); imgui.TextColored(K.muted, (f.lg == 1) and 'Legend' or ((f.sz == 1) and 'Large' or 'Small'));
        imgui.TableNextColumn();
        local d, lbl, c = difficulty_text(e.id);
        imgui.TextColored(c, lbl);
        tip(('Mini-game difficulty for you: %d out of 100'):format(d));
        imgui.TableNextColumn();
        local up = skillup_now(f);
        if (up > 0) then
            imgui.TextColored(K.green, pct(up));
            tip('Skill-up chance per catch (75% with a Perfect catch).');
        else
            imgui.TextColored(K.dim, 'N/A');
            tip(no_skillup_reason(f));
        end
        imgui.TableNextColumn();
        local n = L.multi_catch(D, e.id, S.skill, S.gear, S.rod);
        imgui.TextColored(n > 1 and K.green or K.dim, tostring(n));
        tip('Fish landed per catch: 2 when the fish is 30+ levels below you, 3 when 50+ below.');
        if (show_share) then
            imgui.TableNextColumn();
            imgui.TextColored(K.blue, pct1(show_share.fish[e.id] or 0));
            tip('Chance that a bite here is this fish (with your rod, bait and the current time).');
        end
    end
    imgui.EndTable();
end

local function tab_here()
    if (S.zinfo == nil) then
        imgui.TextColored(K.muted, ('%s has no fishing.'):format(zone_name(S.zone)));
        imgui.TextWrapped('Use the Zones or Fish tab to plan your next trip.');
        return;
    end
    heading(zone_name(S.zone), K.gold, 'title', 1.2);
    imgui.SameLine();
    imgui.TextColored(K.muted, S.area and ('-  fishing area: ' .. S.area.n) or '-  you are not in a fishing area');
    if (S.zinfo.city) then imgui.SameLine(); imgui.TextColored(K.dim, '(town: more items, no monsters)'); end

    imgui.Text('Rod: '); imgui.SameLine();
    imgui.TextColored(S.has_rod and K.text or K.red, S.rod > 0 and item_name(S.rod) or 'none');
    imgui.SameLine(); imgui.Text('   Bait: '); imgui.SameLine();
    imgui.TextColored(D.bait[S.bait] and K.text or K.red, S.bait > 0 and item_name(S.bait) or 'none');
    imgui.Separator();

    local sp = S.spot;
    if (sp == nil) then imgui.TextDisabled('Walk to one of this zone\'s fishing areas (listed in the Zones tab).'); return; end
    if (S.bait == 0 or D.bait[S.bait] == nil) then
        imgui.TextColored(K.amber, 'Equip bait or a lure to see what bites.');
    elseif (sp.nothing) then
        imgui.TextColored(K.red, 'Nothing here bites on this bait. Try one of the baits listed below.');
    else
        local od, exhausted = odds_now();
        imgui.Text('Current Hook Ratio:');
        imgui.SameLine(); imgui.TextColored(K.blue, ('Fish %s'):format(pct(od.fishp)));
        imgui.SameLine(); imgui.TextColored(K.muted, ('  Items %s'):format(pct(od.item)));
        imgui.SameLine(); imgui.TextColored(K.red, ('  Monsters %s'):format(pct(od.mob)));
        if (od.none > 0) then imgui.SameLine(); imgui.TextColored(K.dim, ('  No bite %s'):format(pct(od.none))); end
        tip(hole.active and 'A school of fish is active: every cast hooks a fish.'
            or (exhausted and 'This fishing spot is exhausted: half of your casts get no bite. Move 20+ yalms for a fresh fishing spot.'
            or 'Chance per cast with your rod, bait, skill and the current time. Every cast gets a bite on Timeless.'));
    end
    imgui.Spacing();
    if (#sp.fish > 0) then
        heading('Available Targets', K.gold);
        imgui.TextColored(K.dim, 'Current Gear Targets');
        tip('Fish your current rod and bait can hook here, with the chance per cast.');
        fish_row_table(sp.fish, '##here', (odds_now()));
    end
    if (#sp.other > 0) then
        imgui.Spacing();
        imgui.TextColored(K.muted, ('Other Available Fish (%d)'):format(#sp.other));
        tip('Fish in this fishing area that need a different bait or a key item.');
        local rows = {};
        for _, o in ipairs(sp.other) do
            local best, bp = nil, 0;
            for b, p in pairs(D.aff[o.id] or {}) do
                local score = p * 10 + (((S.owned[b] or 0) > 0) and 5 or 0);
                if (score > bp) then best, bp = b, score; end
            end
            rows[#rows + 1] = { id = o.id, bait = best, ki = o.ki };
        end
        if (imgui.BeginTable('##other', 3, bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit))) then
            imgui.TableSetupColumn('Fish', ImGuiTableColumnFlags_WidthStretch);
            imgui.TableSetupColumn('Lv');
            imgui.TableSetupColumn('Best Bait');
            imgui.TableHeadersRow();
            for i, r in ipairs(rows) do
                imgui.TableNextRow();
                imgui.TableNextColumn(); draw_icon(r.id, 18); imgui.SameLine();
                if (imgui.Selectable(('%s##ot%d'):format(item_name(r.id), i), false, ImGuiSelectableFlags_SpanAllColumns)) then open_fish(r.id); end
                imgui.TableNextColumn(); imgui.Text(tostring(D.fish[r.id].lv));
                imgui.TableNextColumn();
                if (r.ki) then imgui.TextColored(K.amber, 'needs a key item');
                elseif (r.bait) then imgui.TextColored(((S.owned[r.bait] or 0) > 0) and K.green or K.muted, item_name(r.bait));
                else imgui.TextDisabled('-'); end
            end
            imgui.EndTable();
        end
    end
    if (#sp.items > 0 and imgui.CollapsingHeader(('Items (%d)'):format(#sp.items))) then
        for _, it in ipairs(sp.items) do draw_icon(it.id, 16); imgui.SameLine(); imgui.Text(item_name(it.id)); end
    end
    if (#sp.mobs > 0 and imgui.CollapsingHeader(('Monsters (%d)'):format(#sp.mobs))) then
        for _, m in ipairs(sp.mobs) do
            imgui.TextColored(K.red, m.n); imgui.SameLine(); imgui.TextColored(K.muted, ('Lv %d'):format(m.lv));
            if (m.b > 0) then imgui.SameLine(); imgui.TextColored(K.muted, ('- only with %s'):format(item_name(m.b))); end
        end
    end
end

local function tab_conditions()
    local d = S.date;
    if (d == nil) then return; end
    local raw = d.raw;

    -- Moon phase
    draw_moon(30, d.moon_pct, d.moon_dir);
    imgui.SameLine();
    imgui.BeginGroup();
    heading(L.MOON_NAMES[d.moon], K.white, 'title', 1.35);
    local dirtxt = (d.moon_dir == 2) and 'waxing' or ((d.moon_dir == 1) and 'waning' or 'turning');
    imgui.TextColored(K.muted, ('%d%% full, %s  -  next phase in %s'):format(d.moon_pct, dirtxt, mins(L.moon_left(raw))));
    local nn, nf = L.next_moon(raw, L.MOON_NEW), L.next_moon(raw, L.MOON_FULL);
    imgui.TextColored(K.muted, ('New Moon %s  -  Full Moon %s'):format(nn and ('in ' .. mins(nn)) or 'now', nf and ('in ' .. mins(nf)) or 'now'));
    tip('Real time (one Vana\'diel day is 57.6 real minutes).');
    imgui.EndGroup();
    imgui.TextColored(K.dim, ('%s, %s %d  -  %02d:%02d  -  Weather: %s'):format(L.WEEKDAYS[d.weekday], L.MONTHS[d.month], d.day, d.hour, d.minute, WEATHER[S.weather] or '?'));
    imgui.Spacing();

    -- Effects right now
    heading('Current Effects', K.gold);
    local moon_cut = (d.moon == L.MOON_NEW or d.moon == L.MOON_FULL);
    local mp = L.moon_pools(d.moon);
    local function level(v) if (v >= 0.67) then return 'High'; elseif (v <= 0.33) then return 'Low'; end return 'Normal'; end
    local town = S.zinfo ~= nil and S.zinfo.city;
    if (imgui.BeginTable('##mooneff', 3, bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit))) then
        imgui.TableSetupColumn('Effect');
        imgui.TableSetupColumn('Now');
        imgui.TableSetupColumn('Best At', ImGuiTableColumnFlags_WidthStretch);
        imgui.TableHeadersRow();
        local function row(name, now, colour, best, tiptext)
            imgui.TableNextRow();
            imgui.TableNextColumn(); imgui.Text(name);
            imgui.TableNextColumn(); imgui.TextColored(colour, now);
            if (tiptext) then tip(tiptext); end
            imgui.TableNextColumn(); imgui.TextColored(K.dim, best);
        end
        row('Bite speed', moon_cut and 'Faster (4 s sooner)' or 'Normal', moon_cut and K.green or K.muted, 'New and Full Moon');
        local lf = level(mp.fish);
        row('Fish', lf, (lf == 'High') and K.green or ((lf == 'Low') and K.amber or K.muted), 'Full Moon',
            'How often a cast hooks a fish, compared with other moons.');
        local li = level(mp.item);
        row('Items', li, K.muted, 'Half moons', 'How often a cast hooks an item (junk or treasure).');
        if (town) then
            row('Monsters', 'None in town', K.dim, 'New Moon');
        else
            local lm = level(mp.mob);
            row('Monsters', lm, (lm == 'High') and K.red or K.muted, 'New Moon', 'How often a cast hooks a monster.');
        end
        row('Skill-ups', 'No effect', K.dim, '-');
        imgui.EndTable();
    end
    -- fish at this spot that like / dislike this moon
    if (S.spot ~= nil and (#S.spot.fish + #S.spot.other) > 0) then
        local likes, dislikes = {}, {};
        local all = {};
        for _, e in ipairs(S.spot.fish) do all[#all + 1] = e.id; end
        for _, e in ipairs(S.spot.other) do all[#all + 1] = e.id; end
        for _, id in ipairs(all) do
            local f = D.fish[id];
            if (f.mp ~= 0) then
                local m = L.moon_mod(f.mp, d.moon);
                if (m >= 1.0) then likes[#likes + 1] = item_name(id);
                elseif (m <= 0.6) then dislikes[#dislikes + 1] = item_name(id); end
            end
        end
        if (#likes > 0) then imgui.TextColored(K.green, 'Biting more this moon:'); imgui.SameLine(); imgui.TextWrapped(table.concat(likes, ', ')); end
        if (#dislikes > 0) then imgui.TextColored(K.amber, 'Biting less this moon:'); imgui.SameLine(); imgui.TextWrapped(table.concat(dislikes, ', ')); end
    end
    imgui.Spacing();

    -- Bite Timer
    local w = L.bite_wait(d.moon, d.hour, S.waist, hole.active);
    heading('Bite Timer', K.gold);
    imgui.Text(('A fish bites about %d seconds after you cast.'):format(w));
    tip('Normally 13 seconds. It can never go below 7 seconds (4 in a school of fish).');
    imgui.TextColored(K.muted, 'These make it faster (green = working for you now):');
    local function speed(on, text)
        imgui.TextColored(on and K.green or K.dim, (on and '+ ' or '- ') .. text);
    end
    speed(moon_cut, 'New or Full Moon: 4 seconds faster');
    speed(d.hour == 5 or d.hour == 17, 'Casting at 05:00 or 17:00 (game time): 1 second faster');
    speed(S.waist == L.FISHERS_ROPE, 'Wearing a Fisher\'s Rope: 1 second faster');
    speed(hole.active, 'Fishing a school of fish: half the wait');
    imgui.Spacing();

    -- Weather
    if (S.weather == 6) then imgui.TextColored(K.green, 'Rain: fish bite 10% more often.');
    elseif (S.weather == 7) then imgui.TextColored(K.green, 'Squall: fish bite 20% more often.');
    else imgui.TextColored(K.dim, 'Weather: rain makes fish bite 10% more often, a squall 20%.'); end
end

local function tab_zones()
    -- List width: fits the longest zone name (e.g. "Ship bound for Selbina (Pirates)") at the current text size.
    local lw = 0;
    for zid in pairs(D.zones) do lw = math.max(lw, imgui.CalcTextSize(zone_name(zid)) or 0); end
    imgui.BeginChild('##zlist', { math.max(210, lw + 36), 0 }, ImGuiChildFlags_Borders or 1);
    heading('Fishing Zones', K.gold);
    imgui.PushItemWidth(-1);
    imgui.InputText('##zf', ui.zone_filter, 48);
    imgui.PopItemWidth();
    tip('Type to filter the zones.');
    local q = (ui.zone_filter[1] or ''):lower();
    local ids = {};
    for zid in pairs(D.zones) do ids[#ids + 1] = zid; end
    table.sort(ids, function (a, b) return zone_name(a) < zone_name(b); end);
    for _, zid in ipairs(ids) do
        local n = zone_name(zid);
        if (q == '' or n:lower():find(q, 1, true)) then
            local here = (zid == S.zone);
            if (here) then imgui.PushStyleColor(ImGuiCol_Text, K.gold); end
            if (imgui.Selectable(n .. '##z' .. zid, ui.sel_zone == zid)) then ui.sel_zone = zid; end
            if (here) then imgui.PopStyleColor(); end
        end
    end
    imgui.EndChild();
    imgui.SameLine();
    panel_begin('##zdetail', 0, true);
    local zid = ui.sel_zone or S.zone;
    local z = D.zones[zid];
    if (z == nil) then
        imgui.TextDisabled('Pick a zone.');
    else
        heading(zone_name(zid), K.gold, 'title', 1.2);
        if (z.city) then imgui.SameLine(); imgui.TextColored(K.dim, '[town]'); end
        local aids = {};
        for aid in pairs(z.areas) do aids[#aids + 1] = aid; end
        table.sort(aids);
        for _, aid in ipairs(aids) do
            local a = z.areas[aid];
            local list = {};
            for _, row in ipairs(D.groups[a.g] or {}) do
                if (D.fish[row[1]] and D.fish[row[1]].it == 0) then list[#list + 1] = { id = row[1] }; end
            end
            table.sort(list, function (x, y) return D.fish[x.id].lv < D.fish[y.id].lv; end);
            local here = (zid == S.zone and aid == S.area_id);
            local hdr = ('%s  (%d fish)%s##a%d'):format(a.n, #list, here and '  - you are here' or '', aid);
            if (imgui.CollapsingHeader(hdr, (here or #aids == 1) and ImGuiTreeNodeFlags_DefaultOpen or 0)) then
                fish_row_table(list, '##za' .. aid, false);
            end
        end
        -- Items that can be fished up anywhere in this zone
        local items, seen = {}, {};
        for _, aid in ipairs(aids) do
            for _, row in ipairs(D.groups[z.areas[aid].g] or {}) do
                local f = D.fish[row[1]];
                if (f ~= nil and f.it == 1 and f.qo == 0 and not seen[row[1]]) then seen[row[1]] = true; items[#items + 1] = row[1]; end
            end
        end
        table.sort(items, function (x, y) return item_name(x) < item_name(y); end);
        if (imgui.CollapsingHeader(('Items (%d)##zitems'):format(#items))) then
            if (#items == 0) then imgui.TextColored(K.dim, 'No items to fish up here.'); end
            for _, id in ipairs(items) do draw_icon(id, 16); imgui.SameLine(); imgui.Text(item_name(id)); end
        end
        local mobs = {};
        for _, m in ipairs(z.mobs or {}) do if (m.qo == 0) then mobs[#mobs + 1] = m; end end
        if (imgui.CollapsingHeader(('Monsters (%d)##zmobs'):format(#mobs))) then
            if (#mobs == 0) then imgui.TextColored(K.dim, z.city and 'No monsters in towns.' or 'No monsters to hook here.'); end
            for _, m in ipairs(mobs) do
                imgui.TextColored(m.nm == 1 and K.amber or K.red, m.n); imgui.SameLine();
                imgui.TextColored(K.muted, ('Lv %d%s%s'):format(m.lv, m.nm == 1 and '  (NM)' or '', m.b > 0 and ('  - bait: ' .. item_name(m.b)) or ''));
            end
        end
    end
    imgui.EndChild();
end

local search_cache = { q = nil, list = {} };
local function search_list(q)
    if (search_cache.q == q) then return search_cache.list; end
    local list = {};
    for id, f in pairs(D.fish) do
        local n = item_name(id):lower();
        local hit = (q == '') or n:find(q, 1, true) ~= nil;
        if (not hit and #q >= 3) then
            for b in pairs(D.aff[id] or {}) do
                if (item_name(b):lower():find(q, 1, true)) then hit = true; break; end
            end
        end
        if (hit and (f.it == 0 or q ~= '')) then list[#list + 1] = id; end
    end
    table.sort(list, function (a, b) return item_name(a) < item_name(b); end);
    search_cache.q, search_cache.list = q, list;
    return list;
end

local function tab_search()
    imgui.BeginChild('##slist', { 230, 0 }, ImGuiChildFlags_Borders or 1);
    imgui.PushItemWidth(-1);
    imgui.InputText('##search', ui.search, 48);
    imgui.PopItemWidth();
    tip('Fish name, or a bait name to see what it hooks.');
    local q = (ui.search[1] or ''):lower();
    local list = search_list(q);
    imgui.TextColored(K.dim, ('%d results'):format(#list));
    for _, id in ipairs(list) do
        local f = D.fish[id];
        draw_icon(id, 18); imgui.SameLine();
        local c = (f.lv > S.skill + 10) and K.muted or K.text;
        imgui.PushStyleColor(ImGuiCol_Text, c);
        if (imgui.Selectable(('%s##s%d'):format(item_name(id), id), ui.sel_fish == id)) then ui.sel_fish = id; end
        imgui.PopStyleColor();
        imgui.SameLine(190); imgui.TextColored(K.dim, f.it == 1 and 'item' or tostring(f.lv));
    end
    imgui.EndChild();
    imgui.SameLine();
    panel_begin('##sdetail', 0, true);
    if (ui.sel_fish == nil and #list > 0) then ui.sel_fish = list[1]; end
    draw_fish_detail(ui.sel_fish);
    imgui.EndChild();
end

local function tab_skill()
    heading(tostring(S.skill), K.white, 'title', 2.0);
    imgui.SameLine();
    imgui.BeginGroup();
    imgui.TextColored(K.muted, 'fishing skill (with gear)');
    imgui.Text(('Your skill: %d'):format(S.skill_raw)); imgui.SameLine();
    imgui.TextColored(S.gear > 0 and K.green or K.dim, ('+ %d from gear'):format(S.gear));
    imgui.EndGroup();
    local cap = L.rank_cap(S.rank);
    imgui.Text(('Guild rank: %s - your skill can go up to %d at this rank'):format(L.RANKS[S.rank] or tostring(S.rank), cap));
    if (S.capped or S.skill_raw >= cap) then
        imgui.TextColored(K.amber, 'You have reached this rank\'s limit. Rank up at the Fishermen\'s Guild to keep gaining skill.');
    end
    local lo = L.rank_cap(S.rank - 1);
    if (S.rank == 0) then lo = 0; end
    imgui.ProgressBar(math.max(0, math.min(1, (S.skill_raw - lo) / math.max(1, cap - lo))), { -1, 14 }, ('%d / %d'):format(S.skill_raw, cap));
    tip('Progress toward this rank\'s limit.');
    imgui.TextColored(K.muted, 'Gear skill helps you hook fish and makes the mini-game easier (wider catch zone).');
    imgui.TextColored(K.muted, 'Skill-up chances use your own skill, without gear.');

    imgui.Separator();
    heading('Fishing Gear', K.gold);
    if (imgui.BeginTable('##gear', 4, bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit))) then
        imgui.TableSetupColumn('Item', ImGuiTableColumnFlags_WidthStretch);
        imgui.TableSetupColumn('Slot');
        imgui.TableSetupColumn('Effect');
        imgui.TableSetupColumn('Status');
        imgui.TableHeadersRow();
        local ids = {};
        for id in pairs(GEAR_SLOT) do ids[#ids + 1] = id; end
        table.sort(ids, function (a, b) if (GEAR_SLOT[a] ~= GEAR_SLOT[b]) then return GEAR_SLOT[a] < GEAR_SLOT[b]; end return a < b; end);
        local worn = {};
        for _, g in ipairs(S.gear_list) do worn[g.id] = true; end
        for _, id in ipairs(ids) do
            imgui.TableNextRow();
            imgui.TableNextColumn(); draw_icon(id, 18); imgui.SameLine();
            imgui.TextColored(worn[id] and K.gold or K.text, item_name(id));
            imgui.TableNextColumn(); imgui.TextColored(K.muted, SLOT_NAMES[GEAR_SLOT[id]] or '');
            imgui.TableNextColumn();
            local fx = {};
            if (D.gear[id]) then fx[#fx + 1] = ('+%d skill'):format(D.gear[id]); end
            if (GEAR_OTHER[id]) then fx[#fx + 1] = GEAR_OTHER[id]; end
            imgui.TextColored(K.green, table.concat(fx, ', '));
            imgui.TableNextColumn();
            if (worn[id]) then imgui.TextColored(K.gold, 'Equipped');
            elseif ((S.owned[id] or 0) > 0) then imgui.TextColored(K.blue, 'In your bags');
            else imgui.TextDisabled('-'); end
        end
        imgui.EndTable();
    end

    -- Legendary rods
    imgui.Spacing();
    heading('Legendary Rods', K.gold);
    imgui.TextColored(K.muted, 'They add no fishing skill, but help in other ways:');
    if (imgui.BeginTable('##rods4', 5, bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit))) then
        imgui.TableSetupColumn('Rod', ImGuiTableColumnFlags_WidthStretch);
        imgui.TableSetupColumn('Lv 100+ Fish');
        imgui.TableSetupColumn('Low Fish');
        imgui.TableSetupColumn('Any Size');
        imgui.TableSetupColumn('Status');
        imgui.TableHeadersRow();
        for _, r in ipairs({ { 17386, '+3', 'More bites' }, { 19320, '+4', 'More bites' }, { 17011, '+5', 'Most bites' }, { 19321, '+6', 'Most bites' } }) do
            local id = r[1];
            imgui.TableNextRow();
            imgui.TableNextColumn(); draw_icon(id, 18); imgui.SameLine();
            imgui.TextColored(S.rod == id and K.gold or K.text, item_name(id));
            imgui.TableNextColumn(); imgui.TextColored(K.green, r[2]);
            tip(('Counts as %s fishing skill in the mini-game against fish above level 100, on top of your gear.'):format(r[2]));
            imgui.TableNextColumn(); imgui.TextColored(K.green, r[3]);
            tip('Fish more than 7 levels below your skill bite much more often. The further below, the bigger the boost (Ebisu rods more than Lu Shang\'s).');
            imgui.TableNextColumn(); imgui.TextColored(K.green, 'Yes');
            tip('No hook-chance penalty for a rod that is too big or too small for the fish.');
            imgui.TableNextColumn();
            if (S.rod == id) then imgui.TextColored(K.gold, 'Equipped');
            elseif ((S.owned[id] or 0) > 0) then imgui.TextColored(K.blue, 'In your bags');
            else imgui.TextDisabled('-'); end
        end
        imgui.EndTable();
    end
end

local function tab_schools()
    local o = L.hole_odds(hole, S.zone, S.pos.x, S.pos.z, os.time());
    heading('How Schools of Fish Work', K.gold);
    imgui.TextWrapped('Your fishing spot starts where you make your first cast, and every cast within 20 yalms of it counts toward that same fishing spot. Each cast has a small chance to find a school of fish, and each fishing spot can only have one school (pond zones work differently: see below).');
    imgui.TextWrapped('A new fishing spot (back to 0 casts) starts when you cast 20 or more yalms away, change zones, or go 10 minutes without casting.');
    imgui.Spacing();

    heading('Current Fishing Spot', K.gold);
    local shown = o.fresh and 0 or hole.casts;
    if (o.fresh and hole.casts > 0) then
        imgui.Text('Cast #0');
        imgui.TextColored(K.blue, 'Your next cast starts a new fishing spot here.');
    else
        imgui.Text(('Cast #%d'):format(shown));
    end
    if (o.pond) then
        imgui.TextColored(K.blue, 'Pond zone: this whole zone is one fishing spot, and it never wears out.');
    else
        draw_hole_meter(math.max(200, avail_w() - 10), 14);
        imgui.TextColored(K.dim, 'Green: casts 1-15   Blue: 16-40   Grey: 41-75   Red: 76+ (exhausted)');
    end
    if (hole.casts > 0 and hole.zone == S.zone and not o.fresh and not o.pond) then
        local dx, dz = S.pos.x - hole.x, S.pos.z - hole.z;
        local dist = math.sqrt(dx * dx + dz * dz);
        imgui.Text(('You are %.1f yalms from where this fishing spot started (a new fishing spot starts at 20).'):format(dist));
        local idle = math.max(0, L.HOLE_IDLE - (os.time() - hole.last));
        imgui.Text(('If you stop casting, this fishing spot resets in %d:%02d.'):format(math.floor(idle / 60), idle % 60));
    end
    imgui.Spacing();

    if (hole.active) then
        local lo, hi, p = L.school_left(hole.school_casts);
        heading('School of Fish Active!', K.gold, 'title', 1.1);
        imgui.Text(('School cast #%d  -  %s'):format(hole.school_casts, casts_left(lo, hi)));
        imgui.Text(('Chance your next cast is still in the school: %s'):format(pct(p)));
        imgui.Text(('Fish caught from this school: %d'):format(hole.school_catches));
        if (imgui.Button('End school')) then let_school_go(); end
        tip('Let the school go now, for example to fish for items or monsters again. Also: /angler school end');
    elseif (o.pond) then
        if ((o.wait or 0) > 0) then
            imgui.Text(('Next school possible in %d:%02d.'):format(math.floor(o.wait / 60), o.wait % 60));
        else
            imgui.Text('Chance your next cast finds a school:'); imgui.SameLine(); imgui.TextColored(K.green, pct(o.now));
        end
    elseif (o.used) then
        imgui.TextColored(K.muted, 'This fishing spot already had its school. Move 20 or more yalms away to start a new fishing spot.');
    elseif (o.next >= L.EXHAUSTED_AT) then
        imgui.TextColored(K.red, 'This fishing spot is exhausted: no more schools, and only half your casts get a bite. Move to a new fishing spot!');
    else
        imgui.Text('Chance your next cast finds a school:'); imgui.SameLine(); imgui.TextColored(K.green, pct(o.now));
        imgui.Text('Chance of a school before this fishing spot is exhausted:'); imgui.SameLine(); imgui.TextColored(K.blue, pct(o.ahead));
    end
    imgui.Separator();
    heading('School Perks', K.gold);
    imgui.BulletText('Every cast hooks a fish (no items or monsters)');
    imgui.BulletText('Fish bite in half the time');
    imgui.BulletText('Lasts 6-12 casts after the one that finds it');
    imgui.BulletText('Ends early if you change zones, move 20+ yalms away, or stop casting for 5 minutes');
    imgui.BulletText('You can end it yourself any time with the End school button (or /angler school end)');
    heading('School Odds', K.gold);
    imgui.TextColored(K.muted, 'Each cast at a fishing spot has a set chance to turn up a school. The odds drop the longer you fish there.');
    if (imgui.BeginTable('##schoolodds', 2, bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit))) then
        imgui.TableSetupColumn('Casts');
        imgui.TableSetupColumn('Chance per Cast', ImGuiTableColumnFlags_WidthStretch);
        imgui.TableHeadersRow();
        for _, r in ipairs({ { '1-15', '8%', K.green }, { '16-40', '5%', K.blue }, { '41-75', '3%', K.muted }, { '76+', 'None - the fishing spot is exhausted', K.red } }) do
            imgui.TableNextRow();
            imgui.TableNextColumn(); imgui.TextColored(r[3], r[1]);
            imgui.TableNextColumn(); imgui.Text(r[2]);
        end
        imgui.EndTable();
    end
    imgui.TextColored(K.dim, 'About 97% of fishing spots turn up a school within 75 casts, and 71% within the first 15.');
    imgui.TextColored(K.dim, 'Once a fishing spot is exhausted, half your casts get no bite. Move 20 or more yalms to start a new one.');
    heading('Pond Zones', K.gold);
    local names = {};
    for _, n in pairs(L.POND_ZONES) do names[#names + 1] = n; end
    table.sort(names);
    imgui.TextWrapped('In these zones the water is too small to move 20 yalms, so the whole zone is one fishing spot. It never wears out, every cast has a 5% school chance, and a new school can come 5 minutes after the last one ended:');
    imgui.TextColored(K.muted, table.concat(names, ', '));
    imgui.Spacing();
    imgui.TextColored(K.dim, ('Schools found this session: %d'):format(session.schools));
    if (imgui.Button('Reset fishing spot tracker')) then hole = L.new_hole(); end
    tip('Only needed if this tracker disagrees with the game (for example after a server restart).');
end

local function tab_log()
    local mins_ = math.max(1, (os.time() - session.start) / 60);
    local hours = session_hours();
    heading(('Fish caught: %d'):format(session.fish), K.gold);
    imgui.TextColored(K.muted, 'Session time:'); imgui.SameLine();
    if (session.first) then
        local t = os.time() - session.first;
        imgui.TextColored(K.blue, ('%d:%02d:%02d'):format(math.floor(t / 3600), math.floor(t / 60) % 60, t % 60));
        tip('Time since your first cast this session. Use Reset session to start over.');
    else
        imgui.TextDisabled('starts with your first cast');
    end
    imgui.Text(('Casts %d   Catches %d   Items %d   Monsters %d   Lost %d'):format(session.casts, session.catches, session.items, session.monsters, session.lost));
    imgui.Text(('Skill gained %.1f   Schools found %d   %.1f catches per hour'):format(session.skill, session.schools, session.catches / mins_ * 60));
    if (imgui.Button('Reset session')) then reset_session(); end
    imgui.Separator();
    local by = {};
    for id, n in pairs(session.by) do by[#by + 1] = { id = id, n = n }; end
    table.sort(by, function (a, b) return a.n > b.n; end);
    if (#by == 0) then
        imgui.TextColored(K.muted, 'Nothing caught yet this session.');
    elseif (imgui.BeginTable('##catches', 5, bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit))) then
        imgui.TableSetupColumn('Catch', ImGuiTableColumnFlags_WidthStretch);
        imgui.TableSetupColumn('Caught');
        imgui.TableSetupColumn('Per Hour');
        imgui.TableSetupColumn('NPC Sell');
        imgui.TableSetupColumn('Total Gil');
        imgui.TableHeadersRow();
        local tn, tgil = 0, 0;
        for _, e in ipairs(by) do
            local each = D.sell[e.id] or 0;
            tn, tgil = tn + e.n, tgil + each * e.n;
            imgui.TableNextRow();
            imgui.TableNextColumn(); draw_icon(e.id, 18); imgui.SameLine(); imgui.Text(item_name(e.id));
            imgui.TableNextColumn(); imgui.Text(('x%d'):format(e.n));
            imgui.TableNextColumn(); imgui.TextColored(K.blue, ('%.0f'):format(e.n / hours));
            imgui.TableNextColumn();
            if (each > 0) then imgui.Text(('%s gil'):format(commas(each))); else imgui.TextDisabled('-'); end
            imgui.TableNextColumn();
            if (each > 0) then imgui.TextColored(K.gold, commas(each * e.n)); else imgui.TextDisabled('-'); end
        end
        imgui.TableNextRow();
        imgui.TableNextColumn(); imgui.TextColored(K.gold, 'Total');
        imgui.TableNextColumn(); imgui.TextColored(K.gold, ('x%d'):format(tn));
        imgui.TableNextColumn(); imgui.TextColored(K.blue, ('%.0f'):format(tn / hours));
        imgui.TableNextColumn(); imgui.TextColored(K.blue, ('%s/hr'):format(commas(tgil / hours)));
        imgui.TableNextColumn(); imgui.TextColored(K.gold, commas(tgil));
        imgui.EndTable();
    end
    imgui.TextColored(K.dim, 'Per Hour is projected from your pace since your first cast. NPC Sell is the base vendor price.');
    imgui.Separator();
    imgui.BeginChild('##log', { 0, 0 }, 0);
    for _, e in ipairs(session.log) do
        imgui.TextColored(K.dim, e.t); imgui.SameLine(); imgui.TextColored(e.c, e.text);
    end
    imgui.EndChild();
end

----------------------------------------------------------------------------
-- Windows
----------------------------------------------------------------------------
----------------------------------------------------------------------------
-- Window opacity, size and position (saved per character)
----------------------------------------------------------------------------
local WIN_DEFAULT = { main = { x = 60, y = 60, w = 660, h = 540 }, hud = { x = 20, y = 220, w = 340, h = 0 } };
local save_at = nil;                         -- debounced settings save (sliders and dragging change every frame)
local function save_soon() save_at = os.clock() + 1.0; end
local reset_pending = {};                    -- [key] = true: put that window back to its default place and size
local hud_fit = 0;                           -- frames left of fitting the HUD to its contents

local function alpha_of(key, default)
    local v = tonumber(cfg[key .. '_alpha']) or default;
    return math.max(0.2, math.min(1.0, v));
end

-- Before Begin: background opacity and the saved size / position.
local function window_prep(key, default_alpha, skip_size)
    local r, d = cfg[key .. '_rect'], WIN_DEFAULT[key];
    local reset = reset_pending[key];
    reset_pending[key] = nil;
    local cond = reset and ImGuiCond_Always or ImGuiCond_FirstUseEver;
    local src = (not reset and type(r) == 'table' and tonumber(r.w)) and r or d;
    imgui.SetNextWindowPos({ src.x, src.y }, cond);
    if (not skip_size and tonumber(src.h) and src.h > 0) then imgui.SetNextWindowSize({ src.w, src.h }, cond); end
    imgui.SetNextWindowBgAlpha(alpha_of(key, default_alpha));
end

-- Inside the window: remember where it is and how big it is.
local function window_track(key)
    local x, y = imgui.GetWindowPos();
    local w, h = imgui.GetWindowSize();
    if (type(x) ~= 'number' or type(w) ~= 'number') then return; end
    local r = cfg[key .. '_rect'];
    if (type(r) ~= 'table' or math.abs((tonumber(r.x) or 0) - x) > 0.5 or math.abs((tonumber(r.y) or 0) - y) > 0.5
        or math.abs((tonumber(r.w) or 0) - w) > 0.5 or math.abs((tonumber(r.h) or 0) - h) > 0.5) then
        cfg[key .. '_rect'] = { x = math.floor(x + 0.5), y = math.floor(y + 0.5), w = math.floor(w + 0.5), h = math.floor(h + 0.5) };
        save_soon();
    end
end

local function tab_settings()
    heading('Window Opacity', K.gold);
    imgui.PushItemWidth(240);
    local g = { math.floor(alpha_of('main', 0.94) * 100 + 0.5) };
    if (imgui.SliderInt('Guide##op', g, 20, 100, '%d%%')) then cfg.main_alpha = g[1] / 100; save_soon(); end
    local h = { math.floor(alpha_of('hud', 0.88) * 100 + 0.5) };
    if (imgui.SliderInt('HUD##op', h, 20, 100, '%d%%')) then cfg.hud_alpha = h[1] / 100; save_soon(); end
    imgui.PopItemWidth();
    imgui.TextColored(K.dim, 'Only the background fades; text stays solid. Also: /angler opacity guide|hud <20-100>');
    imgui.Spacing();

    heading('Window Size', K.gold);
    imgui.TextWrapped('Drag the bottom-right corner of the guide or the HUD to resize it, and its title bar (or anywhere on the HUD) to move it. Sizes and positions are saved for this character.');
    if (imgui.Button('Fit HUD to contents')) then hud_fit = 3; end
    tip('Shrink or grow the HUD to exactly fit what it shows.');
    imgui.SameLine();
    if (imgui.Button('Reset sizes and positions')) then
        cfg.main_rect, cfg.hud_rect = nil, nil;
        reset_pending.main, reset_pending.hud = true, true;
        hud_fit = 3;
        save_soon();
    end
    imgui.Spacing();

    heading('Text', K.gold);
    imgui.PushItemWidth(240);
    local fs = { font_on.size };
    if (imgui.SliderInt('Text size', fs, 11, 24, '%d px')) then
        cfg.font_size = fs[1]; font_on.size = fs[1]; save_soon();
    end
    imgui.PopItemWidth();
    imgui.PushItemWidth(240);
    if (imgui.BeginCombo('Title font', UF.title_label())) then
        for _, name in ipairs(UF.TITLE_ORDER) do
            if (imgui.Selectable(UF.title_label(name), UF.title == name)) then UF.set_title(name); end
        end
        imgui.EndCombo();
    end
    imgui.PopItemWidth();
    imgui.PushItemWidth(240);
    if (imgui.BeginCombo('Text font', UF.text_label())) then
        for _, name in ipairs(UF.TEXT_ORDER) do
            if (imgui.Selectable(UF.text_label(name) .. '##tx', UF.text == name)) then UF.set_text(name); end
        end
        imgui.EndCombo();
    end
    imgui.PopItemWidth();
    imgui.TextColored(K.dim, 'The fishing mini-game picks up new fonts after /addon reload timelessfishing.');
    imgui.Spacing();

    heading('HUD', K.gold);
    local v = { cfg.show_hud ~= false };
    if (imgui.Checkbox('Show the HUD', v)) then cfg.show_hud = v[1]; save_soon(); end
    v = { cfg.hud_auto ~= false };
    if (imgui.Checkbox('Only while holding a fishing rod', v)) then cfg.hud_auto = v[1]; save_soon(); end
    v = { cfg.show_banner ~= false };
    if (imgui.Checkbox('School of fish banner', v)) then cfg.show_banner = v[1]; save_soon(); end
end

local TABS = {
    { 'Current Zone', tab_here }, { 'Tracker', tab_log }, { 'Moon Effects', tab_conditions }, { 'Zones', tab_zones }, { 'Fish', tab_search },
    { 'Skill', tab_skill }, { 'Schools', tab_schools }, { 'Settings', tab_settings },
};

local function draw_main()
    ui.open_main[1] = cfg.show_main;
    window_prep('main', 0.94);
    imgui.SetNextWindowSizeConstraints({ 420, 300 }, { 1600, 1400 });
    safe_window('Timeless Angler', ui.open_main, ImGuiWindowFlags_NoCollapse, function ()
        window_track('main');
        -- header strip
        imgui.TextColored(K.gold, ('Fishing skill %d'):format(S.skill));
        if (S.gear > 0) then imgui.SameLine(); imgui.TextColored(K.green, ('(+%d gear)'):format(S.gear)); end
        imgui.SameLine(); imgui.TextColored(K.dim, '|');
        if (S.date) then
            imgui.SameLine(); imgui.TextColored(K.muted, ('%02d:%02d  %s (%d%%)'):format(S.date.hour, S.date.minute, L.MOON_NAMES[S.date.moon], S.date.moon_pct));
        end
        imgui.SameLine(); imgui.TextColored(K.dim, '|');
        imgui.SameLine(); imgui.TextColored(hole.active and K.gold or K.muted, hole.active and 'School of Fish Active!' or ('Cast #%d'):format(hole.casts));
        if (imgui.BeginTabBar('##tabs')) then
            for _, t in ipairs(TABS) do
                local flags = (ui.tab_req == t[1]) and ImGuiTabItemFlags_SetSelected or 0;
                if (imgui.BeginTabItem(t[1], nil, flags)) then
                    t[2]();
                    imgui.EndTabItem();
                end
            end
            ui.tab_req = nil;
            imgui.EndTabBar();
        end
    end);
    if (not ui.open_main[1]) then cfg.show_main = false; settings.save(); end
end

local function draw_hud()
    local school = hole.active;
    if (not cfg.show_hud) then return; end
    if (cfg.hud_auto and not S.has_rod and not school and not S.fishing) then return; end
    -- Resizable (owner 2026-11-12); 'Fit HUD to contents' / first use = a few frames of auto-fit.
    if (type(cfg.hud_rect) ~= 'table' and hud_fit == 0 and not ui.hud_fitted) then hud_fit = 3; end
    ui.hud_fitted = true;
    local fitting = hud_fit > 0;
    window_prep('hud', 0.88, fitting);
    if (not fitting) then imgui.SetNextWindowSizeConstraints({ 240, 120 }, { 1000, 1400 }); end
    local flags = bit.bor(ImGuiWindowFlags_NoTitleBar, ImGuiWindowFlags_NoFocusOnAppearing, ImGuiWindowFlags_NoNav);
    if (fitting) then flags = bit.bor(flags, ImGuiWindowFlags_AlwaysAutoResize); hud_fit = hud_fit - 1; end
    safe_window('Timeless Angler HUD', nil, flags, function ()
        window_track('hud');
        -- 1. Zone and fishing pool
        if (S.zinfo == nil) then
            heading(zone_name(S.zone), K.gold, 'title', 1.05);
            imgui.TextColored(K.muted, 'No fishing in this zone.');
        else
            heading(zone_name(S.zone) .. (S.area and ('  -  ' .. S.area.n) or ''), K.gold, 'title', 1.05);
            if (S.area == nil) then imgui.TextColored(K.muted, 'Not in a fishing pool: walk to the water.'); end
        end

        -- 2. Rod and bait
        imgui.TextColored(K.muted, 'Rod:'); imgui.SameLine();
        imgui.TextColored(S.has_rod and K.text or K.red, S.rod > 0 and item_name(S.rod) or 'none');
        imgui.SameLine(); imgui.TextColored(K.muted, '   Bait:'); imgui.SameLine();
        imgui.TextColored(D.bait[S.bait] and K.text or K.red, S.bait > 0 and item_name(S.bait) or 'none');

        -- 3. Fish this rod and bait can hook here (real chance per cast)
        local hud_odds = odds_now();
        if (S.spot and #S.spot.fish > 0) then
            if (imgui.BeginTable('##hudfish', 3, ImGuiTableFlags_SizingFixedFit)) then
                imgui.TableSetupColumn(school and 'Target Fish (School)' or 'Target Fish', ImGuiTableColumnFlags_WidthStretch);
                imgui.TableSetupColumn('Lv');
                imgui.TableSetupColumn('Hook');
                imgui.TableHeadersRow();
                for i = 1, math.min(5, #S.spot.fish) do
                    local e = S.spot.fish[i];
                    local _, lbl, c = difficulty_text(e.id);
                    imgui.TableNextRow();
                    imgui.TableNextColumn(); draw_icon(e.id, 14); imgui.SameLine(); imgui.TextColored(c, item_name(e.id));
                    tip(('Mini-game difficulty for you: %s'):format(lbl));
                    imgui.TableNextColumn(); imgui.Text(tostring(D.fish[e.id].lv));
                    imgui.TableNextColumn(); imgui.TextColored(K.blue, pct1(hud_odds.fish[e.id] or 0));
                    tip('Chance that a cast hooks this fish.');
                end
                imgui.EndTable();
            end
            if (#S.spot.fish > 5) then imgui.TextColored(K.dim, ('+%d more in the guide'):format(#S.spot.fish - 5)); end
            if (not school) then
                local rest = ('Items %s  Monsters %s'):format(pct(hud_odds.item), pct(hud_odds.mob));
                if (hud_odds.none > 0) then rest = rest .. ('  No bite %s'):format(pct(hud_odds.none)); end
                imgui.TextColored(K.dim, rest);
                tip('The rest of each cast: items, monsters (and no bite at an exhausted fishing spot).');
            end
        elseif (S.area ~= nil and (S.bait == 0 or D.bait[S.bait] == nil)) then
            imgui.TextColored(K.amber, 'Equip bait or a lure to see what you can hook.');
        elseif (S.spot and S.spot.nothing) then
            imgui.TextColored(K.red, 'Nothing here bites on this bait.');
        elseif (S.spot and #S.spot.fish == 0) then
            imgui.TextColored(K.amber, 'No fish here take this bait (only items or monsters).');
        end

        -- 4. Fishing skill
        imgui.Separator();
        imgui.TextColored(K.gold, ('Fishing skill %d'):format(S.skill));
        if (S.gear > 0) then imgui.SameLine(); imgui.TextColored(K.green, ('(+%d gear)'):format(S.gear)); end
        tip(('Your skill %d plus %d from equipped fishing gear = %d.\nGear counts twice in the mini-game.'):format(S.skill_raw, S.gear, S.skill));

        -- 5. Moon and bite time
        if (S.date) then
            local w = L.bite_wait(S.date.moon, S.date.hour, S.waist, school);
            draw_moon(7, S.date.moon_pct, S.date.moon_dir); imgui.SameLine();
            imgui.TextColored(K.muted, ('%s (%d%%)'):format(L.MOON_NAMES[S.date.moon], S.date.moon_pct));
            local fast = (S.date.moon == L.MOON_NEW or S.date.moon == L.MOON_FULL);
            imgui.TextColored(fast and K.green or K.muted, ('%d seconds per bite'):format(w));
            tip('About how long a fish takes to bite after you cast. Normally 13 seconds; faster with a New or Full Moon, at 05:00 or 17:00, with a Fisher\'s Rope, or in a school of fish.');
        end

        -- 6. Fishing Spot Fatigue Tracker
        imgui.Separator();
        heading('Fishing Spot Fatigue Tracker', K.gold, 'title', 1.0);
        local o = L.hole_odds(hole, S.zone, S.pos.x, S.pos.z, os.time());
        if (not o.pond) then draw_hole_meter(math.max(160, math.min(420, avail_w())), 9); end
        if (school) then
            local lo, hi = L.school_left(hole.school_casts);
            imgui.TextColored(K.gold, ('School of fish! Cast #%d  -  %s'):format(hole.school_casts, casts_left(lo, hi)));
            imgui.SameLine();
            if (imgui.SmallButton('End school##hud')) then let_school_go(); end
            tip('Let the school go now (for example to fish for items or monsters again).');
        elseif (o.pond) then
            imgui.TextColored(K.blue, 'Pond zone: this fishing spot never wears out.');
            tip('The water here is too small to move 20 yalms, so the whole zone is one fishing spot.\nEvery cast has a 5% school chance, and a new school can come 5 minutes after the last one ended.');
            if ((o.wait or 0) > 0) then
                imgui.TextColored(K.muted, ('Next school possible in %d:%02d'):format(math.floor(o.wait / 60), o.wait % 60));
            else
                imgui.TextColored(K.text, ('School Chance: %s'):format(pct(o.now)));
            end
        elseif (o.fresh) then
            imgui.TextColored(K.blue, ('School Chance: %s'):format(pct(o.now)));
            tip('Your next cast starts a fresh fishing spot.');
        elseif (o.used) then
            imgui.TextColored(K.muted, ('Cast #%d - No school remaining'):format(hole.casts));
            imgui.TextColored(K.muted, 'Move 20+ yalms away for a fresh fishing spot.');
        elseif (o.next >= L.EXHAUSTED_AT) then
            imgui.TextColored(K.red, ('Cast #%d - this fishing spot is exhausted. Move on!'):format(hole.casts));
        else
            imgui.TextColored(K.text, ('Cast #%d at this fishing spot'):format(hole.casts));
            imgui.TextColored(K.text, ('School Chance: %s'):format(pct(o.now)));
            tip(('Chance your next cast finds a school. %s chance of one before this fishing spot is exhausted.'):format(pct(o.ahead)));
        end
        if (hole.casts > 0 and hole.zone == S.zone and not o.fresh and not o.pond) then
            local dx, dz = S.pos.x - hole.x, S.pos.z - hole.z;
            local dist = math.sqrt(dx * dx + dz * dz);
            if (dist > 1.5) then imgui.TextColored(dist > 16 and K.amber or K.dim, ('%.1f yalms from this fishing spot (a new one starts at 20)'):format(dist)); end
        end

        -- 7. Session summary (a light version of the Tracker tab), once you have cast
        if (session.first) then
            imgui.Separator();
            local t = os.time() - session.first;
            heading('Session', K.gold, 'title', 1.0);
            imgui.SameLine(); imgui.TextColored(K.muted, ('%d:%02d:%02d'):format(math.floor(t / 3600), math.floor(t / 60) % 60, t % 60));
            tip('Time since your first cast.');
            local bw = (imgui.CalcTextSize('Reset session') or 80) + 10;
            local right = avail_w();
            imgui.SameLine(math.max(0, (imgui.GetCursorPosX() or 0) + right - bw));
            if (imgui.SmallButton('Reset session##hud')) then reset_session(); end
            tip('Start the session over: clock, catches and per-hour numbers.');
            local hrs = session_hours();
            local by, gil = {}, 0;
            for id, n in pairs(session.by) do
                by[#by + 1] = { id = id, n = n };
                gil = gil + n * (D.sell[id] or 0);
            end
            table.sort(by, function (a, b) return a.n > b.n; end);
            imgui.TextColored(K.text, ('%d fish'):format(session.fish));
            imgui.SameLine(); imgui.TextColored(K.blue, ('  %.0f catches/hr'):format(session.catches / hrs));
            imgui.SameLine(); imgui.TextColored(K.gold, ('  %s gil'):format(commas(gil)));
            tip(('About %s gil per hour at NPC prices.'):format(commas(gil / hrs)));
            if (#by > 0 and imgui.BeginTable('##hudsession', 4, ImGuiTableFlags_SizingFixedFit)) then
                imgui.TableSetupColumn('c', ImGuiTableColumnFlags_WidthStretch);
                imgui.TableSetupColumn('n'); imgui.TableSetupColumn('h'); imgui.TableSetupColumn('g');
                for k = 1, math.min(3, #by) do
                    local e = by[k];
                    local each = D.sell[e.id] or 0;
                    imgui.TableNextRow();
                    imgui.TableNextColumn(); draw_icon(e.id, 14); imgui.SameLine(); imgui.Text(item_name(e.id));
                    imgui.TableNextColumn(); imgui.Text(('x%d'):format(e.n));
                    imgui.TableNextColumn(); imgui.TextColored(K.blue, ('%.0f/hr'):format(e.n / hrs));
                    imgui.TableNextColumn();
                    if (each > 0) then imgui.TextColored(K.gold, ('%s g'):format(commas(e.n * each))); else imgui.TextDisabled('-'); end
                    tip(each > 0 and ('NPC sell: %s gil each.'):format(commas(each)) or 'Vendors won\'t buy this.');
                end
                imgui.EndTable();
                if (#by > 3) then imgui.TextColored(K.dim, ('+%d more on the Tracker tab'):format(#by - 3)); end
            end
        end

        -- 8. Buttons
        imgui.Separator();
        if (imgui.SmallButton(S.fishing and 'Fishing...' or 'Fish')) then
            if (not S.fishing) then AshitaCore:GetChatManager():QueueCommand(1, '/fish'); end
        end
        tip('Cast your line (same as typing /fish).');
        imgui.SameLine();
        if (imgui.SmallButton(cfg.show_main and 'Close guide' or 'Open guide')) then cfg.show_main = not cfg.show_main; settings.save(); end
        imgui.SameLine();
        if (imgui.SmallButton('Hide')) then
            cfg.show_hud = false;
            settings.save();
            msg('HUD hidden. Type /angler hud to bring it back.');
        end
        tip('Hide this HUD. Bring it back with /angler hud');
    end, -1);
end

local function draw_banner()
    if (not cfg.show_banner) then return; end
    local msg_on = banner_msg ~= nil and os.clock() < banner_msg.till;
    if (not hole.active and not msg_on) then return; end
    local sw = 1280;
    pcall(function () sw = imgui.GetIO().DisplaySize.x or 1280; end);
    imgui.SetNextWindowPos({ sw / 2, 80 }, ImGuiCond_Always, { 0.5, 0 });
    imgui.PushStyleColor(ImGuiCol_Border, K.gold);
    imgui.PushStyleVar(ImGuiStyleVar_WindowBorderSize, 2);
    local flags = bit.bor(ImGuiWindowFlags_NoTitleBar, ImGuiWindowFlags_AlwaysAutoResize, ImGuiWindowFlags_NoFocusOnAppearing, ImGuiWindowFlags_NoNav,
                          ImGuiWindowFlags_NoMove, ImGuiWindowFlags_NoInputs);
    safe_window('##anglerbanner', nil, flags, function ()
        if (hole.active) then
            local pulse = 0.75 + 0.25 * math.sin(os.clock() * 4);
            heading('SCHOOL OF FISH!', { K.gold[1], K.gold[2], K.gold[3], pulse }, 'title', 1.6);
            local lo, hi, p = L.school_left(hole.school_casts);
            local w = L.bite_wait(S.date and S.date.moon or 0, S.date and S.date.hour or 0, S.waist, true);
            imgui.TextColored(K.green, '+ Every cast hooks a fish');
            imgui.TextColored(K.green, ('+ Fish bite in half the time (about %d s)'):format(w));
            imgui.TextColored(K.text, ('School cast #%d  -  %s'):format(hole.school_casts, casts_left(lo, hi)));
            -- pips: 13 = the cast that found it + up to 12 more; gold = done, blue = certain, faint = maybe
            local x, y = imgui.GetCursorScreenPos();
            local dl = imgui.GetWindowDrawList();
            for i = 1, 13 do
                local px = x + (i - 1) * 18;
                local c;
                if (i <= hole.school_casts) then c = U.gold;
                elseif (i <= 7) then c = U.blue;
                else c = U.goldDim; end
                dl:AddRectFilled({ px, y }, { px + 14, y + 10 }, c, 2);
            end
            imgui.Dummy({ 13 * 18, 12 });
            imgui.TextColored(K.muted, ('Chance your next cast is still in the school: %s'):format(pct(p)));
            imgui.TextColored(K.muted, ('Fish caught from this school: %d'):format(hole.school_catches or 0));
        else
            imgui.TextColored(K.gold, banner_msg.text);
        end
    end);
    imgui.PopStyleVar();
    imgui.PopStyleColor();
end

----------------------------------------------------------------------------
-- Events
----------------------------------------------------------------------------
ashita.events.register('load', 'angler_load', function ()
    if ((tonumber(cfg.font_v) or 1) < 2) then   -- 1.7: body text one size up for settings saved by 1.4-1.6
        if (tonumber(cfg.font_size) == nil or tonumber(cfg.font_size) == 15) then cfg.font_size = 16; end
        cfg.font_v = 2;
        settings.save();
    end
    font_on.enabled, font_on.size = cfg.font ~= false, tonumber(cfg.font_size) or 16;
    if (not UF.load(imgui_raw)) then
        print(('[timelessangler] Using the default font (%s).'):format(tostring(UF.error)));
    end
    local h = cfg.hole;
    if (type(h) == 'table' and h.casts and h.last and (os.time() - h.last) < L.HOLE_IDLE) then
        for k, v in pairs(h) do hole[k] = v; end
        -- a school only survives a short reload; otherwise the server has likely ended it
        if (hole.active and (os.time() - h.last) > 120) then hole.active = false; end
    end
    pcall(update_state);
end);

ashita.events.register('unload', 'angler_unload', function ()
    cfg.hole = { zone = hole.zone, x = hole.x, z = hole.z, casts = hole.casts, last = hole.last, used = hole.used, active = hole.active,
                 hit_at = hole.hit_at, school_casts = hole.school_casts, school_catches = hole.school_catches };
    settings.save();
end);

ashita.events.register('packet_in', 'angler_packet_in', function (e)
    if (e.id == 0x000A) then
        hooked = nil;
        armed = true;
        S.next_update = 0;
        return;
    end
    -- Our own status: animation 56 = a cast the server accepted (NewFishingStart).
    if (e.id == 0x0037) then
        local a = struct.unpack('B', e.data_modified, 0x30 + 1);
        if (see_status(a)) then count_cast(); end
        return;
    end
    -- System text from the server (schools of fish).
    if (e.id == 0x0017) then
        local s = e.data_modified;
        if (s:find('school of fish', 1, true) or s:find('fishing spot', 1, true) or s:find('fishing hole', 1, true)) then on_server_text(s); end
        return;
    end
    -- What bit: the Timeless layout of 0x115 (read only; timelessfishing handles the game).
    if (e.id == 0x0115) then
        local magic = struct.unpack('<H', e.data_modified, 0x04 + 1);
        session.bites = session.bites + 1;
        if (magic == 0x5855) then
            local item = struct.unpack('<H', e.data_modified, 0x0E + 1);
            local flags = struct.unpack('B', e.data_modified, 0x12 + 1);
            hooked = { item = item, monster = (flags % 8) >= 4, chest = (flags % 16) >= 8, legendary = (flags % 2) == 1 };
        else
            hooked = { item = 0 };
        end
    end
end);

ashita.events.register('text_in', 'angler_text_in', function (e)
    local ok, err = pcall(on_text, e.message_modified or e.message);
    if (not ok) then print(err); end
end);

ashita.events.register('command', 'angler_command', function (e)
    local args = e.command:args();
    if (#args == 0) then return; end
    local c = args[1]:lower();
    if (c ~= '/angler' and c ~= '/fishhud') then return; end
    e.blocked = true;
    local sub = (args[2] or ''):lower();
    if (sub == '') then
        cfg.show_main = not cfg.show_main;
    elseif (sub == 'hud' or sub == 'show' or sub == 'hide') then
        local v = (args[3] or ''):lower();
        if (sub == 'show' or v == 'on' or v == 'show') then cfg.show_hud = true;
        elseif (sub == 'hide' or v == 'off' or v == 'hide') then cfg.show_hud = false;
        else cfg.show_hud = not cfg.show_hud; end
        if (cfg.show_hud) then
            msg(cfg.hud_auto and 'HUD on. It shows while you hold a fishing rod (/angler auto to always show it).' or 'HUD on.');
        else
            msg('HUD hidden. Type /angler hud to bring it back.');
        end
    elseif (sub == 'auto') then
        cfg.hud_auto = not cfg.hud_auto;
        msg('HUD ' .. (cfg.hud_auto and 'only with a rod in hand' or 'always shown'));
    elseif (sub == 'school' and ((args[3] or ''):lower() == 'end' or (args[3] or ''):lower() == 'stop')) then
        let_school_go();
    elseif (sub == 'banner') then
        cfg.show_banner = not cfg.show_banner;
        msg('School banner ' .. (cfg.show_banner and 'on' or 'off'));
    elseif (sub == 'search') then
        ui.search[1] = table.concat(args, ' ', 3);
        ui.sel_fish = nil;
        ui.tab_req = 'Fish';
        cfg.show_main = true;
    elseif (sub == 'font') then
        local v = (args[3] or ''):lower();
        if (v == 'on' or v == 'off') then
            cfg.font = (v == 'on');
        elseif (v == 'size' and tonumber(args[4])) then
            cfg.font_size = math.max(11, math.min(24, math.floor(tonumber(args[4]))));
        else
            cfg.font = not (cfg.font ~= false);
        end
        font_on.enabled, font_on.size = cfg.font ~= false, tonumber(cfg.font_size) or 16;
        msg(('Website fonts %s, text size %d%s'):format(font_on.enabled and 'on' or 'off', font_on.size,
            (font_on.enabled and not UF.loaded) and (' (not loaded: ' .. tostring(UF.error) .. ')') or ''));
    elseif (sub == 'opacity') then
        local which, v = (args[3] or ''):lower(), tonumber(args[4]);
        local key = (which == 'guide' or which == 'main') and 'main' or ((which == 'hud') and 'hud' or nil);
        if (key ~= nil and v ~= nil) then
            cfg[key .. '_alpha'] = math.max(20, math.min(100, v)) / 100;
            msg(('%s opacity %d%%'):format(key == 'main' and 'Guide' or 'HUD', math.floor(cfg[key .. '_alpha'] * 100 + 0.5)));
        else
            msg(('Opacity: guide %d%%, HUD %d%%. Change: /angler opacity guide|hud <20-100>'):format(
                math.floor(alpha_of('main', 0.94) * 100 + 0.5), math.floor(alpha_of('hud', 0.88) * 100 + 0.5)));
        end
    elseif (sub == 'textfont') then
        local v = (args[3] or ''):lower();
        if (v ~= '' and UF.set_text(v)) then
            msg(('Text font: %s (for the fishing mini-game too after /addon reload timelessfishing).'):format(UF.text_label()));
        else
            msg(('Text font is %s. Choose: /angler textfont %s'):format(UF.text_label(), table.concat(UF.TEXT_ORDER, ' | ')));
        end
    elseif (sub == 'titlefont') then
        local v = (args[3] or ''):lower();
        if (v ~= '' and UF.set_title(v)) then
            msg(('Title font: %s (for the fishing mini-game too after /addon reload timelessfishing).'):format(UF.title_label()));
        else
            msg(('Title font is %s. Choose: /angler titlefont %s'):format(UF.title_label(), table.concat(UF.TITLE_ORDER, ' | ')));
        end
    elseif ((sub == 'spot' or sub == 'hole') and (args[3] or ''):lower() == 'reset') then
        hole = L.new_hole();
        msg('Fishing spot tracker reset.');
    else
        msg('/angler  - open or close the guide');
        msg('/angler hud  - show or hide the HUD (also: /angler show, /angler hide)');
        msg('/angler auto  - HUD only while holding a rod, or always');
        msg('/angler banner  - school banner on/off');
        msg('/angler search <text>  - find a fish (or a bait)');
        msg('/angler font [on|off]  - website font (Inter)');
        msg('/angler font size <11-24>  - text size');
        msg('/angler titlefont <raleway|montserrat|inter|cormorant|ashita>  - font for titles');
        msg('/angler textfont <inter|raleway|montserrat|cormorant|ashita>  - font for all other text');
        msg('/angler opacity guide|hud <20-100>  - window background opacity (also in the guide\'s Settings tab)');
        msg('/angler spot reset  - forget the tracked fishing spot');
    end
    settings.save();
end);

local err_shown = false;
ashita.events.register('d3d_present', 'angler_present', function ()
    local player = mm():GetPlayer();
    if (player == nil or player:GetMainJob() == 0 or mm():GetParty():GetMemberServerId(0) == 0) then return; end
    local now = os.clock();
    if (now >= S.next_update) then
        S.next_update = now + 0.25;
        local ok, err = pcall(update_state);
        if (not ok and not err_shown) then err_shown = true; msg('update error: ' .. tostring(err)); end
        pcall(check_school);
        -- Fallback cast detection from the entity status (if 0x037 was missed).
        S.fishing = is_fishing_anim(S.status);
        if (see_status(S.status)) then count_cast(); end
    end
    if (save_at ~= nil and now >= save_at) then save_at = nil; settings.save(); end
    if (cfg.show_main and now >= S.next_owned) then
        S.next_owned = now + 3;
        pcall(scan_owned);
    end
    UF.capture_default(imgui_raw);
    push_theme();
    local ok, err = pcall(function ()
        draw_hud();
        draw_banner();
        if (cfg.show_main) then draw_main(); end
    end);
    pop_theme();
    if (not ok and not err_shown) then err_shown = true; msg('draw error: ' .. tostring(err)); end
end);
