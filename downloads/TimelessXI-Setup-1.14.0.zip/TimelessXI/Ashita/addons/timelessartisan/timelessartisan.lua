--[[
* Timeless Artisan - crafting window and HUD for Timeless XI (Ashita v4)
*
* Everything about crafting in one place, without the synthesis menu:
*   Recipes    every recipe of each craft by level, with your success, HQ and skill-up chances
*   Search     find a recipe by its result or an ingredient; the recipe card has everything
*   Favorites  the recipes you starred
*   Guilds     today's guild point item of every guild, the limits, and one-click crafting of what's needed
*   Storage    the account's crafting material storage: deposit, withdraw, auto-deposit, all characters
*   Queue      up to 12 crafts in a row and what they made
*   Bonuses    your crafts and everything changing your chances right now
*   Settings   opacity, size, fonts, HUD and storage options
* Craft buttons take the crystal and materials straight out of storage (greyed out while something is
* missing) and run a real synthesis on the server: same animation, results and skill-ups as the menu.
*
* Server side: modules/timeless_artisan (timeless-server). Recipes: data.lua (TimelessArtisan/gen.py).
* Commands: /artisan (window)  /artisan hud  /artisan search <text>  /artisan deposit  /artisan stop
*           /artisan help    (also /tcraft)
--]]

addon.name    = 'timelessartisan';
addon.author  = 'Timeless XI';
addon.version = '1.5';
addon.desc    = 'Crafting window: recipes with your chances, material storage, one-click crafting, a 12-craft queue and guild items.';
addon.link    = 'https://timelessxi.gg';

require('common');
local chat      = require('chat');
local imgui_raw = require('imgui');
-- Text goes through TextUnformatted / TextColored, which print the string as it is ('%' included).
-- Any ImGui function this Ashita build doesn't have becomes a no-op instead of an error.
local missing_warned = {};
local imgui = setmetatable({}, { __index = function (_, k)
    local v = imgui_raw[k];
    if (v == nil) then
        if (not missing_warned[k]) then
            missing_warned[k] = true;
            print(('[timelessartisan] ImGui has no %s here; skipped.'):format(tostring(k)));
        end
        v = function () end;
    end
    return v;
end });
local DIM_TEXT = { 110 / 255, 120 / 255, 140 / 255, 1 };
imgui.Text = function (s) imgui_raw.TextUnformatted(tostring(s)); end
imgui.TextDisabled = function (s) imgui_raw.TextColored(DIM_TEXT, tostring(s)); end
imgui.TextWrapped = function (s)
    imgui_raw.PushTextWrapPos(0);
    imgui_raw.TextUnformatted(tostring(s));
    imgui_raw.PopTextWrapPos();
end
imgui.BulletText = function (s)
    imgui_raw.Bullet();
    imgui_raw.SameLine();
    imgui_raw.TextUnformatted(tostring(s));
end
imgui.SetTooltip = function (s)
    if (imgui_raw.BeginTooltip() ~= false) then
        imgui_raw.TextUnformatted(tostring(s));
        imgui_raw.EndTooltip();
    end
end

-- Unwind stack: every Begin*/Push* that needs a matching End*/Pop* is recorded, so a window whose
-- drawing hits an error can still close everything it opened (see safe_window).
local unwind = {};
local function closes(name)
    for i = #unwind, 1, -1 do if (unwind[i] == name) then table.remove(unwind, i); return; end end
end
local function track(open_fn, close_fn, always)
    local o, c = imgui_raw[open_fn], imgui_raw[close_fn];
    if (o == nil or c == nil) then return; end
    imgui[open_fn] = function (...)
        local r = o(...);
        if (always or r) then unwind[#unwind + 1] = close_fn; end
        return r;
    end
    imgui[close_fn] = function (...) closes(close_fn); return c(...); end
end
track('BeginChild', 'EndChild', true);
track('BeginTable', 'EndTable', false);
track('BeginTabBar', 'EndTabBar', false);
track('BeginTabItem', 'EndTabItem', false);
track('BeginCombo', 'EndCombo', false);
track('BeginGroup', 'EndGroup', true);
track('Indent', 'Unindent', true);
track('PushItemWidth', 'PopItemWidth', true);
do
    for _, pair in ipairs({ { 'PushStyleColor', 'PopStyleColor' }, { 'PushStyleVar', 'PopStyleVar' } }) do
        local o, c = imgui_raw[pair[1]], imgui_raw[pair[2]];
        imgui[pair[1]] = function (...) unwind[#unwind + 1] = pair[2]; return o(...); end
        imgui[pair[2]] = function (n) for _ = 1, (n or 1) do closes(pair[2]); end return c(n or 1); end
    end
end

-- Fonts shared with timelessangler / timelessfishing (title and text font choices, Settings tab).
local UF = require('timeless.ui_fonts');
local font_on = { enabled = true, size = 16 };
local function fonts_ok() return font_on.enabled and UF.loaded; end

local function heading(text, color, role, mult)
    role = role or 'title';
    mult = mult or 1.1;
    if (fonts_ok()) then
        imgui_raw.PushFont(UF.get(role), UF.size(role, font_on.size * mult));
        imgui_raw.TextColored(color, tostring(text));
        imgui_raw.PopFont();
    else
        imgui_raw.TextColored(color, tostring(text));
    end
end

local reported = {};
local function safe_window(name, open, flags, body, size_delta)
    local depth = #unwind;
    local pushed = false;
    if (fonts_ok()) then
        imgui_raw.PushFont(UF.get('body'), UF.size('body', font_on.size + (size_delta or 0)));
        pushed = true;
    end
    if (imgui_raw.Begin(name, open, flags)) then
        local ok, err = pcall(body);
        if (not ok and not reported[tostring(err)]) then
            reported[tostring(err)] = true;
            print(('[timelessartisan] error drawing %s: %s'):format(name, tostring(err)));
        end
    end
    while (#unwind > depth) do
        local f = table.remove(unwind);
        if (f == 'PopStyleColor' or f == 'PopStyleVar') then imgui_raw[f](1); else imgui_raw[f](); end
    end
    imgui_raw.End();
    if (pushed) then imgui_raw.PopFont(); end
end

local settings = require('settings');
local ffi      = require('ffi');
local d3d8     = require('d3d8');

local L = require('artisan_logic');
local D = require('data');
local IDX = L.index(D);

local defaults = T{
    show_main     = false,
    show_hud      = true,
    hud_auto      = false,     -- HUD only while crafts are queued (1.4+: the HUD is a compact crafting window, shown always)
    hud_v         = 1,         -- settings version for the HUD (1.4 turns hud_auto off once)
    hud_favs      = true,      -- HUD: favorites section open
    last_craft    = nil,       -- { id, n }: the last craft you queued (Repeat)
    hud_alpha     = 0.88,
    main_alpha    = 0.94,
    main_rect     = nil,
    hud_rect      = nil,
    font          = true,
    font_size     = 16,
    craft_count   = 1,         -- how many each Craft button queues (1-12)
    return_left   = true,      -- after each queued craft, leftovers and a material result go back into storage
    bag_satchel   = true,      -- deposits also take from the Mog Satchel / Sack / Case
    bag_sack      = true,
    bag_case      = true,
    bag_home      = true,      -- ... and the Mog Safe / Storage / Locker while in a Mog House
    auto_mode     = 0,         -- auto-deposit: 0 off, 1 every crafting material, 2 only the chosen items
    auto_items    = T{},       -- item ids for auto_mode 2
    kept          = T{},       -- [tostring(id)] = n: withdrawn by hand, auto-deposit leaves them alone
    auto_bags     = false,     -- auto-deposit from the satchel / sack / case too (else the inventory only)
    favorites     = T{},       -- recipe ids
    hide_hard     = false,     -- Recipes tab: hide recipes more than 15 levels above you
    only_make     = false,     -- Recipes tab: only recipes you have everything for
};
local cfg = settings.load(defaults);

----------------------------------------------------------------------------
-- Colours (theme shared with timelessangler)
----------------------------------------------------------------------------
local function rgba(r, g, b, a) return { r / 255, g / 255, b / 255, a or 1 }; end
local function col(r, g, b, a) return math.floor((a or 1) * 255 + 0.5) * 16777216 + b * 65536 + g * 256 + r; end
local K = {
    text   = rgba(230, 236, 245), muted = rgba(152, 163, 184), dim = rgba(110, 120, 140),
    gold   = rgba(232, 200, 120), blue  = rgba(143, 178, 230), green = rgba(126, 211, 140),
    red    = rgba(230, 96, 96),   amber = rgba(235, 170, 80),  white = rgba(245, 245, 250),
    bg     = rgba(10, 11, 18, 0.94), bg2 = rgba(17, 20, 29, 1), edge = rgba(40, 48, 64, 1),
    head   = rgba(24, 30, 44, 1), headHi = rgba(36, 46, 68, 1), tab = rgba(20, 25, 37, 1), tabHi = rgba(61, 95, 148, 1),
    off    = rgba(30, 34, 46, 1), offText = rgba(90, 98, 115, 1), go = rgba(46, 92, 64, 1), goHi = rgba(62, 124, 86, 1),
};
local U = { track = col(17, 20, 29, 1), gold = col(232, 200, 120, 1), green = col(126, 211, 140, 0.85), red = col(230, 96, 96, 0.85), blue = col(143, 178, 230, 0.85) };

local theme_pushed = { c = 0, v = 0 };
local function push_theme(alpha)
    local list = {
        { ImGuiCol_WindowBg, { K.bg[1], K.bg[2], K.bg[3], alpha or K.bg[4] } }, { ImGuiCol_Border, K.edge },
        { ImGuiCol_TitleBg, K.head }, { ImGuiCol_TitleBgActive, K.headHi }, { ImGuiCol_Tab, K.tab },
        { ImGuiCol_TabHovered, K.tabHi }, { ImGuiCol_TabActive, K.tabHi }, { ImGuiCol_Header, K.head },
        { ImGuiCol_HeaderHovered, K.headHi }, { ImGuiCol_HeaderActive, K.tabHi }, { ImGuiCol_FrameBg, K.bg2 },
        { ImGuiCol_Button, K.head }, { ImGuiCol_ButtonHovered, K.headHi }, { ImGuiCol_PlotHistogram, K.tabHi },
        { ImGuiCol_TableHeaderBg, K.head }, { ImGuiCol_TableRowBgAlt, { 1, 1, 1, 0.025 } }, { ImGuiCol_Text, K.text },
    };
    theme_pushed.c, theme_pushed.v = 0, 0;
    for _, e in ipairs(list) do
        if (e[1] ~= nil) then imgui.PushStyleColor(e[1], e[2]); theme_pushed.c = theme_pushed.c + 1; end
    end
    for _, e in ipairs({ { ImGuiStyleVar_WindowRounding, 6 }, { ImGuiStyleVar_FrameRounding, 4 } }) do
        if (e[1] ~= nil) then imgui.PushStyleVar(e[1], e[2]); theme_pushed.v = theme_pushed.v + 1; end
    end
end
local function pop_theme()
    if (theme_pushed.v > 0) then imgui.PopStyleVar(theme_pushed.v); end
    if (theme_pushed.c > 0) then imgui.PopStyleColor(theme_pushed.c); end
    theme_pushed.c, theme_pushed.v = 0, 0;
end

----------------------------------------------------------------------------
-- Game helpers
----------------------------------------------------------------------------
local mm = function () return AshitaCore:GetMemoryManager(); end
local res = function () return AshitaCore:GetResourceManager(); end
local function msg(text) print(chat.header(addon.name):append(chat.message(text))); end

local name_cache = {};
local function item_name(id)
    if (id == nil or id == 0) then return '-'; end
    local n = name_cache[id];
    if (n) then return n; end
    local it = res():GetItemById(id);
    if (it ~= nil and it.Name ~= nil and it.Name[1] ~= nil and it.Name[1] ~= '') then n = it.Name[1]; else n = ('Item %d'):format(id); end
    name_cache[id] = n;
    return n;
end
local function stack_of(id)
    local it = res():GetItemById(id);
    return (it ~= nil and tonumber(it.StackSize) and it.StackSize > 0) and it.StackSize or 1;
end
-- Weapons and armour (item type 4 / 5): some are ingredients, but "deposit all" and auto-deposit leave gear alone
local function is_gear(id)
    local it = res():GetItemById(id);
    return it ~= nil and (it.Type == 4 or it.Type == 5);
end
local function has_ki(k)
    local ok, v = pcall(function () return mm():GetPlayer():HasKeyItem(k); end);
    return ok and v and true or false;
end

local function commas(n)
    local t = tostring(math.floor(n + 0.5));
    local k;
    repeat t, k = t:gsub('^(-?%d+)(%d%d%d)', '%1,%2'); until k == 0;
    return t;
end

local function plural(n, one, many) return ('%s %s'):format(commas(n), n == 1 and one or (many or (one .. 's'))); end

-- Chat line as plain text (drop FFXI colour / auto-translate codes and control bytes)
local function clean_chat(text)
    text = text:gsub('[\30\31\127\239].', ''):gsub('[%z\1-\31]', '');
    text = text:gsub('^.-%[%d%d?:%d%d:%d%d%]%s*', '', 1);
    return (text:gsub('^%s+', ''):gsub('%s+$', ''));
end

----------------------------------------------------------------------------
-- State
----------------------------------------------------------------------------
local ST = L.new_state();
local rev = 1                 -- bumped whenever anything that changes chances or materials changes
local INV, BAGS, INV_FREE = {}, {}, 0  -- inventory counts, every bag's counts { [bag] = { [id] = n } }, free slots
local function have(id) return INV[id] or 0; end
local function stored(id) return (ST.store[id] or 0) + (ST.store_own[id] or 0); end
local function in_bags(id, skip_inventory)
    local n = 0;
    for bag, t in pairs(BAGS) do if (not (skip_inventory and bag == 0)) then n = n + (t[id] or 0); end end
    return n;
end

local session = { start = os.time(), made = 0, hq = 0, broke = 0, skill = {}, log = {}, by = {} };
local function log(text, c)
    table.insert(session.log, 1, { t = os.date('%H:%M:%S'), text = text, c = c or K.text });
    while (#session.log > 80) do table.remove(session.log); end
end

local ui = {
    tab_req = nil, search = { '' }, store_filter = { '' }, sel_recipe = nil, sel_craft = nil, open_main = { false },
    show_acct = false, hud_fit = 0, wd = {}, wa_confirm = nil,
};
local net = { out = {}, next_send = 0, asked_at = nil, answered = false, next_mods = 0, next_auto = nil, last_auto = 0, hello_at = nil };

----------------------------------------------------------------------------
-- Talking to the server
----------------------------------------------------------------------------
local function request(text)
    net.out[#net.out + 1] = text;
end
local function flush_requests()
    if (#net.out == 0 or os.clock() < net.next_send) then return; end
    local text = table.remove(net.out, 1);
    local bytes = L.request_bytes(text);
    if (bytes ~= nil) then
        pcall(function () AshitaCore:GetPacketManager():AddOutgoingPacket(0x0B5, bytes); end);
    end
    net.next_send = os.clock() + 0.12;
end
local function hello()
    request('hi');
    net.asked_at = os.clock();
end

local function deposit_mask(for_auto)
    if (for_auto) then
        return L.bag_mask(true, cfg.auto_bags and cfg.bag_satchel, cfg.auto_bags and cfg.bag_sack, cfg.auto_bags and cfg.bag_case, false);
    end
    return L.bag_mask(true, cfg.bag_satchel, cfg.bag_sack, cfg.bag_case, cfg.bag_home);
end

local function queue_size() return (ST.queue.n or 0) + (ST.queue.run and 1 or 0); end
local function queue_room() return math.max(0, (ST.v.max or L.MAX_QUEUE) - queue_size()); end

local function craft(r, n)
    n = math.max(1, math.min(n or 1, queue_room()));
    if (queue_room() <= 0) then msg('The craft queue is full (12 crafts at most).'); return; end
    request(('cq %d %d %d'):format(r.id, n, cfg.return_left and 1 or 0));
    log(('Queued %s x%d'):format(r.name, n), K.blue);
    cfg.last_craft = { id = r.id, n = n };
    ui.save_at = os.clock() + 1;
end

-- Every crafting material in the deposit bags (gear only when asked for by id)
local function bag_materials(for_auto)
    local ids, seen = {}, {};
    local bags = { 0 };
    if (not for_auto or cfg.auto_bags) then
        if (cfg.bag_satchel) then bags[#bags + 1] = 5; end
        if (cfg.bag_sack) then bags[#bags + 1] = 6; end
        if (cfg.bag_case) then bags[#bags + 1] = 7; end
    end
    if (not for_auto and cfg.bag_home) then for _, b in ipairs({ 1, 2, 4, 9 }) do bags[#bags + 1] = b; end end
    for _, b in ipairs(bags) do
        for id in pairs(BAGS[b] or {}) do
            if (IDX.materials[id] and not seen[id] and not is_gear(id)) then seen[id] = true; ids[#ids + 1] = id; end
        end
    end
    table.sort(ids);
    return ids;
end

-- Kept items (withdrawn by hand): see L.kept_clamp / L.auto_plan
local keep = { pending = {}, asked = {}, at = {} };   -- withdrawals still landing: [id] = qty asked, time asked; time landed
local function pending_expire()
    for id, t in pairs(keep.asked) do
        if (os.clock() - t > 10) then keep.pending[id], keep.asked[id] = nil, nil; end   -- no answer: forget it
    end
end
local function kept_map()
    local t = {};
    for k, n in pairs(cfg.kept or {}) do
        local id, v = tonumber(k), tonumber(n);
        if (id and v and v > 0) then t[id] = v; end
    end
    for id, n in pairs(keep.pending) do t[id] = (t[id] or 0) + n; end
    return t;
end
local function kept_of(id) return kept_map()[id] or 0; end
local function kept_save(t)
    local out = T{};
    for id, n in pairs(t) do if (n > 0) then out[tostring(id)] = n; end end
    cfg.kept = out;
    ui.save_at = os.clock() + 1;
end
local function kept_release(id)
    local t = {};
    for k, n in pairs(cfg.kept or {}) do if (tonumber(k) ~= id) then t[tonumber(k)] = tonumber(n); end end
    keep.pending[id], keep.asked[id] = nil, nil;
    kept_save(t);
end
-- Carried = inventory + satchel + sack + case (where withdrawn items can wander to)
local function carried(id)
    local n = 0;
    for _, b in ipairs({ 0, 5, 6, 7 }) do n = n + ((BAGS[b] or {})[id] or 0); end
    return n;
end
local function kept_tick()
    if (cfg.kept == nil or next(cfg.kept) == nil) then return; end
    local t = {};
    for k, n in pairs(cfg.kept) do t[tonumber(k)] = tonumber(n); end
    local before = 0;
    for _, n in pairs(t) do before = before + n; end
    L.kept_clamp(t, carried, function (id) return keep.pending[id] ~= nil or (keep.at[id] and os.clock() - keep.at[id] < 5); end);
    local after = 0;
    for _, n in pairs(t) do after = after + n; end
    if (after ~= before) then kept_save(t); end
end

local function deposit_all(ids)
    ids = ids or bag_materials(false);
    if (#ids == 0) then log('No crafting materials in your bags to store.', K.muted); return; end
    for _, id in ipairs(ids) do if (kept_of(id) > 0) then kept_release(id); end end
    local parts = {};
    for _, id in ipairs(ids) do parts[#parts + 1] = tostring(id); end
    for _, rq in ipairs(L.chunk_requests(('da %d'):format(deposit_mask(false)), parts)) do request(rq); end
end

local function on_server_line(line)
    local kind, info = L.parse(ST, line);
    if (kind == nil) then return; end
    rev = rev + 1;
    net.answered = true;
    if (kind == 'R') then
        local r = IDX.by_id[info.recipe];
        local name = r and r.name or item_name(info.item);
        if (info.res == 0) then
            session.broke = session.broke + 1;
            log(('%s: the synthesis broke.'):format(name), K.red);
        else
            session.made = session.made + 1;
            if (info.res >= 2) then session.hq = session.hq + 1; end
            session.by[info.item] = (session.by[info.item] or 0) + info.qty;
            log(('%s: %s x%d%s'):format(name, item_name(info.item), info.qty, info.res >= 2 and ('  (HQ' .. (info.res - 1) .. ')') or ''),
                info.res >= 2 and K.gold or K.green);
        end
    elseif (kind == 'D') then
        if (info.act == 'all') then
            if (info.q > 0) then log(('Stored %s (%s).'):format(plural(info.q, 'item'), plural(info.i, 'material type')), K.green); end
        elseif (info.act == 'wall') then
            if (info.q > 0) then log(('Withdrew %s (%s).'):format(plural(info.q, 'item'), plural(info.i, 'material type')), K.green); end
            if (info.why ~= '') then log(('Withdraw all stopped: %s.'):format(info.why), K.amber); end
            for id, n in pairs(keep.pending) do if (n == 0) then keep.pending[id], keep.asked[id] = nil, nil; end end
        elseif (info.q > 0) then
            log(('%s %s x%d'):format(info.act == 'wd' and 'Withdrew' or 'Stored', item_name(info.i), info.q), K.green);
            if (info.act == 'wd') then
                -- a hand withdrawal: auto-deposit leaves these alone
                keep.pending[info.i], keep.asked[info.i] = nil, nil;
                keep.at[info.i] = os.clock();
                local t = kept_map();
                t[info.i] = (tonumber((cfg.kept or {})[tostring(info.i)]) or 0) + info.q;
                kept_save(t);
                if (cfg.auto_mode ~= 0) then log(('Auto-deposit will leave these %d alone.'):format(info.q), K.blue); end
            end
        elseif (info.act == 'wd') then
            keep.pending[info.i], keep.asked[info.i] = nil, nil;
            log(('Couldn\'t withdraw %s: %s.'):format(item_name(info.i), info.why ~= '' and info.why or 'nothing moved'), K.amber);
        elseif (info.why == 'in_use') then
            log(('%s is equipped or in use and stays in your bags.'):format(item_name(info.i)), K.amber);
        end
    elseif (kind == 'E') then
        local c = (info.kind == 'done') and K.green or ((info.kind == 'stop' or info.kind == 'no' or info.kind == 'full') and K.amber or K.muted);
        log(info.text, c);
        if (info.kind ~= 'done') then msg(info.text); end
    end
end

----------------------------------------------------------------------------
-- Bags
----------------------------------------------------------------------------
local CONTAINERS = { 0, 1, 2, 4, 5, 6, 7, 9 };
local inv_sig = '';
local function scan_bags()
    local inv = mm():GetInventory();
    local bags, sig = {}, {};
    local used = 0;
    for _, c in ipairs(CONTAINERS) do
        local t = {};
        local n = inv:GetContainerCountMax(c) or 0;
        for i = 0, n do
            local it = inv:GetContainerItem(c, i);
            if (it ~= nil and it.Id ~= nil and it.Id > 0 and it.Id ~= 65535) then
                t[it.Id] = (t[it.Id] or 0) + math.max(1, it.Count or 1);
                if (c == 0) then used = used + 1; end
            end
        end
        bags[c] = t;
    end
    for id, n in pairs(bags[0] or {}) do sig[#sig + 1] = id .. ':' .. n; end
    table.sort(sig);
    local s = table.concat(sig, ',');
    BAGS, INV = bags, bags[0] or {};
    INV_FREE = math.max(0, (inv:GetContainerCountMax(0) or 0) - used);
    if (s ~= inv_sig) then inv_sig = s; rev = rev + 1; return true; end
    return false;
end

-- Auto-deposit: a few seconds after the inventory changes, never while crafting
local function auto_ids()
    if (cfg.auto_mode == 1) then return bag_materials(true); end
    local ids = {};
    if (cfg.auto_mode == 2) then
        for _, id in ipairs(cfg.auto_items or {}) do
            if (have(id) > 0 or (cfg.auto_bags and in_bags(id, true) > 0)) then ids[#ids + 1] = id; end
        end
    end
    return ids;
end
local function auto_count(id)
    local n = have(id);
    if (cfg.auto_bags) then
        if (cfg.bag_satchel) then n = n + ((BAGS[5] or {})[id] or 0); end
        if (cfg.bag_sack) then n = n + ((BAGS[6] or {})[id] or 0); end
        if (cfg.bag_case) then n = n + ((BAGS[7] or {})[id] or 0); end
    end
    return n;
end
local function auto_deposit_tick(now)
    if (cfg.auto_mode == 0 or net.next_auto == nil or now < net.next_auto) then return; end
    net.next_auto = nil;
    pending_expire();
    if (ST.queue.run or (ST.queue.n or 0) > 0 or not ST.ready or next(keep.pending) ~= nil) then net.next_auto = now + 5; return; end
    kept_tick();
    local plan = L.auto_plan(auto_ids(), kept_map(), carried, auto_count);
    if (#plan == 0) then return; end
    local parts = {};
    for _, e in ipairs(plan) do parts[#parts + 1] = ('%d:%d'):format(e.id, e.qty); end
    for _, rq in ipairs(L.chunk_requests(('dp %d'):format(deposit_mask(true)), parts)) do request(rq); end
    net.last_auto = now;
end

----------------------------------------------------------------------------
-- Icons
----------------------------------------------------------------------------
local tex = { items = {}, count = 0 };
local function icon(id)
    if (id == nil or id <= 0 or id >= 65535) then return nil; end
    local c = tex.items[id];
    if (c ~= nil) then return c ~= false and c or nil; end
    if (tex.count > 200) then tex.items = {}; tex.count = 0; end
    tex.count = tex.count + 1;
    local it = res():GetItemById(id);
    if (it == nil or it.ImageSize == nil or it.ImageSize == 0) then tex.items[id] = false; return nil; end
    local p = ffi.new('IDirect3DTexture8*[1]');
    if (ffi.C.D3DXCreateTextureFromFileInMemoryEx(d3d8.get_device(), it.Bitmap, it.ImageSize, 0xFFFFFFFF, 0xFFFFFFFF, 1, 0,
            ffi.C.D3DFMT_A8R8G8B8, ffi.C.D3DPOOL_MANAGED, ffi.C.D3DX_DEFAULT, ffi.C.D3DX_DEFAULT, 0xFF000000, nil, nil, p) ~= ffi.C.S_OK) then
        tex.items[id] = false;
        return nil;
    end
    local t = d3d8.gc_safe_release(ffi.cast('IDirect3DTexture8*', p[0]));
    tex.items[id] = t;
    return t;
end
local function draw_icon(id, size)
    local t = icon(id);
    if (t ~= nil) then imgui.Image(tonumber(ffi.cast('uint32_t', t)), { size, size }); else imgui.Dummy({ size, size }); end
end

----------------------------------------------------------------------------
-- Small widgets
----------------------------------------------------------------------------
local function tip(text) if (imgui.IsItemHovered()) then imgui.SetTooltip(text); end end
local pct = L.pct;
local function chance_col(x)
    if (x >= 0.9) then return K.green; end
    if (x >= 0.7) then return K.blue; end
    if (x >= 0.5) then return K.amber; end
    return K.red;
end

-- A button that is greyed out (and does nothing) when it can't be used
local function button(label, enabled, why, small)
    if (enabled) then
        imgui.PushStyleColor(ImGuiCol_Button, K.go);
        imgui.PushStyleColor(ImGuiCol_ButtonHovered, K.goHi);
        local hit;
        if (small) then hit = imgui.SmallButton(label); else hit = imgui.Button(label); end
        imgui.PopStyleColor(2);
        return hit;
    end
    imgui.PushStyleColor(ImGuiCol_Button, K.off);
    imgui.PushStyleColor(ImGuiCol_ButtonHovered, K.off);
    imgui.PushStyleColor(ImGuiCol_ButtonActive, K.off);
    imgui.PushStyleColor(ImGuiCol_Text, K.offText);
    if (small) then imgui.SmallButton(label); else imgui.Button(label); end
    imgui.PopStyleColor(4);
    if (why) then tip(why); end
    return false;
end

local function panel_begin(id, width, border)
    imgui.PushStyleVar(ImGuiStyleVar_WindowPadding, { 14, 12 });
    imgui.BeginChild(id, { width, 0 }, bit.bor(ImGuiChildFlags_AlwaysUseWindowPadding or 0, border and (ImGuiChildFlags_Borders or 1) or 0));
    imgui.PopStyleVar();
end

----------------------------------------------------------------------------
-- Per-recipe caches (chances and materials), rebuilt when anything changes
----------------------------------------------------------------------------
local cache = { rev = 0, odds = {}, check = {} };
local function fresh()
    if (cache.rev ~= rev) then cache.rev, cache.odds, cache.check = rev, {}, {}; end
end
local function odds_of(r)
    fresh();
    local o = cache.odds[r.id];
    if (o == nil) then o = L.odds(ST, r); cache.odds[r.id] = o; end
    return o;
end
local function check_of(r)
    fresh();
    local c = cache.check[r.id];
    if (c == nil) then c = L.check(ST, r, have, stored, has_ki); cache.check[r.id] = c; end
    return c;
end

-- Why a recipe can't be crafted right now (nil = it can)
local function craft_block(r)
    if (not ST.ready) then return 'Waiting for the server (Timeless Artisan module).'; end
    local o, c = odds_of(r), check_of(r);
    if (o.too_hard) then return 'Too difficult: more than 15 levels above your skill.'; end
    if (c.no_ki) then return 'Needs a key item you don\'t have (sold by the guild).'; end
    if (not c.ok) then
        local parts = {};
        for _, m in ipairs(c.missing) do
            parts[#parts + 1] = ('%s (%d of %d)'):format(L.is_crystal(m.id) and (L.ELEMENTS[L.CRYSTAL_ELEMENT[m.id]] .. ' crystal') or item_name(m.id), m.have, m.need);
        end
        return 'Missing: ' .. table.concat(parts, ', ');
    end
    if (queue_room() <= 0) then return 'The craft queue is full (12 crafts at most).'; end
    return nil;
end

local function is_fav(id)
    for _, f in ipairs(cfg.favorites or {}) do if (f == id) then return true; end end
    return false;
end
-- Gold star for favorites (Inter has the glyph; the default ImGui font doesn't, so it gets '*')
local function star(id, size)
    if (not is_fav(id)) then return false; end
    if (fonts_ok() and UF.get('bold')) then
        imgui_raw.PushFont(UF.get('bold'), size or font_on.size);
        imgui.TextColored(K.gold, '\226\152\133');
        imgui_raw.PopFont();
    else
        imgui.TextColored(K.gold, '*');
    end
    tip('Favorite');
    imgui.SameLine();
    return true;
end
local function toggle_fav(id)
    local list = cfg.favorites or T{};
    for i, f in ipairs(list) do
        if (f == id) then table.remove(list, i); cfg.favorites = list; settings.save(); return; end
    end
    list[#list + 1] = id;
    cfg.favorites = list;
    settings.save();
end

local function open_recipe(id)
    ui.sel_recipe = id;
    ui.tab_req = 'Search';
    cfg.show_main = true;
end

local function count_slider(width)
    imgui.PushItemWidth(width or 140);
    local v = { math.max(1, math.min(L.MAX_QUEUE, tonumber(cfg.craft_count) or 1)) };
    if (imgui.SliderInt('##count', v, 1, L.MAX_QUEUE, 'Craft x%d')) then cfg.craft_count = v[1]; ui.save_at = os.clock() + 1; end
    imgui.PopItemWidth();
    tip('How many times a Craft button crafts the recipe, one after another (1-12).\nThe queue holds 12 crafts at most, so this can be lower when crafts are already queued.');
end

-- Repeat: queue the last craft again (same recipe, same count)
local function last_recipe()
    local lc = cfg.last_craft;
    if (type(lc) ~= 'table' or tonumber(lc.id) == nil) then return nil, 0; end
    return IDX.by_id[tonumber(lc.id)], math.max(1, math.min(L.MAX_QUEUE, tonumber(lc.n) or 1));
end
local function repeat_button(label_suffix, small)
    local r, n = last_recipe();
    if (r == nil) then
        button('Repeat##rep' .. label_suffix, false, 'Craft something first: Repeat queues your last craft again.', small);
        return;
    end
    local block = craft_block(r);
    local label = ('Repeat: %s x%d##rep%s'):format(r.name, n, label_suffix);
    if (button(label, block == nil, block, small)) then craft(r, n); end
    if (block == nil) then tip(('Queue %s x%d again (your last craft).'):format(r.name, math.min(n, queue_room()))); end
end

----------------------------------------------------------------------------
-- Recipe table (Recipes, Favorites, Search)
----------------------------------------------------------------------------
local function recipe_table(list, id_prefix, opts)
    opts = opts or {};
    local cols = opts.fav and 8 or 7;
    if (not imgui.BeginTable(id_prefix, cols, bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit))) then return; end
    imgui.TableSetupColumn('Recipe', ImGuiTableColumnFlags_WidthStretch);
    imgui.TableSetupColumn('Lv');
    imgui.TableSetupColumn('Success');
    imgui.TableSetupColumn('HQ');
    imgui.TableSetupColumn('Skill-Up');
    imgui.TableSetupColumn('Can Make');
    imgui.TableSetupColumn('##craft');
    if (opts.fav) then imgui.TableSetupColumn('##fav'); end
    imgui.TableHeadersRow();
    for i, r in ipairs(list) do
        local o, c = odds_of(r), check_of(r);
        imgui.TableNextRow();
        imgui.TableNextColumn(); star(r.id); draw_icon(r.result, 18); imgui.SameLine();
        imgui.PushStyleColor(ImGuiCol_Text, o.too_hard and K.dim or (c.ok and K.text or K.muted));
        local label = r.name .. ((r.qty > 1) and (' x' .. r.qty) or '');
        if (imgui.Selectable(('%s##%s%d'):format(label, id_prefix, i), ui.sel_recipe == r.id, ImGuiSelectableFlags_SpanAllColumns or 0)) then open_recipe(r.id); end
        imgui.PopStyleColor();
        tip('Click for the full recipe: materials, results and every chance.');
        imgui.TableNextColumn();
        local subs = L.subcrafts(r);
        imgui.TextColored(K.text, tostring(r.level) .. (#subs > 0 and '+' or ''));
        if (#subs > 0) then
            local t = {};
            for _, s in ipairs(subs) do t[#t + 1] = ('%s %d'):format(L.CRAFTS[s.craft].name, s.level); end
            tip('Also needs ' .. table.concat(t, ', '));
        end
        imgui.TableNextColumn();
        if (o.too_hard) then imgui.TextColored(K.dim, 'Too hard'); tip('More than 15 levels above your skill: the server won\'t start it.');
        else imgui.TextColored(chance_col(o.success), pct(o.success)); tip('Chance the synthesis doesn\'t break.'); end
        imgui.TableNextColumn();
        if (o.hq > 0) then imgui.TextColored(K.gold, pct(o.hq)); tip(('High quality: HQ1 %s  HQ2 %s  HQ3 %s'):format(pct(o.hq1), pct(o.hq2), pct(o.hq3)));
        else imgui.TextColored(K.dim, '0%'); tip('No HQ: the recipe is above your skill, or a craft ring blocks it.'); end
        imgui.TableNextColumn();
        if (o.skillup > 0) then imgui.TextColored(K.green, pct(o.skillup)); tip('Chance of a skill-up per synth (breaks included).');
        else imgui.TextColored(K.dim, 'N/A'); tip('No skill-ups: the recipe is too far below you, or your skill is at its cap.'); end
        imgui.TableNextColumn();
        imgui.TextColored(c.max > 0 and K.green or K.dim, c.max > 0 and tostring(math.min(c.max, 999)) or '-');
        tip('How many times you could make it with your inventory and storage together.');
        imgui.TableNextColumn();
        local block = craft_block(r);
        if (button(('Craft##c%s%d'):format(id_prefix, i), block == nil, block, true)) then craft(r, cfg.craft_count); end
        if (block == nil) then tip(('Craft %d (materials come out of storage)'):format(math.max(1, math.min(cfg.craft_count or 1, queue_room())))); end
        if (opts.fav) then
            imgui.TableNextColumn();
            if (imgui.SmallButton(('x##f%s%d'):format(id_prefix, i))) then toggle_fav(r.id); end
            tip('Remove from Favorites');
        end
    end
    imgui.EndTable();
end

----------------------------------------------------------------------------
-- Recipe card
----------------------------------------------------------------------------
local function draw_recipe(r)
    if (r == nil) then imgui.TextDisabled('Pick a recipe.'); return; end
    local o, c = odds_of(r), check_of(r);
    draw_icon(r.result, 32);
    imgui.SameLine();
    imgui.BeginGroup();
    star(r.id, font_on.size * 1.35);
    heading(r.name .. ((r.qty > 1) and ('  x' .. r.qty) or ''), K.gold, 'title', 1.35);
    local subs = L.subcrafts(r);
    local t = { ('%s Lv %d'):format(L.CRAFTS[r.craft].name, r.level) };
    for _, s in ipairs(subs) do t[#t + 1] = ('%s %d'):format(L.CRAFTS[s.craft].name, s.level); end
    imgui.TextColored(K.muted, table.concat(t, '  |  ') .. ('  |  %s crystal'):format(L.ELEMENTS[r.element] or '?'));
    imgui.EndGroup();
    if (r.ki ~= 0) then
        imgui.TextColored(has_ki(r.ki) and K.green or K.amber, has_ki(r.ki) and 'Needs a guild key item: you have it.' or 'Needs a guild key item you don\'t have yet (sold by the guild).');
    end
    local fav = is_fav(r.id);
    if (imgui.SmallButton(fav and 'Remove from Favorites' or 'Add to Favorites')) then toggle_fav(r.id); end
    tip(fav and 'Take it off your Favorites tab and the HUD.' or 'Keep it on your Favorites tab and the HUD for quick crafting.');
    imgui.Separator();

    -- Chances
    if (imgui.CollapsingHeader('Your Chances', ImGuiTreeNodeFlags_DefaultOpen)) then
        if (imgui.BeginTable('##odds', 2, ImGuiTableFlags_SizingFixedFit)) then
            local function row(label, value, color, text)
                imgui.TableNextRow();
                imgui.TableNextColumn(); imgui.TextColored(K.muted, label);
                imgui.TableNextColumn(); imgui.TextColored(color, value);
                if (text) then tip(text); end
            end
            if (o.too_hard) then row('Synthesis', 'Too difficult', K.red, 'More than 15 levels above your skill in a craft: the server won\'t start it.'); end
            row('Success', pct(o.success), chance_col(o.success), 'Chance the synthesis doesn\'t break (every craft of the recipe rolls on its own).');
            if (o.hq > 0) then
                row('High quality', ('%s  (HQ1 %s, HQ2 %s, HQ3 %s)'):format(pct(o.hq), pct(o.hq1), pct(o.hq2), pct(o.hq3)), K.gold,
                    ('HQ tier %d of 4 (by how far above the recipe you are). %s of successful synths come out HQ, at most 80%%.'):format(o.hq_tier, pct(o.hq_given)));
            else
                row('High quality', 'None', K.dim, 'HQ needs every craft of the recipe at or above its level, and no craft ring for it.');
            end
            for i, cr in pairs(o.crafts) do
                local text, color;
                if ((cr.skillup or 0) > 0) then
                    text, color = pct(cr.skillup), K.green;
                elseif (cr.why == 'max') then text, color = 'N/A (skill 100)', K.dim;
                elseif (cr.why == 'cap') then text, color = ('N/A (rank cap %d)'):format(((ST.rank[i] or 0) + 1) * 10), K.dim;
                else text, color = 'N/A (too easy)', K.dim; end
                row(L.CRAFTS[i].name .. ' skill-up', text, color, ('Your skill %s, recipe %d. Per synth, breaks included (%s when it doesn\'t break).'):format(
                    L.skill_text(cr.skill), cr.need, pct(cr.on_success or 0)));
            end
            row('Lost on a break', ('%s per material'):format(pct(o.loss)), K.amber, 'Each material has this chance to be lost when the synthesis breaks; the crystal is always used.');
            if (o.made > 0 or ST.cp.on) then
                local nxt = nil;
                for _, tr in ipairs(ST.cp.tiers or {}) do if (o.made < tr.made) then nxt = tr; break; end end
                row('Made', ('%d%s'):format(o.made, nxt and ('  (%d more for +%d HQ)'):format(nxt.made - o.made, nxt.hq) or ''), K.blue,
                    'Recipe mastery (Craft Plus): Practiced at 25, Mastered at 50, Grandmaster at 100 made. Each raises the HQ chance.');
            end
            imgui.EndTable();
        end
        if (ST.cp.on and (ST.cp.ins or 0) > 0) then
            imgui.TextColored(K.dim, ('Flash of Insight: %d%% on any synth that can skill up or HQ (a sure skill-up, or a strong HQ).'):format(ST.cp.ins));
        end
    end

    -- Materials
    if (imgui.CollapsingHeader('Materials', ImGuiTreeNodeFlags_DefaultOpen)) then
        if (imgui.BeginTable('##mats', 4, bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit))) then
            imgui.TableSetupColumn('Item', ImGuiTableColumnFlags_WidthStretch);
            imgui.TableSetupColumn('Need');
            imgui.TableSetupColumn('Inventory');
            imgui.TableSetupColumn('Storage');
            imgui.TableHeadersRow();
            local function mat_row(id, need, inv_n, store_n, note)
                imgui.TableNextRow();
                imgui.TableNextColumn(); draw_icon(id, 16); imgui.SameLine();
                local ok = inv_n + store_n >= need;
                imgui.TextColored(ok and K.text or K.red, item_name(id));
                if (note) then tip(note); end
                imgui.TableNextColumn(); imgui.Text(tostring(need));
                imgui.TableNextColumn(); imgui.TextColored(inv_n > 0 and K.text or K.dim, tostring(inv_n));
                imgui.TableNextColumn(); imgui.TextColored(store_n > 0 and K.green or K.dim, commas(store_n));
            end
            local e = r.element;
            local inv_c, st_c = 0, 0;
            if (e > 0) then
                for _, id in ipairs(L.CRYSTAL_SETS[e]) do inv_c = inv_c + have(id); st_c = st_c + stored(id); end
                st_c = st_c + 12 * stored(L.cluster_of(e));
            end
            mat_row(r.crystal, 1, inv_c, st_c, ('Any %s crystal works. Stored %s clusters count 12 each (broken automatically).'):format(L.ELEMENTS[e] or '', L.ELEMENTS[e] or ''));
            for _, g in ipairs(r.ing) do mat_row(g.id, g.qty, have(g.id), stored(g.id)); end
            imgui.EndTable();
        end
    end

    -- Results
    if (imgui.CollapsingHeader('Results', ImGuiTreeNodeFlags_DefaultOpen)) then
        local names = { 'NQ', 'HQ1', 'HQ2', 'HQ3' };
        for k = 1, 4 do
            local id, q = r.res[k * 2 - 1], r.res[k * 2];
            if (id and id > 0) then
                imgui.TextColored(k == 1 and K.muted or K.gold, names[k]); imgui.SameLine(48);
                draw_icon(id, 16); imgui.SameLine();
                imgui.Text(('%s x%d'):format(item_name(id), q or 1));
            end
        end
    end

    imgui.Spacing();
    count_slider(150);
    imgui.SameLine();
    local block = craft_block(r);
    local n = math.max(1, math.min(cfg.craft_count or 1, queue_room()));
    if (button(('Craft %d##card'):format(n), block == nil, block)) then craft(r, n); end
    if (block ~= nil) then imgui.TextColored(K.amber, block); end
    if (c.max > 0) then imgui.TextColored(K.dim, ('Enough materials for %d.'):format(c.max)); end
end

----------------------------------------------------------------------------
-- Tabs
----------------------------------------------------------------------------
local BANDS = { { 0, 10 }, { 11, 20 }, { 21, 30 }, { 31, 40 }, { 41, 50 }, { 51, 60 }, { 61, 70 }, { 71, 80 }, { 81, 90 }, { 91, 100 }, { 101, 120 } };

local function tab_recipes()
    -- crafts on the left, like the angler's Zones tab
    imgui.BeginChild('##crafts', { 210, 0 }, ImGuiChildFlags_Borders or 1);
    heading('Crafts', K.gold);
    for i, c in ipairs(L.CRAFTS) do
        local label = ('%s##cr%d'):format(c.name, i);
        if (imgui.Selectable(label, (ui.sel_craft or 1) == i)) then ui.sel_craft = i; end
        imgui.SameLine(150);
        imgui.TextColored(K.muted, L.skill_text(ST.skill[i]));
    end
    imgui.Spacing();
    local v = { cfg.hide_hard == true };
    if (imgui.Checkbox('Hide recipes I can\'t attempt', v)) then cfg.hide_hard = v[1]; settings.save(); end
    tip('Hides recipes more than 15 levels above your skill in any of their crafts: the server won\'t start those.');
    v = { cfg.only_make == true };
    if (imgui.Checkbox('Only recipes I have materials for', v)) then cfg.only_make = v[1]; settings.save(); end
    tip('Shows only recipes whose crystal and ingredients you have, counting your inventory and storage together.');
    imgui.EndChild();
    imgui.SameLine();
    panel_begin('##craftdetail', 0, true);
    local ci = ui.sel_craft or 1;
    heading(L.CRAFTS[ci].name, K.gold, 'title', 1.2);
    imgui.SameLine();
    imgui.TextColored(K.muted, ('  skill %s, %s'):format(L.skill_text(ST.skill[ci]), L.RANKS[ST.rank[ci] or 0] or '?'));
    count_slider();
    local lvl = math.floor((ST.skill[ci] or 0) / 10);
    for b, band in ipairs(BANDS) do
        local list = {};
        for _, r in ipairs(IDX.by_craft[ci]) do
            if (r.level >= band[1] and r.level <= band[2]) then
                local keep = true;
                if (cfg.hide_hard and odds_of(r).too_hard) then keep = false; end
                if (keep and cfg.only_make and not check_of(r).ok) then keep = false; end
                if (keep) then list[#list + 1] = r; end
            end
        end
        if (#list > 0) then
            local near = lvl >= band[1] - 5 and lvl <= band[2] + 2;
            local hdr = ('Level %d-%d  (%d)%s###band%d_%d'):format(math.max(1, band[1]), band[2], #list, near and '  - your level' or '', ci, b);
            if (imgui.CollapsingHeader(hdr, near and ImGuiTreeNodeFlags_DefaultOpen or 0)) then
                recipe_table(list, ('##rb%d_%d'):format(ci, b));
            end
        end
    end
    imgui.EndChild();
end

local search_cache = { q = nil, rev = 0, list = {} };
local function search_list(q)
    if (search_cache.q == q) then return search_cache.list; end
    local list = {};
    if (q ~= '') then
        local seen = {};
        for _, r in ipairs(IDX.list) do
            if (r.name:lower():find(q, 1, true)) then list[#list + 1] = r; seen[r.id] = true; end
        end
        if (#q >= 3) then -- ingredients too
            for _, r in ipairs(IDX.list) do
                if (not seen[r.id]) then
                    for _, g in ipairs(r.ing) do
                        if (item_name(g.id):lower():find(q, 1, true)) then list[#list + 1] = r; seen[r.id] = true; break; end
                    end
                end
            end
        end
        table.sort(list, function (a, b) if (a.level ~= b.level) then return a.level < b.level; end return a.name < b.name; end);
    end
    search_cache.q, search_cache.list = q, list;
    return list;
end

local function tab_search()
    imgui.BeginChild('##slist', { 260, 0 }, ImGuiChildFlags_Borders or 1);
    imgui.PushItemWidth(-1);
    imgui.InputText('##search', ui.search, 48);
    imgui.PopItemWidth();
    tip('A result (e.g. "bronze") or, with 3+ letters, an ingredient (e.g. "copper ore").');
    local q = (ui.search[1] or ''):lower();
    local list = search_list(q);
    if (q == '') then imgui.TextColored(K.dim, 'Type a name to search.'); else imgui.TextColored(K.dim, ('%d recipes'):format(#list)); end
    for i, r in ipairs(list) do
        if (i > 300) then imgui.TextColored(K.dim, 'More... type more letters.'); break; end
        star(r.id); draw_icon(r.result, 18); imgui.SameLine();
        local o = odds_of(r);
        imgui.PushStyleColor(ImGuiCol_Text, o.too_hard and K.dim or (check_of(r).ok and K.text or K.muted));
        if (imgui.Selectable(('%s##s%d'):format(r.name, r.id), ui.sel_recipe == r.id)) then ui.sel_recipe = r.id; end
        imgui.PopStyleColor();
        imgui.SameLine(200); imgui.TextColored(K.dim, ('%s %d'):format(L.CRAFTS[r.craft].short, r.level));
    end
    imgui.EndChild();
    imgui.SameLine();
    panel_begin('##sdetail', 0, true);
    if (ui.sel_recipe == nil and #list > 0) then ui.sel_recipe = list[1].id; end
    draw_recipe(IDX.by_id[ui.sel_recipe or -1]);
    imgui.EndChild();
end

local function tab_favorites()
    local list = {};
    for _, id in ipairs(cfg.favorites or {}) do if (IDX.by_id[id]) then list[#list + 1] = IDX.by_id[id]; end end
    if (#list == 0) then
        heading('Favorites', K.gold);
        imgui.TextWrapped('No favorites yet. Open a recipe (Recipes or Search tab) and press "Add to Favorites" to keep it here (and on the HUD) for quick crafting. Favorites show a gold star in every list.');
        return;
    end
    heading(('Favorites (%d)'):format(#list), K.gold);
    imgui.SameLine();
    count_slider();
    recipe_table(list, '##fav', { fav = true });
end

-- JST midnight (when guild points reset)
local function jst_reset_left()
    local now = os.time();
    local utc = os.date('!*t', now);
    local jst_secs = (utc.hour * 3600 + utc.min * 60 + utc.sec + 9 * 3600) % 86400;
    return 86400 - jst_secs;
end

local function tab_guilds()
    heading('Guild Point Items', K.gold);
    imgui.SameLine();
    if (imgui.SmallButton('Refresh##gd')) then request('gd'); end
    local left = jst_reset_left();
    imgui.TextColored(K.muted, ('Each guild\'s item changes with your rank in it and resets at Japanese midnight (in %dh %02dm).'):format(math.floor(left / 3600), math.floor(left % 3600 / 60)));
    local contract = nil;
    for g, info in pairs(ST.guilds) do if (info.contract) then contract = g; end end
    if (contract) then
        imgui.TextColored(K.green, ('Your guild contract: %s. Only that guild\'s union representative takes your items.'):format(L.GUILDS[contract]));
    else
        imgui.TextColored(K.amber, 'You have no guild contract: sign one with a guild\'s union representative to earn guild points.');
    end
    if (next(ST.guilds) == nil) then imgui.TextDisabled('Waiting for the server...'); return; end
    if (imgui.BeginTable('##guilds', 9, bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit))) then
        imgui.TableSetupColumn('Guild');
        imgui.TableSetupColumn('Today\'s Item', ImGuiTableColumnFlags_WidthStretch);
        imgui.TableSetupColumn('Points Each');
        imgui.TableSetupColumn('Daily Max');
        imgui.TableSetupColumn('Left Today');
        imgui.TableSetupColumn('Items Needed');
        imgui.TableSetupColumn('You Have');
        imgui.TableSetupColumn('Crafts');
        imgui.TableSetupColumn('##go');
        imgui.TableHeadersRow();
        for g = 1, 8 do
            local p = L.guild_plan(ST, IDX, g, have, stored);
            if (p) then
                imgui.TableNextRow();
                imgui.TableNextColumn();
                imgui.TextColored(p.contract and K.gold or K.text, L.GUILDS[g]);
                if (p.contract) then tip('Your guild contract'); end
                imgui.TableNextColumn(); draw_icon(p.item, 16); imgui.SameLine();
                if (p.recipe) then
                    if (imgui.Selectable(('%s##gi%d'):format(item_name(p.item), g), false)) then open_recipe(p.recipe.id); end
                    tip(('%s Lv %d: click for the recipe. Only normal quality counts (HQ items don\'t).'):format(L.CRAFTS[p.recipe.craft].name, p.recipe.level));
                else
                    imgui.Text(item_name(p.item));
                end
                imgui.TableNextColumn(); imgui.Text(tostring(p.points));
                imgui.TableNextColumn(); imgui.TextColored(K.muted, commas(p.max));
                tip(('A full day is %d items.'):format(p.full_day));
                imgui.TableNextColumn();
                if (p.contract) then imgui.TextColored(p.remaining > 0 and K.green or K.dim, commas(p.remaining));
                else imgui.TextColored(K.dim, '-'); tip('Only your contracted guild gives points.'); end
                imgui.TableNextColumn();
                local items = p.contract and p.items or p.full_day;
                imgui.TextColored(items > 0 and K.text or K.dim, tostring(items));
                tip(p.contract and 'Items still worth points today.' or 'Items for a full day (if this were your guild).');
                imgui.TableNextColumn(); imgui.TextColored(p.own > 0 and K.blue or K.dim, tostring(p.own));
                tip('In your inventory and storage.');
                local to_make = math.max(0, items - p.own);
                local crafts = p.recipe and math.ceil(to_make / math.max(1, p.recipe.qty)) or 0;
                imgui.TableNextColumn();
                imgui.TextColored(crafts > 0 and K.text or K.dim, p.recipe and tostring(crafts) or '-');
                if (p.recipe and p.recipe.qty > 1) then tip(('Each synth makes %d.'):format(p.recipe.qty)); end
                imgui.TableNextColumn();
                if (p.recipe and crafts > 0) then
                    local n = math.min(crafts, queue_room(), L.MAX_QUEUE);
                    local block = craft_block(p.recipe);
                    if (button(('Craft %d##g%d'):format(math.max(1, n), g), block == nil and n > 0, block or 'The craft queue is full.', true)) then craft(p.recipe, n); end
                    if (block == nil) then tip(crafts > n and ('Queues %d now (12 at most); come back for the rest.'):format(n) or 'Queue what you need.'); end
                elseif (p.recipe == nil) then
                    imgui.TextColored(K.dim, 'Not crafted');
                else
                    imgui.TextColored(K.green, 'Done');
                end
            end
        end
        imgui.EndTable();
    end
    local f = ST.guilds[0];
    if (f) then
        imgui.Spacing();
        imgui.TextColored(K.muted, 'Fishing guild:'); imgui.SameLine(); draw_icon(f.item, 16); imgui.SameLine();
        imgui.Text(('%s  (%d points each, %s a day)'):format(item_name(f.item), f.points, commas(f.max)));
        tip('Fish it: /angler search ' .. item_name(f.item));
    end
    imgui.Spacing();
    imgui.TextColored(K.dim, 'Hand the items to your guild\'s union representative. Points count once per Japanese day across all guilds.');
end

local function storage_rows()
    local ids, seen = {}, {};
    local function add(id) if (not seen[id]) then seen[id] = true; ids[#ids + 1] = id; end end
    for id in pairs(ST.store) do add(id); end
    for id in pairs(ST.store_own) do add(id); end
    for bag, t in pairs(BAGS) do
        if (bag ~= 1 and bag ~= 2 and bag ~= 4 and bag ~= 9) then
            for id in pairs(t) do if (IDX.materials[id]) then add(id); end end
        end
    end
    local q = (ui.store_filter[1] or ''):lower();
    local out = {};
    for _, id in ipairs(ids) do
        if (q == '' or item_name(id):lower():find(q, 1, true)) then out[#out + 1] = id; end
    end
    table.sort(out, function (a, b)
        local ca, cb = L.is_crystal(a) or L.is_cluster(a), L.is_crystal(b) or L.is_cluster(b);
        if (ca ~= cb) then return ca; end
        if (ca) then return a < b; end
        return item_name(a) < item_name(b);
    end);
    return out;
end

local function auto_has(id)
    for _, x in ipairs(cfg.auto_items or {}) do if (x == id) then return true; end end
    return false;
end
local function auto_toggle(id)
    local list = cfg.auto_items or T{};
    for i, x in ipairs(list) do if (x == id) then table.remove(list, i); cfg.auto_items = list; settings.save(); return; end end
    list[#list + 1] = id;
    cfg.auto_items = list;
    settings.save();
end

local function withdraw(id, n)
    if (n <= 0) then return; end
    keep.pending[id] = (keep.pending[id] or 0) + n;   -- kept from the moment you ask
    keep.asked[id] = os.clock();
    request(('wd %d %d'):format(id, n));
end

-- Withdraw all: one request; every item moved comes back as a D line and is kept (like a hand withdrawal)
local function withdraw_all()
    for id in pairs(ST.store) do keep.pending[id] = (keep.pending[id] or 0); keep.asked[id] = os.clock(); end
    for id in pairs(ST.store_own) do keep.pending[id] = (keep.pending[id] or 0); keep.asked[id] = os.clock(); end
    request('wa');
end

local function storage_row(id)
    local s, inv_n, bag_n = stored(id), have(id), in_bags(id, true);
    imgui.TableNextRow();
    imgui.TableNextColumn(); draw_icon(id, 16); imgui.SameLine();
    imgui.Text(item_name(id));
    do
        local parts = {};
        if ((ST.store_own[id] or 0) > 0) then parts[#parts + 1] = 'Rare / Ex: stored for this character only.'; end
        local mc = IDX.mat_crafts[id];
        if (mc) then
            local u = {};
            for c = 1, 8 do if ((mc[c] or 0) > 0) then u[#u + 1] = ('%s %d'):format(L.CRAFTS[c].name, mc[c]); end end
            parts[#parts + 1] = (#u > 0) and ('Used in: ' .. table.concat(u, ', ')) or 'A crafting material no recipe on this server uses (sell it, trade it or keep it).';
        end
        if (#parts > 0) then tip(table.concat(parts, '\n')); end
    end
    local keeping = kept_of(id);
    if (keeping > 0) then
        imgui.SameLine();
        imgui.TextColored(K.blue, ('keeping %d'):format(keeping));
        tip(('You withdrew these, so auto-deposit leaves %d alone and only stores any extra you pick up.\nIt lets go as you use them up, or when you press Deposit.'):format(keeping));
        imgui.SameLine();
        if (imgui.SmallButton(('x##rk%d'):format(id))) then kept_release(id); net.next_auto = os.clock() + 2; end
        tip('Stop keeping them (auto-deposit may store them again).');
    end
    imgui.TableNextColumn(); imgui.TextColored(s > 0 and K.green or K.dim, commas(s));
    imgui.TableNextColumn(); imgui.TextColored(inv_n + bag_n > 0 and K.text or K.dim, tostring(inv_n) .. (bag_n > 0 and (' +' .. bag_n) or ''));
    tip('Inventory (+ satchel, sack, case and Mog House bags).');
    imgui.TableNextColumn();
    -- Withdraw: type how many (of N stored), then the button
    if (s > 0) then
        local buf = ui.wd[id];
        if (buf == nil) then buf = { '1' }; ui.wd[id] = buf; end
        imgui.PushItemWidth(56);
        imgui.InputText(('##wq%d'):format(id), buf, 8, ImGuiInputTextFlags_CharsDecimal or 0);
        imgui.PopItemWidth();
        tip(('How many to withdraw (1 - %s).'):format(commas(s)));
        imgui.SameLine();
        imgui.TextColored(K.muted, '/ ' .. commas(s));
        imgui.SameLine();
        local want = L.parse_amount(buf[1], s);
        if (button(('Withdraw##w%d'):format(id), want ~= nil, 'Type how many to withdraw.', true)) then
            withdraw(id, want);
            buf[1] = '1';
        end
        if (want) then tip(('Withdraw %s %s into your inventory (as much as it has room for).'):format(commas(want), item_name(id))); end
    else
        imgui.TextColored(K.dim, 'None stored');
    end
    imgui.TableNextColumn();
    if (button(('Deposit##d%d'):format(id), inv_n + bag_n > 0, 'None in your bags.', true)) then
        kept_release(id);
        request(('dp %d %d:0'):format(deposit_mask(false), id));
    end
    imgui.TableNextColumn();
    local a = { auto_has(id) };
    if (imgui.Checkbox(('##auto%d'):format(id), a)) then auto_toggle(id); end
    tip('Auto-deposit this item (when auto-deposit is set to "chosen items").');
end

local function tab_storage()
    local kinds, total = 0, 0;
    for _, n in pairs(ST.store) do kinds = kinds + 1; total = total + n; end
    for _, n in pairs(ST.store_own) do kinds = kinds + 1; total = total + n; end
    heading('Crafting Storage', K.gold);
    imgui.SameLine();
    imgui.TextColored(K.muted, ('  %s in storage (%s)  |  %s free in your inventory'):format(plural(total, 'item'), plural(kinds, 'material type'), plural(INV_FREE, 'slot')));
    if (button('Deposit all crafting materials', ST.ready, 'Waiting for the server.')) then deposit_all(nil); end
    tip('Every crafting material in your inventory' .. ((cfg.bag_satchel or cfg.bag_sack or cfg.bag_case) and ', satchel, sack and case' or '') ..
        ' goes into storage. Equipped items stay. (Bags: Settings tab.)');
    imgui.SameLine();
    local can_wa = ST.ready and (ST.v.ver or 0) >= 2 and total > 0;
    local confirming = ui.wa_confirm and os.clock() < ui.wa_confirm;
    if (button(confirming and 'Click again to withdraw everything' or 'Withdraw all crafting materials', can_wa,
            (ST.ready and (ST.v.ver or 0) < 2) and 'Needs the server update (Timeless Artisan server module 2).' or 'Nothing stored.')) then
        if (confirming) then ui.wa_confirm = nil; withdraw_all(); else ui.wa_confirm = os.clock() + 4; end
    end
    if (can_wa) then tip('Everything in storage comes back into your inventory, until it is full. Auto-deposit leaves it alone (kept).'); end
    imgui.SameLine();
    if (imgui.Button('Refresh')) then request('st'); end
    imgui.SameLine();
    local v = { ui.show_acct };
    if (imgui.Checkbox('All my characters', v)) then ui.show_acct = v[1]; if (v[1]) then request('ac'); end end
    tip('What your other characters on this account keep in their bags (as of their last save).');

    -- Auto-deposit
    imgui.PushItemWidth(220);
    local modes = { [0] = 'Auto-deposit: off', 'Auto-deposit: all materials', 'Auto-deposit: chosen items' };
    if (imgui.BeginCombo('##automode', modes[cfg.auto_mode or 0] or modes[0])) then
        for m = 0, 2 do
            if (imgui.Selectable(modes[m] .. '##am' .. m, (cfg.auto_mode or 0) == m)) then cfg.auto_mode = m; settings.save(); net.next_auto = os.clock() + 2; end
        end
        imgui.EndCombo();
    end
    imgui.PopItemWidth();
    tip('A few seconds after your inventory changes, crafting materials go into storage by themselves (never while crafts are queued).\n"Chosen items": tick the Auto box of each item below.\nItems you withdraw are kept: auto-deposit leaves them alone and only stores extras you pick up.');
    imgui.SameLine();
    v = { cfg.auto_bags == true };
    if (imgui.Checkbox('Also from satchel, sack and case', v)) then cfg.auto_bags = v[1]; settings.save(); end

    imgui.PushItemWidth(260);
    imgui.InputText('##sfilter', ui.store_filter, 48);
    imgui.PopItemWidth();
    tip('Filter by name.');

    local rows = storage_rows();
    local h = ui.show_acct and 0.55 or 1;
    local _, avail_h = imgui.GetContentRegionAvail();
    imgui.BeginChild('##storetable', { 0, ui.show_acct and math.max(160, (tonumber(avail_h) or 400) * h) or 0 }, 0);
    if (#rows == 0) then
        imgui.TextWrapped('Nothing stored yet. Press "Deposit all crafting materials", or turn on auto-deposit above.');
    else
        local groups = {};
        for _, id in ipairs(rows) do
            local g = L.group_of(IDX, id);
            groups[g] = groups[g] or {};
            table.insert(groups[g], id);
        end
        for g = 0, 9 do
            local list = groups[g];
            if (list) then
                local n = 0;
                for _, id in ipairs(list) do n = n + stored(id); end
                local hdr = ('%s  -  %s, %s stored###sg%d'):format(L.GROUP_NAMES[g], plural(#list, 'material type'), plural(n, 'item'), g);
                if (imgui.CollapsingHeader(hdr, ImGuiTreeNodeFlags_DefaultOpen)) then
                    if (imgui.BeginTable(('##store%d'):format(g), 6, bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit))) then
                        imgui.TableSetupColumn('Material', ImGuiTableColumnFlags_WidthStretch);
                        imgui.TableSetupColumn('Stored');
                        imgui.TableSetupColumn('In Bags');
                        imgui.TableSetupColumn('Withdraw');
                        imgui.TableSetupColumn('Deposit');
                        imgui.TableSetupColumn('Auto');
                        imgui.TableHeadersRow();
                        for _, id in ipairs(list) do storage_row(id); end
                        imgui.EndTable();
                    end
                end
            end
        end
    end
    imgui.EndChild();

    if (ui.show_acct) then
        heading('All My Characters', K.gold);
        imgui.SameLine();
        if (imgui.SmallButton('Refresh##ac')) then request('ac'); end
        imgui.BeginChild('##acct', { 0, 0 }, ImGuiChildFlags_Borders or 1);
        if (#ST.acct == 0) then
            imgui.TextColored(K.dim, ST.acct_at and 'Your other characters hold no crafting materials.' or 'Asking the server...');
        end
        local last = nil;
        for k, e in ipairs(ST.acct) do
            if (e.name ~= last) then heading(e.name, K.blue, 'title', 1.0); last = e.name; end
            local ids = {};
            for id in pairs(e.items) do ids[#ids + 1] = id; end
            table.sort(ids, function (a, b) return item_name(a) < item_name(b); end);
            if (imgui.CollapsingHeader(('%s  (%d)###acb%d'):format(L.BAGS[e.loc] or ('Bag ' .. e.loc), #ids, k))) then
                for _, id in ipairs(ids) do
                    draw_icon(id, 14); imgui.SameLine();
                    imgui.Text(('%s x%d'):format(item_name(id), e.items[id]));
                end
            end
        end
        imgui.TextColored(K.dim, 'Log in on that character to put its materials into the shared storage.');
        imgui.EndChild();
    end
end

local function tab_queue()
    heading('Craft Queue', K.gold);
    imgui.SameLine();
    imgui.TextColored(K.muted, ('  %d of %d'):format(queue_size(), ST.v.max or L.MAX_QUEUE));
    if (ST.queue.run and ST.queue.cur > 0) then
        local r = IDX.by_id[ST.queue.cur];
        imgui.TextColored(K.gold, 'Crafting now:'); imgui.SameLine();
        if (r) then draw_icon(r.result, 16); imgui.SameLine(); end
        imgui.Text(r and r.name or ('recipe ' .. ST.queue.cur));
    elseif (queue_size() == 0) then
        imgui.TextColored(K.dim, 'Nothing queued. Use a Craft button on any recipe (up to 12 in a row).');
    end
    for i, e in ipairs(ST.queue.list) do
        local r = IDX.by_id[e.r];
        imgui.TextColored(K.muted, ('%d.'):format(i)); imgui.SameLine();
        if (r) then draw_icon(r.result, 16); imgui.SameLine(); end
        imgui.Text(('%s x%d'):format(r and r.name or ('recipe ' .. e.r), e.n));
    end
    if (button('Stop the queue', queue_size() > 0, 'Nothing queued.')) then request('cx'); end
    imgui.SameLine();
    repeat_button('queue', false);
    tip('Clears the queue. A synthesis already running still finishes.');
    imgui.TextColored(K.dim, 'Each craft starts after the last one finishes (15 seconds apart at the quickest, like the synthesis menu).');
    imgui.Separator();
    heading('This Session', K.gold, 'title', 1.0);
    imgui.Text(('Made %d   HQ %d   Broke %d'):format(session.made, session.hq, session.broke));
    local ups = {};
    for craft_name, n in pairs(session.skill) do ups[#ups + 1] = ('%s +%.1f'):format(craft_name, n); end
    if (#ups > 0) then imgui.TextColored(K.green, 'Skill-ups: ' .. table.concat(ups, ', ')); end
    imgui.SameLine();
    if (imgui.SmallButton('Reset##sess')) then session = { start = os.time(), made = 0, hq = 0, broke = 0, skill = {}, log = {}, by = {} }; end
    imgui.BeginChild('##log', { 0, 0 }, ImGuiChildFlags_Borders or 1);
    for _, e in ipairs(session.log) do
        imgui.TextColored(K.dim, e.t); imgui.SameLine(); imgui.TextColored(e.c, e.text);
    end
    imgui.EndChild();
end

local function tab_bonuses()
    heading('Your Crafts', K.gold);
    if (imgui.BeginTable('##skills', 5, bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit))) then
        imgui.TableSetupColumn('Craft', ImGuiTableColumnFlags_WidthStretch);
        imgui.TableSetupColumn('Skill');
        imgui.TableSetupColumn('Rank');
        imgui.TableSetupColumn('Cap');
        imgui.TableSetupColumn('Gear');
        imgui.TableHeadersRow();
        for i, c in ipairs(L.CRAFTS) do
            local cap = ((ST.rank[i] or 0) + 1) * 10;
            imgui.TableNextRow();
            imgui.TableNextColumn(); imgui.Text(c.name);
            imgui.TableNextColumn(); imgui.TextColored((ST.skill[i] or 0) >= cap * 10 and K.blue or K.text, L.skill_text(ST.skill[i]));
            imgui.TableNextColumn(); imgui.TextColored(K.muted, L.RANKS[ST.rank[i] or 0] or '?');
            imgui.TableNextColumn(); imgui.TextColored(K.muted, tostring(math.min(cap, 100)));
            tip('Skill-ups stop at your guild rank\'s cap: rank up at the guild.');
            imgui.TableNextColumn();
            local g = ST.mods.c[i] or 0;
            imgui.TextColored(g > 0 and K.green or K.dim, g ~= 0 and ('%+d'):format(g) or '-');
            tip('Crafting skill from gear (and image support): counts for success and HQ, not for skill-ups.');
        end
        imgui.EndTable();
    end
    imgui.Spacing();
    heading('Current Effects', K.gold);
    if (imgui.BeginTable('##fx', 3, bit.bor(ImGuiTableFlags_RowBg, ImGuiTableFlags_SizingFixedFit))) then
        imgui.TableSetupColumn('Effect', ImGuiTableColumnFlags_WidthStretch);
        imgui.TableSetupColumn('Now');
        imgui.TableSetupColumn('What It Does');
        imgui.TableHeadersRow();
        local function row(name, now, on, what)
            imgui.TableNextRow();
            imgui.TableNextColumn(); imgui.Text(name);
            imgui.TableNextColumn(); imgui.TextColored(on and K.green or K.dim, now);
            imgui.TableNextColumn(); imgui.TextColored(K.muted, what);
        end
        local m, cp = ST.mods, ST.cp;
        row('Success rate', m.sr ~= 0 and ('%+d%%'):format(m.sr) or 'None', m.sr > 0, 'Gear and the guild Workshop: fewer breaks');
        row('HQ rate', m.hq ~= 0 and ('%+d (about %+.1f%%)'):format(m.hq, 100 * m.hq / 512) or 'None', m.hq > 0, 'Gear and the guild Workshop');
        row('Skill-up rate', m.sg ~= 0 and ('%+d%%'):format(m.sg) or 'None', m.sg > 0, 'Gear and the guild Workshop');
        local rings = {};
        for i = 1, 8 do if ((m.ah[i] or 0) ~= 0) then rings[#rings + 1] = L.CRAFTS[i].name; end end
        row('Craft ring', #rings > 0 and table.concat(rings, ', ') or 'None', #rings > 0, '+1% success, but no HQ in that craft');
        if (cp.on) then
            row('Rested synths', ('%d / %d'):format(cp.r, cp.rm), cp.r > 0, ('+%d%% skill-up chance on synths that can skill up; 2 back each hour away'):format(cp.rg));
            local ls = {};
            for i = 1, 8 do if ((cp.l[i] or 0) > 0) then ls[#ls + 1] = ('%s %d'):format(L.CRAFTS[i].short, cp.l[i]); end end
            row('Lessons from breaks', #ls > 0 and table.concat(ls, ', ') or 'None', #ls > 0, ('+%d%% skill-up each, until your next skill-up in that craft'):format(cp.lg));
            row('Flash of Insight', cp.rdy and 'Ready!' or ('%d%%'):format(cp.ins), cp.rdy, 'A sure skill-up, or a strong HQ chance');
            row('Guild rank', cp.gl > 0 and ('-%d%%'):format(cp.gl) or 'None', cp.gl > 0, 'Fewer materials lost on a break (Artisans Guild standing)');
            row('Guild feast', cp.fs > 0 and ('+%d%%'):format(cp.fs) or 'Not running', cp.fs > 0, 'Skill-up chance for everyone online');
            row('Mog House furniture', cp.hh > 0 and ('+%d HQ'):format(cp.hh) or 'None', cp.hh > 0, 'Water furniture raises the HQ rate (Hearth)');
        end
        imgui.EndTable();
    end
    imgui.Spacing();
    heading('What Doesn\'t Matter', K.gold);
    imgui.TextWrapped('The moon phase, the day of the week, the weather, the time of day and the direction you face have no effect on synthesis on Timeless XI: the server\'s synthesis code never looks at them. Craft anywhere, any time.');
    imgui.TextColored(K.dim, 'Success, HQ and skill-ups depend only on your skill against the recipe, crafting gear and rings, and the effects above.');
end

----------------------------------------------------------------------------
-- Settings, window size / position
----------------------------------------------------------------------------
local WIN_DEFAULT = { main = { x = 80, y = 70, w = 780, h = 580 }, hud = { x = 20, y = 420, w = 320, h = 0 } };
local reset_pending = {};
local function save_soon() ui.save_at = os.clock() + 1.0; end
local function alpha_of(key, default)
    local v = tonumber(cfg[key .. '_alpha']) or default;
    return math.max(0.2, math.min(1.0, v));
end
local function window_prep(key, default_alpha, skip_size)
    local r, d = cfg[key .. '_rect'], WIN_DEFAULT[key];
    local reset = reset_pending[key];
    reset_pending[key] = nil;
    local cond = reset and ImGuiCond_Always or ImGuiCond_FirstUseEver;
    local src = (not reset and type(r) == 'table' and tonumber(r.w)) and r or d;
    imgui.SetNextWindowPos({ src.x, src.y }, cond);
    if (not skip_size and tonumber(src.h) and src.h > 0) then imgui.SetNextWindowSize({ src.w, src.h }, cond); end
    imgui.SetNextWindowBgAlpha(alpha_of(key, default_alpha));
end
local function window_track(key)
    local x, y = imgui.GetWindowPos();
    local w, h = imgui.GetWindowSize();
    if (type(x) ~= 'number' or type(w) ~= 'number') then return; end
    local r = cfg[key .. '_rect'];
    if (type(r) ~= 'table' or math.abs((tonumber(r.x) or 0) - x) > 0.5 or math.abs((tonumber(r.y) or 0) - y) > 0.5
        or math.abs((tonumber(r.w) or 0) - w) > 0.5 or math.abs((tonumber(r.h) or 0) - h) > 0.5) then
        cfg[key .. '_rect'] = { x = math.floor(x + 0.5), y = math.floor(y + 0.5), w = math.floor(w + 0.5), h = math.floor(h + 0.5) };
        save_soon();
    end
end

local function tab_settings()
    heading('Window Opacity', K.gold);
    imgui.PushItemWidth(240);
    local g = { math.floor(alpha_of('main', 0.94) * 100 + 0.5) };
    if (imgui.SliderInt('Window##op', g, 20, 100, '%d%%')) then cfg.main_alpha = g[1] / 100; save_soon(); end
    local h = { math.floor(alpha_of('hud', 0.88) * 100 + 0.5) };
    if (imgui.SliderInt('HUD##op', h, 20, 100, '%d%%')) then cfg.hud_alpha = h[1] / 100; save_soon(); end
    imgui.PopItemWidth();
    imgui.TextColored(K.dim, 'Only the background fades; text stays solid. Also: /artisan opacity window|hud <20-100>');
    imgui.Spacing();

    heading('Window Size', K.gold);
    imgui.TextWrapped('Drag the bottom-right corner of the window or the HUD to resize it, and its title bar (or anywhere on the HUD) to move it. Sizes and positions are saved for this character.');
    if (imgui.Button('Fit HUD to contents')) then ui.hud_fit = 3; end
    imgui.SameLine();
    if (imgui.Button('Reset sizes and positions')) then
        cfg.main_rect, cfg.hud_rect = nil, nil;
        reset_pending.main, reset_pending.hud = true, true;
        ui.hud_fit = 3;
        save_soon();
    end
    imgui.Spacing();

    heading('Text', K.gold);
    imgui.PushItemWidth(240);
    local fs = { font_on.size };
    if (imgui.SliderInt('Text size', fs, 11, 24, '%d px')) then cfg.font_size = fs[1]; font_on.size = fs[1]; save_soon(); end
    imgui.PopItemWidth();
    imgui.PushItemWidth(240);
    if (imgui.BeginCombo('Title font', UF.title_label())) then
        for _, name in ipairs(UF.TITLE_ORDER) do
            if (imgui.Selectable(UF.title_label(name), UF.title == name)) then UF.set_title(name); end
        end
        imgui.EndCombo();
    end
    imgui.PopItemWidth();
    imgui.PushItemWidth(240);
    if (imgui.BeginCombo('Text font', UF.text_label())) then
        for _, name in ipairs(UF.TEXT_ORDER) do
            if (imgui.Selectable(UF.text_label(name) .. '##tx', UF.text == name)) then UF.set_text(name); end
        end
        imgui.EndCombo();
    end
    imgui.PopItemWidth();
    imgui.TextColored(K.dim, 'Fonts are shared with Timeless Angler and the fishing mini-game.');
    imgui.Spacing();

    heading('HUD', K.gold);
    local v = { cfg.show_hud ~= false };
    if (imgui.Checkbox('Show the HUD', v)) then cfg.show_hud = v[1]; save_soon(); end
    tip('The HUD is a small crafting window: favorites with Craft buttons, Repeat, the queue and storage at a glance.');
    v = { cfg.hud_auto == true };
    if (imgui.Checkbox('Only while crafts are queued', v)) then cfg.hud_auto = v[1]; save_soon(); end
    tip('Hide the HUD whenever nothing is being crafted.');
    imgui.Spacing();

    heading('Crafting and Storage', K.gold);
    v = { cfg.return_left ~= false };
    if (imgui.Checkbox('After each queued craft, put leftovers back into storage', v)) then cfg.return_left = v[1]; save_soon(); end
    tip('Materials saved on a break, unused crystals of the recipe, and the result if it is itself a crafting material.');
    imgui.Text('"Deposit" buttons take from the inventory and:');
    v = { cfg.bag_satchel ~= false };
    if (imgui.Checkbox('Mog Satchel', v)) then cfg.bag_satchel = v[1]; save_soon(); end
    imgui.SameLine();
    v = { cfg.bag_sack ~= false };
    if (imgui.Checkbox('Mog Sack', v)) then cfg.bag_sack = v[1]; save_soon(); end
    imgui.SameLine();
    v = { cfg.bag_case ~= false };
    if (imgui.Checkbox('Mog Case', v)) then cfg.bag_case = v[1]; save_soon(); end
    v = { cfg.bag_home ~= false };
    if (imgui.Checkbox('Mog Safe, Storage and Locker (only inside your Mog House)', v)) then cfg.bag_home = v[1]; save_soon(); end
    imgui.TextColored(K.dim, 'Storage is shared by every character on your account. Rare / Ex materials stay with the character that stored them.');
end

local TABS = {
    { 'Recipes', tab_recipes }, { 'Search', tab_search }, { 'Favorites', tab_favorites }, { 'Guilds', tab_guilds },
    { 'Storage', tab_storage }, { 'Queue', tab_queue }, { 'Bonuses', tab_bonuses }, { 'Settings', tab_settings },
};

local function draw_main()
    ui.open_main[1] = cfg.show_main;
    window_prep('main', 0.94);
    imgui.SetNextWindowSizeConstraints({ 520, 320 }, { 1800, 1400 });
    safe_window('Timeless Artisan', ui.open_main, ImGuiWindowFlags_NoCollapse, function ()
        window_track('main');
        -- header strip: best crafts, rested, queue
        local best = {};
        for i = 1, 8 do if ((ST.skill[i] or 0) > 0) then best[#best + 1] = { i = i, s = ST.skill[i] }; end end
        table.sort(best, function (a, b) return a.s > b.s; end);
        for k = 1, math.min(3, #best) do
            if (k > 1) then imgui.SameLine(); end
            imgui.TextColored(K.gold, ('%s %s'):format(L.CRAFTS[best[k].i].name, L.skill_text(best[k].s)));
        end
        if (#best == 0) then imgui.TextColored(K.muted, ST.ready and 'No crafting skill yet' or 'Connecting to the server...'); end
        if (ST.cp.on) then imgui.SameLine(); imgui.TextColored(K.dim, '|'); imgui.SameLine(); imgui.TextColored(K.green, ('Rested %d'):format(ST.cp.r)); end
        imgui.SameLine(); imgui.TextColored(K.dim, '|'); imgui.SameLine();
        imgui.TextColored(queue_size() > 0 and K.gold or K.muted, ('Queue %d/%d'):format(queue_size(), ST.v.max or L.MAX_QUEUE));
        if (last_recipe() ~= nil) then imgui.SameLine(); repeat_button('main', true); end
        if (not ST.ready and net.asked_at and os.clock() - net.asked_at > 6) then
            imgui.TextColored(K.amber, 'The server isn\'t answering: crafting and storage need the Timeless Artisan server module.');
        end
        if (imgui.BeginTabBar('##tabs')) then
            for _, t in ipairs(TABS) do
                local flags = (ui.tab_req == t[1]) and ImGuiTabItemFlags_SetSelected or 0;
                if (imgui.BeginTabItem(t[1], nil, flags)) then
                    t[2]();
                    imgui.EndTabItem();
                end
            end
            ui.tab_req = nil;
            imgui.EndTabBar();
        end
    end);
    if (not ui.open_main[1]) then cfg.show_main = false; settings.save(); end
end

-- The HUD: a small crafting window (favorites with Craft buttons, Repeat, the queue, storage)
local HUD_FAVS = 8;
local function draw_hud()
    if (not cfg.show_hud) then return; end
    local active = queue_size() > 0;
    if (cfg.hud_auto and not active) then return; end
    if (type(cfg.hud_rect) ~= 'table' and ui.hud_fit == 0 and not ui.hud_fitted) then ui.hud_fit = 3; end
    ui.hud_fitted = true;
    local fitting = ui.hud_fit > 0;
    window_prep('hud', 0.88, fitting);
    if (not fitting) then imgui.SetNextWindowSizeConstraints({ 260, 120 }, { 900, 1200 }); end
    local flags = bit.bor(ImGuiWindowFlags_NoTitleBar, ImGuiWindowFlags_NoFocusOnAppearing, ImGuiWindowFlags_NoNav);
    if (fitting) then flags = bit.bor(flags, ImGuiWindowFlags_AlwaysAutoResize); ui.hud_fit = ui.hud_fit - 1; end
    safe_window('Timeless Artisan HUD', nil, flags, function ()
        window_track('hud');
        heading('Timeless Artisan', K.gold, 'title', 1.05);
        imgui.SameLine();
        imgui.TextColored(active and K.gold or K.muted, ('  Queue %d/%d'):format(queue_size(), ST.v.max or L.MAX_QUEUE));
        if (ST.cp.on and ST.cp.r > 0) then imgui.SameLine(); imgui.TextColored(K.green, ('  Rested %d'):format(ST.cp.r)); tip('Rested synths: a higher skill-up chance on each synth that can skill up.'); end
        if (not ST.ready) then imgui.TextColored(K.amber, 'Connecting to the server...'); end

        -- What's happening now
        if (ST.queue.run and ST.queue.cur > 0) then
            local r = IDX.by_id[ST.queue.cur];
            if (r) then draw_icon(r.result, 16); imgui.SameLine(); end
            imgui.TextColored(K.text, 'Crafting: ' .. (r and r.name or '...'));
            local left = ST.queue.n or 0;
            if (left > 0) then
                local nxt = ST.queue.list[1];
                local nr = nxt and IDX.by_id[nxt.r];
                imgui.TextColored(K.dim, ('%s after this%s'):format(plural(left, 'more craft'), nr and ('  (next: ' .. nr.name .. ')') or ''));
            end
        elseif (active) then
            imgui.TextColored(K.muted, 'Next craft starting...');
        else
            imgui.TextColored(K.dim, 'Not crafting.');
        end
        if (session.made + session.broke > 0) then
            imgui.Text(('Made %d   HQ %d   Broke %d'):format(session.made, session.hq, session.broke));
            tip('This session. Full log: Queue tab.');
        end
        if (session.log[1]) then imgui.TextColored(session.log[1].c, session.log[1].text); end

        -- Quick crafting
        repeat_button('hud', true);
        imgui.SameLine();
        if (button('Stop', active, 'Nothing queued.', true)) then request('cx'); end
        tip('Clear the queue (a synthesis already running finishes).');
        count_slider(150);

        local favs = {};
        for _, id in ipairs(cfg.favorites or {}) do if (IDX.by_id[id]) then favs[#favs + 1] = IDX.by_id[id]; end end
        if (imgui.CollapsingHeader(('Favorites (%d)###hudfavs'):format(#favs), ImGuiTreeNodeFlags_DefaultOpen)) then
            if (#favs == 0) then
                imgui.TextColored(K.dim, 'Add recipes to Favorites to craft them from here.');
            elseif (imgui.BeginTable('##hudfav', 3, ImGuiTableFlags_SizingFixedFit)) then
                imgui.TableSetupColumn('##n', ImGuiTableColumnFlags_WidthStretch);
                imgui.TableSetupColumn('##m');
                imgui.TableSetupColumn('##c');
                for i, r in ipairs(favs) do
                    if (i > HUD_FAVS) then break; end
                    local c = check_of(r);
                    imgui.TableNextRow();
                    imgui.TableNextColumn(); draw_icon(r.result, 16); imgui.SameLine();
                    imgui.PushStyleColor(ImGuiCol_Text, c.ok and K.text or K.muted);
                    if (imgui.Selectable(('%s##hf%d'):format(r.name, r.id), false)) then open_recipe(r.id); end
                    imgui.PopStyleColor();
                    tip('Open the recipe in the window.');
                    imgui.TableNextColumn();
                    imgui.TextColored(c.max > 0 and K.green or K.dim, c.max > 0 and ('x' .. math.min(c.max, 999)) or '-');
                    tip('How many times you can make it (inventory + storage).');
                    imgui.TableNextColumn();
                    local block = craft_block(r);
                    if (button(('Craft##hc%d'):format(r.id), block == nil, block, true)) then craft(r, cfg.craft_count); end
                    if (block == nil) then tip(('Craft %d'):format(math.max(1, math.min(cfg.craft_count or 1, queue_room())))); end
                end
                imgui.EndTable();
                if (#favs > HUD_FAVS) then imgui.TextColored(K.dim, ('+%d more on the Favorites tab'):format(#favs - HUD_FAVS)); end
            end
        end

        -- Storage at a glance
        local kinds, total = 0, 0;
        for _, n in pairs(ST.store) do kinds = kinds + 1; total = total + n; end
        for _, n in pairs(ST.store_own) do kinds = kinds + 1; total = total + n; end
        imgui.TextColored(K.muted, ('Storage: %s'):format(plural(total, 'item')));
        tip(('%s in storage, shared by your characters. Inventory: %s free.'):format(plural(kinds, 'material type'), plural(INV_FREE, 'slot')));
        imgui.SameLine();
        if (button('Deposit all##hud', ST.ready, 'Waiting for the server.', true)) then deposit_all(nil); end
        tip('Put every crafting material from your bags into storage (gear stays).');
        imgui.SameLine();
        local modes = { [0] = 'Auto: off', 'Auto: all', 'Auto: chosen' };
        if (imgui.SmallButton(modes[cfg.auto_mode or 0] .. '##hudauto')) then
            cfg.auto_mode = ((cfg.auto_mode or 0) + 1) % 3;
            net.next_auto = os.clock() + 2;
            save_soon();
        end
        tip('Auto-deposit (click to change): off / every crafting material / only the items ticked on the Storage tab.');

        if (imgui.SmallButton(cfg.show_main and 'Close window' or 'Open window')) then cfg.show_main = not cfg.show_main; settings.save(); end
        imgui.SameLine();
        if (imgui.SmallButton('Hide HUD')) then
            cfg.show_hud = false;
            settings.save();
            msg('HUD hidden. Type /artisan hud to bring it back.');
        end
    end, -1);
end

----------------------------------------------------------------------------
-- Events
----------------------------------------------------------------------------
local function logged_in()
    local player = mm():GetPlayer();
    return player ~= nil and player:GetMainJob() ~= 0 and mm():GetParty():GetMemberServerId(0) ~= 0;
end

ashita.events.register('load', 'artisan_load', function ()
    font_on.enabled, font_on.size = cfg.font ~= false, tonumber(cfg.font_size) or 16;
    if (not UF.load(imgui_raw)) then
        print(('[timelessartisan] Using the default font (%s).'):format(tostring(UF.error)));
    end
    net.hello_at = os.clock() + 1.5;
    if ((tonumber(cfg.hud_v) or 1) < 2) then
        -- 1.4: the HUD became a small crafting window, shown all the time
        cfg.hud_auto, cfg.hud_v, cfg.hud_rect = false, 2, nil;
        ui.hud_fit = 3;
        settings.save();
    end
end);

ashita.events.register('unload', 'artisan_unload', function ()
    settings.save();
end);

ashita.events.register('packet_in', 'artisan_packet_in', function (e)
    if (e.id == 0x000A) then          -- zone in: ask again once the zone has loaded
        net.hello_at = os.clock() + 4;
        ST.queue = { run = false, n = 0, cur = 0, list = {} };
        return;
    end
    if (e.id == 0x0017) then          -- our server's answers: read them and keep them out of the chat log
        local s = e.data_modified or e.data;
        local at = s:find('TA1|', 1, true);
        if (at ~= nil) then
            local line = s:sub(at):match('^[^%z]*');
            local ok, err = pcall(on_server_line, line);
            if (not ok) then print('[timelessartisan] ' .. tostring(err)); end
            e.blocked = true;
        end
        return;
    end
    if (e.id == 0x001E or e.id == 0x001F or e.id == 0x0020) then   -- inventory changed
        if (cfg.auto_mode ~= 0) then net.next_auto = os.clock() + 4; end
        net.bags_dirty = true;
        return;
    end
    if (e.id == 0x0050) then          -- equipment changed: crafting gear changes the chances
        net.next_mods = os.clock() + 1.5;
    end
end);

ashita.events.register('text_in', 'artisan_text_in', function (e)
    local text = e.message_modified or e.message or '';
    if (text:find('TA1|', 1, true)) then e.blocked = true; return; end
    local craft_name, up = text:match('(%a+) skill rises ([%d%.]+) point');
    if (craft_name and up) then
        for _, c in ipairs(L.CRAFTS) do
            if (c.name == craft_name) then
                session.skill[c.name] = (session.skill[c.name] or 0) + (tonumber(up) or 0);
                log(clean_chat(text), K.gold);
                net.next_mods = os.clock() + 1;
            end
        end
    end
end);

ashita.events.register('command', 'artisan_command', function (e)
    local args = e.command:args();
    if (#args == 0) then return; end
    local c = args[1]:lower();
    if (c ~= '/artisan' and c ~= '/tcraft') then return; end
    e.blocked = true;
    local sub = (args[2] or ''):lower();
    if (sub == '') then
        cfg.show_main = not cfg.show_main;
        if (cfg.show_main) then request('st'); request('md'); end
    elseif (sub == 'hud' or sub == 'show' or sub == 'hide') then
        local v = (args[3] or ''):lower();
        if (sub == 'show' or v == 'on') then cfg.show_hud = true;
        elseif (sub == 'hide' or v == 'off') then cfg.show_hud = false;
        else cfg.show_hud = not cfg.show_hud; end
        msg(cfg.show_hud and (cfg.hud_auto and 'HUD on. It shows while crafts are queued (Settings tab to change).' or 'HUD on.') or 'HUD hidden. Type /artisan hud to bring it back.');
    elseif (sub == 'search') then
        ui.search[1] = table.concat(args, ' ', 3);
        ui.sel_recipe = nil;
        ui.tab_req = 'Search';
        cfg.show_main = true;
    elseif (sub == 'deposit') then
        deposit_all(nil);
        msg('Putting every crafting material from your bags into storage.');
    elseif (sub == 'stop') then
        request('cx');
    elseif (sub == 'guilds' or sub == 'guild') then
        ui.tab_req = 'Guilds';
        cfg.show_main = true;
        request('gd');
    elseif (sub == 'refresh') then
        hello();
    elseif (sub == 'opacity') then
        local which, v = (args[3] or ''):lower(), tonumber(args[4]);
        local key = (which == 'window' or which == 'main') and 'main' or ((which == 'hud') and 'hud' or nil);
        if (key ~= nil and v ~= nil) then
            cfg[key .. '_alpha'] = math.max(20, math.min(100, v)) / 100;
            msg(('%s opacity %d%%'):format(key == 'main' and 'Window' or 'HUD', math.floor(cfg[key .. '_alpha'] * 100 + 0.5)));
        else
            msg('Change: /artisan opacity window|hud <20-100>');
        end
    else
        msg('/artisan  - open or close the crafting window');
        msg('/artisan search <text>  - find a recipe by its result or an ingredient');
        msg('/artisan guilds  - today\'s guild point items');
        msg('/artisan deposit  - put every crafting material from your bags into storage');
        msg('/artisan stop  - clear the craft queue');
        msg('/artisan hud  - show or hide the HUD');
        msg('/artisan opacity window|hud <20-100>  - background opacity');
        msg('/artisan refresh  - ask the server for everything again');
    end
    settings.save();
end);

local err_shown = false;
ashita.events.register('d3d_present', 'artisan_present', function ()
    if (not logged_in()) then return; end
    local now = os.clock();
    if (net.hello_at and now >= net.hello_at) then net.hello_at = nil; hello(); end
    flush_requests();
    if (net.next_mods > 0 and now >= net.next_mods) then net.next_mods = 0; request('md'); end
    local visible = cfg.show_main or (cfg.show_hud and queue_size() > 0);
    if (net.bags_dirty or now >= (net.next_scan or 0)) then
        net.bags_dirty = false;
        net.next_scan = now + (visible and 1 or 3);
        local ok, err = pcall(scan_bags);
        if (ok) then pcall(kept_tick); end
        if (not ok and not err_shown) then err_shown = true; msg('bag scan error: ' .. tostring(err)); end
    end
    if (cfg.show_main and now >= (net.next_refresh or 0)) then
        net.next_refresh = now + 20;   -- chances follow gear / Workshop / rested changes
        if (ST.ready) then request('md'); end
    end
    pcall(auto_deposit_tick, now);
    if (ui.save_at ~= nil and now >= ui.save_at) then ui.save_at = nil; settings.save(); end
    UF.capture_default(imgui_raw);
    push_theme();
    local ok, err = pcall(function ()
        draw_hud();
        if (cfg.show_main) then draw_main(); end
    end);
    pop_theme();
    if (not ok and not err_shown) then err_shown = true; msg('draw error: ' .. tostring(err)); end
end);
