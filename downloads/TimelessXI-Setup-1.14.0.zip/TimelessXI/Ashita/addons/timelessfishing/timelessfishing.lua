--[[
* Timeless Fishing - bar mini-game for Timeless XI (Ashita v4)
*
* Replaces FFXI's arrow fishing mini-game with a precision bar game: a
* horizontal bar in the middle of the screen. Keep the hourglass inside
* your catch zone until the catch meter fills. Both start in the center.
* The fish is shown with its own inventory icon (hourglass if unknown).
* Monsters are fought the same way, shown as a pulsing, flashing red "!". Items and chests skip the bar: after the normal "something caught
* the hook" text, a box shows the item's icon and name: press ENTER to reel it
* in or ESC to release it.
*
*   LEFT / RIGHT movement keys (A / D, arrow keys or numpad 4 / 6) steer
*   your zone; let go and it drifts back to the center line. Your rod pulls
*   against the fish (fish on the right -> rod held left, and the other way
*   round; middle 10% = neutral). The keys don't move your character while you fight.
*   ESCAPE gives up on any catch (you keep your rod, the bait is spent).
*
* PERFECT catch = the fish never left your bar (after the first half second).
* On a fish above your skill it gives a 75% skill-up chance; on a fish at or below
* your skill it lands one extra fish.
*
* Works together with the server module modules/timeless_fishing on the
* Timeless XI server, which refuses casts from players without this add-on.
* The add-on says hello on load and after every zone-in (and again whenever
* the server answers a cast with "Please load the timelessfishing add-on").
* On any other server (or if the server doesn't send the new settings) the
* native arrow game plays as usual.
*
* Commands:
*   /tfish                    status
*   /tfish practice [d] [b] [monster]   practice round (no fish, no packets);
*                             d = difficulty 0-100, b = mixed|smooth|sinker|floater|dart
*   /tfish pos <x> <y>        move the panel (top-left corner, pixels; -1 -1 = centered)
*   /tfish scale <n>          panel size, e.g. 1.25
*   /tfish font [on|off]      the website's font (Inter) on or off
--]]

addon.name    = 'timelessfishing';
addon.author  = 'Timeless XI';
addon.version = '2.16';
addon.desc    = 'Stardew-style precision fishing mini-game for Timeless XI.';
addon.link    = 'https://timelessxi.gg';

require('common');
local chat     = require('chat');
local imgui    = require('imgui');
local d3d8     = require('d3d8');
local ffi      = require('ffi');
local settings = require('settings');

local defaults = T{ x = -1, y = -1, scale = 1.0, font = true };
local cfg = settings.load(defaults);

-- Must match modules/timeless_fishing/cpp/timeless_fishing.cpp
local MAGIC       = 0x5854;   -- layout v2 (no item id)
local MAGIC_V3    = 0x5855;   -- layout v3: fill / drain as u8 at 0x0C / 0x0D, catch item id u16 at 0x0E
local HELLO_PARA  = 10;
local METER_START = 0.30;

local BEHAVIORS = { [0] = 'mixed', 'smooth', 'sinker', 'floater', 'dart' };

local POSE_CENTER, POSE_LEFT, POSE_RIGHT = 6, 7, 8;   -- 0x110 mode 5 para: rod pose reports

-- Steering keys. DirectInput (what FFXI reads for movement) and window-message codes.
local DIK_LEFT_KEYS  = { 0x1E, 0xCB, 0x4B };   -- A, Left arrow, Numpad 4
local DIK_RIGHT_KEYS = { 0x20, 0xCD, 0x4D };   -- D, Right arrow, Numpad 6
local DIK_ESCAPE     = 0x01;
local DIK_ENTER_KEYS = { 0x1C, 0x9C };          -- Enter, Numpad Enter
local VK_LEFT_KEYS   = { [0x41] = true, [0x25] = true, [0x64] = true };   -- A, Left, Numpad 4
local VK_RIGHT_KEYS  = { [0x44] = true, [0x27] = true, [0x66] = true };   -- D, Right, Numpad 6
local VK_ESCAPE      = 0x1B;
local VK_RETURN      = 0x0D;
local STEER_DIK = {};
for _, k in ipairs(DIK_LEFT_KEYS) do STEER_DIK[k] = true; end
for _, k in ipairs(DIK_RIGHT_KEYS) do STEER_DIK[k] = true; end

-- Catch-zone physics (track = 0..1, center 0.5).
local ZONE_ACCEL  = 2.6;   -- while a steering key is held
local ZONE_SPRING = 6.0;   -- pull back toward the center when no key is held
local ZONE_DAMP   = 3.2;
local ZONE_VMAX   = 1.4;

----------------------------------------------------------------------------
-- State
----------------------------------------------------------------------------
local game = nil;          -- current round (see new_round)
local pending = nil;       -- item / chest on the line, waiting for ENTER (reel in) or ESC (release)
local hello_at = nil;      -- os.clock() time to send the hello packet
local release_at = nil;    -- os.clock() time to send our release packet
local released = false;
local input = { left = false, right = false, esc = false, enter = false };
local pose_sent, pose_sent_at = POSE_CENTER, 0;
local last_clock = os.clock();
debug_lastanim = nil;
local debug = false;  -- /tfish debug toggles; prints fishing packets to chat

local function dbg(fmt, ...)
    if (debug) then print(chat.header(addon.name):append(chat.message('[dbg] ' .. fmt:format(...)))); end
end

----------------------------------------------------------------------------
-- Packets
----------------------------------------------------------------------------
local function me()
    local party = AshitaCore:GetMemoryManager():GetParty();
    return party:GetMemberServerId(0), party:GetMemberTargetIndex(0);
end

-- 0x110: header, UniqueNo u32, para i32, ActIndex u16, mode i8, pad u8, para2 i32 (20 bytes)
local function send_fishing(mode, para, para2)
    local id, index = me();
    if (id == nil or id == 0) then return false; end
    local p = struct.pack('<BBHIiHbBi', 0x10, 0x0B, 0, id, para or 0, index, mode, 0, para2 or 0):totable();
    AshitaCore:GetPacketManager():AddOutgoingPacket(0x110, p);
    return true;
end

local function send_hello()
    send_fishing(5, HELLO_PARA, 0);
end

----------------------------------------------------------------------------
-- The round
----------------------------------------------------------------------------
local function new_round(p)
    local d = math.max(0, math.min(100, p.difficulty));
    local beh = p.behavior or 0;
    local g = T{
        practice   = p.practice or false,
        kind       = p.kind or 0,
        behavior   = beh,
        d          = d,
        bar        = p.bar,
        fill       = p.fill,
        drain      = p.drain,
        time_limit = p.time_limit or 60,
        legendary  = p.legendary or false,
        monster    = p.monster or false,
        special    = p.special or 0,
        item       = p.item or 0,
        count      = p.count or 1,
        t          = 0,
        meter      = METER_START,
        perfect    = true,
        warned     = false,
        -- catch zone: its center, 0..1 (0.5 = the center line)
        bar_x      = 0.5,
        bar_v      = 0,
        -- fish: center, 0..1; starts on the center line too
        fish_x     = 0.5,
        fish_v     = 0,
        target     = 0.5,
        done       = nil,   -- 'win' | 'lose' | 'giveup'
        done_t     = 0,
        inside     = false,
    };
    -- Movement tuning by difficulty (same idea as Stardew: higher = faster, jumpier).
    g.retarget = 0.35 + 0.025 * d;
    g.amp      = math.min(0.9, 0.15 + 0.006 * d);
    g.k        = 1.2 + 0.03 * d;
    g.accel    = 6 + 0.06 * d;
    if (beh == 1) then g.k = g.k * 0.6; g.retarget = g.retarget * 0.6; g.accel = 3; end
    if (beh == 4) then g.amp = math.min(0.95, g.amp * 1.4); g.retarget = g.retarget * 1.5; end
    return g;
end

local function finish(g, result)
    if (g.done ~= nil) then return; end
    g.done = result;
    g.done_t = g.t;
    if (g.practice) then
        local msg = (result == 'win') and (g.perfect and 'Perfect catch!' or 'Caught!') or 'It got away.';
        print(chat.header(addon.name):append(chat.message(('Practice (difficulty %d, %s%s): %s  %.1fs'):format(g.d, BEHAVIORS[g.behavior], g.monster and ', monster' or '', msg, g.t))));
        return;
    end
    local para = 300;                       -- "You lost your catch."
    if (result == 'win') then para = g.perfect and 1 or 0; end   -- 1 = Perfect (server: skill-up / +1 fish)
    if (result == 'giveup') then para = 200; end
    send_fishing(3, para, g.special);
    released = false;
    release_at = os.clock() + 3.0;
end

-- One physics step. dir = -1 steering left, 1 steering right, 0 no key.
local function step(g, dt, dir)
    g.t = g.t + dt;
    if (g.done ~= nil) then return; end

    -- Catch zone: pushed by the keys, springs back to the center when let go.
    local a;
    if (dir ~= 0) then
        a = dir * ZONE_ACCEL;
        if (g.bar_v * dir < 0) then a = a * 1.5; end                    -- turning around is snappier
    else
        a = -ZONE_SPRING * (g.bar_x - 0.5) - ZONE_DAMP * g.bar_v;
    end
    g.bar_v = math.max(-ZONE_VMAX, math.min(ZONE_VMAX, g.bar_v + a * dt));
    g.bar_x = g.bar_x + g.bar_v * dt;
    local half = g.bar / 2;
    if (g.bar_x < half) then g.bar_x = half; g.bar_v = 0; end
    if (g.bar_x > 1 - half) then g.bar_x = 1 - half; g.bar_v = 0; end

    -- Fish (same moves as before, now left / right).
    if (math.random() < g.retarget * dt) then
        local spread = (math.random() * 2 - 1) * g.amp;
        if (g.behavior == 2) then spread = spread - 0.25 * g.amp; end   -- sinker pulls left
        if (g.behavior == 3) then spread = spread + 0.25 * g.amp; end   -- floater pulls right
        g.target = math.max(0.03, math.min(0.97, g.fish_x + spread));
    end
    local fdir = g.target - g.fish_x;
    local k = g.k;
    if (g.behavior == 2) then k = (fdir < 0) and k * 1.8 or k * 0.75; end
    if (g.behavior == 3) then k = (fdir > 0) and k * 1.8 or k * 0.75; end
    local want = fdir * k;
    g.fish_v = g.fish_v + (want - g.fish_v) * math.min(1, g.accel * dt);
    if (g.behavior == 4 and math.random() < (0.2 + 0.01 * g.d) * dt) then
        g.fish_v = g.fish_v + (math.random() * 2 - 1) * (0.6 + 0.01 * g.d);   -- dart burst
    end
    g.fish_x = g.fish_x + g.fish_v * dt;
    if (g.fish_x < 0.02) then g.fish_x = 0.02; g.fish_v = math.abs(g.fish_v) * 0.5; end
    if (g.fish_x > 0.98) then g.fish_x = 0.98; g.fish_v = -math.abs(g.fish_v) * 0.5; end

    -- Catch meter.
    g.inside = math.abs(g.fish_x - g.bar_x) <= half;
    if (g.inside) then
        g.meter = g.meter + g.fill * dt;
    else
        g.meter = g.meter - g.drain * dt;
        if (g.t > 0.5) then g.perfect = false; end
    end

    if (g.meter >= 1) then g.meter = 1; finish(g, 'win'); return; end
    if (g.meter <= 0) then g.meter = 0; finish(g, 'lose'); return; end

    if (not g.practice) then
        local left = g.time_limit - g.t;
        if (left <= 10 and not g.warned) then
            g.warned = true;
            send_fishing(5, 5, 0);   -- "You don't know how much longer you can keep this one on the line..."
        end
        if (left <= 0) then finish(g, 'lose'); end
    end
end

----------------------------------------------------------------------------
-- Drawing
----------------------------------------------------------------------------
-- ImGui colors are 0xAABBGGRR (built with arithmetic so they stay positive numbers)
local function col(r, g, b, a)
    return math.floor((a or 1) * 255 + 0.5) * 16777216 + b * 65536 + g * 256 + r;
end

local C = {
    panel   = col(10, 11, 18, 0.92),
    edge    = col(40, 48, 64, 1),
    track   = col(17, 20, 29, 1),
    water1  = col(16, 26, 44, 1),
    water2  = col(10, 13, 22, 1),
    bar     = col(143, 178, 230, 0.30),
    barIn   = col(143, 178, 230, 0.48),
    barEdge = col(214, 225, 240, 0.85),
    silver  = col(214, 220, 232, 1),
    crystal = col(143, 178, 230, 1),
    glow    = col(61, 95, 148, 0.45),
    sand    = col(152, 163, 184, 1),
    text    = col(230, 236, 245, 1),
    muted   = col(152, 163, 184, 1),
    gold    = col(232, 200, 120, 1),
    red     = col(214, 48, 48, 1),
    white   = col(245, 245, 250, 1),
    dark    = col(14, 10, 18, 1),
    meterLo = col(61, 95, 148, 1),
    meterHi = col(214, 225, 240, 1),
};

-- Textures: the inventory icon of the fish (or item) on the line.
local tex = { items = {}, item_count = 0 };

local function tex_id(t)
    return tonumber(ffi.cast('uint32_t', t));
end

-- The same icon the inventory shows (from the client's own item data).
local function item_texture(id)
    if (id == nil or id <= 0 or id >= 65535) then return nil; end
    local cached = tex.items[id];
    if (cached ~= nil) then return cached ~= false and cached or nil; end
    if (tex.item_count > 64) then tex.items = {}; tex.item_count = 0; end
    tex.item_count = tex.item_count + 1;
    local item = AshitaCore:GetResourceManager():GetItemById(id);
    if (item == nil or item.ImageSize == nil or item.ImageSize == 0) then tex.items[id] = false; return nil; end
    local ptr = ffi.new('IDirect3DTexture8*[1]');
    if (ffi.C.D3DXCreateTextureFromFileInMemoryEx(d3d8.get_device(), item.Bitmap, item.ImageSize, 0xFFFFFFFF, 0xFFFFFFFF, 1, 0,
            ffi.C.D3DFMT_A8R8G8B8, ffi.C.D3DPOOL_MANAGED, ffi.C.D3DX_DEFAULT, ffi.C.D3DX_DEFAULT, 0xFF000000, nil, nil, ptr) ~= ffi.C.S_OK) then
        tex.items[id] = false;
        return nil;
    end
    local t = d3d8.gc_safe_release(ffi.cast('IDirect3DTexture8*', ptr[0]));
    tex.items[id] = t;
    return t;
end

-- The Timeless hourglass: stepped caps, fine glass, star crystal on top, sand below.
local function draw_hourglass(dl, cx, cy, h, alpha)
    local w  = h * 0.62;
    local t, b = cy - h / 2, cy + h / 2;
    local lw = math.max(1, h / 16);
    -- glow
    dl:AddCircleFilled({ cx, cy }, h * 0.55, C.glow, 24);
    -- caps (main bar + inner step)
    dl:AddRectFilled({ cx - w / 2, t }, { cx + w / 2, t + h * 0.07 }, C.silver, 1);
    dl:AddRectFilled({ cx - w * 0.42, t + h * 0.07 }, { cx + w * 0.42, t + h * 0.11 }, C.silver, 0);
    dl:AddRectFilled({ cx - w / 2, b - h * 0.07 }, { cx + w / 2, b }, C.silver, 1);
    dl:AddRectFilled({ cx - w * 0.42, b - h * 0.11 }, { cx + w * 0.42, b - h * 0.07 }, C.silver, 0);
    -- glass
    local gt, gb, gx, nx = t + h * 0.11, b - h * 0.11, w * 0.38, w * 0.05;
    dl:AddBezierCubic({ cx - gx, gt }, { cx - gx, cy - h * 0.18 }, { cx - nx * 1.6, cy - h * 0.08 }, { cx - nx, cy }, C.silver, lw, 12);
    dl:AddBezierCubic({ cx - nx, cy }, { cx - nx * 1.6, cy + h * 0.08 }, { cx - gx, cy + h * 0.18 }, { cx - gx, gb }, C.silver, lw, 12);
    dl:AddBezierCubic({ cx + gx, gt }, { cx + gx, cy - h * 0.18 }, { cx + nx * 1.6, cy - h * 0.08 }, { cx + nx, cy }, C.silver, lw, 12);
    dl:AddBezierCubic({ cx + nx, cy }, { cx + nx * 1.6, cy + h * 0.08 }, { cx + gx, cy + h * 0.18 }, { cx + gx, gb }, C.silver, lw, 12);
    -- sand pile
    dl:AddTriangleFilled({ cx - gx * 0.85, gb - 1 }, { cx, gb - h * 0.16 }, { cx + gx * 0.85, gb - 1 }, C.sand);
    -- falling sand
    dl:AddLine({ cx, cy }, { cx, gb - h * 0.16 }, C.sand, math.max(1, lw * 0.6));
    -- star crystal (diamond) in the top bulb
    local sy, sr = cy - h * 0.2, h * 0.11;
    dl:AddQuadFilled({ cx, sy - sr * 1.3 }, { cx + sr * 0.75, sy }, { cx, sy + sr * 1.3 }, { cx - sr * 0.75, sy }, C.crystal);
    dl:AddLine({ cx, sy - sr * 1.3 }, { cx, sy + sr * 1.3 }, C.silver, 1);
end

-- Red pulsing, flashing "!" (a monster on the line).
local function draw_alert(dl, cx, cy, size, t)
    local pulse = 0.5 + 0.5 * math.sin(t * math.pi * 3);  -- 1.5 pulses per second
    local rr = size * (0.9 + 0.15 * pulse);
    dl:AddCircleFilled({ cx, cy }, rr * (1.35 + 0.35 * pulse), col(214, 48, 48, 0.18 + 0.22 * pulse), 24);
    dl:AddCircleFilled({ cx, cy }, rr, col(214 + math.floor(41 * pulse), 48 + math.floor(42 * pulse), 48 + math.floor(26 * pulse), 1), 24);
    dl:AddCircle({ cx, cy }, rr, col(255, 190, 190, 0.9), 24, 1.5);
    local w = rr * 0.26;
    dl:AddRectFilled({ cx - w / 2, cy - rr * 0.62 }, { cx + w / 2, cy + rr * 0.18 }, C.white, w / 2);
    dl:AddCircleFilled({ cx, cy + rr * 0.46 }, w * 0.62, C.white, 10);
end

local function lerp_col(a, b, f)
    local out, mul = 0, 1;
    for _ = 1, 4 do
        local ca, cb = a % 256, b % 256;
        out = out + math.floor(ca + (cb - ca) * f + 0.5) * mul;
        a, b, mul = math.floor(a / 256), math.floor(b / 256), mul * 256;
    end
    return out;
end

local function screen()
    local res, vp = d3d8.get_device():GetViewport();
    if (res == 0 and vp ~= nil) then return vp.Width, vp.Height; end
    return 1920, 1080;
end

-- Fonts: the website's Inter (text); titles in the shared title face (default Raleway SemiBold), shared with timelessangler.
local UF = require('timeless.ui_fonts');
local function fonts_ok() return UF.loaded and cfg.font ~= false; end

-- Run fn with a font role selected the safe way: PushFont(font, size), then plain AddText / CalcTextSize,
-- then PopFont. (2.11 called AddText(font, ...) / ImFont:CalcTextSizeA directly: that crashed the client's
-- d3d_present with an access violation and froze the round mid-fight.)
local function with_font(role, size, fn)
    if (not fonts_ok() or role == nil) then return fn(); end
    imgui.PushFont(UF.get(role), UF.size(role, size));
    local ok, r = pcall(fn);
    imgui.PopFont();
    if (not ok) then error(r, 0); end
    return r;
end

-- Draw a text in a font role (body / medium / serif_bold ...) at a pixel size; default font if the fonts aren't in.
local function ftext(dl, role, size, pos, colour, text)
    with_font(role, size, function () dl:AddText(pos, colour, text); end);
end

-- Width of a text as ftext draws it (measured, so any font / size fits the panel).
local function text_w(text, role, size)
    local w = with_font(role, size, function () return imgui.CalcTextSize(text); end);
    if (type(w) == 'number') then return w; end
    return #text * 7;
end

local function draw(g)
    local s = cfg.scale or 1.0;
    local W, H = 600 * s, 112 * s;
    local sw, sh = screen();
    local x0 = (cfg.x or -1) >= 0 and cfg.x or (sw * 0.5 - W * 0.5);
    local y0 = (cfg.y or -1) >= 0 and cfg.y or (sh * 0.5 - H * 0.5);
    local dl = imgui.GetForegroundDrawList();

    -- panel
    dl:AddRectFilled({ x0, y0 }, { x0 + W, y0 + H }, C.panel, 10 * s);
    dl:AddRect({ x0, y0 }, { x0 + W, y0 + H }, C.edge, 10 * s, 0, 1.5);

    -- track (horizontal water band)
    local tx, ty, tw, th = x0 + 18 * s, y0 + 26 * s, W - 36 * s, 50 * s;
    dl:AddRectFilledMultiColor({ tx, ty }, { tx + tw, ty + th }, C.water1, C.water1, C.water2, C.water2);
    dl:AddRect({ tx, ty }, { tx + tw, ty + th }, C.edge, 4 * s, 0, 1);

    -- catch zone
    local bx0 = tx + tw * (g.bar_x - g.bar / 2);
    local bx1 = tx + tw * (g.bar_x + g.bar / 2);
    dl:AddRectFilled({ bx0, ty + 2 * s }, { bx1, ty + th - 2 * s }, g.inside and C.barIn or C.bar, 4 * s);
    dl:AddRect({ bx0, ty + 2 * s }, { bx1, ty + th - 2 * s }, C.barEdge, 4 * s, 0, 1.2);

    -- center line (the zone's resting point)
    local cxl = tx + tw * 0.5;
    dl:AddLine({ cxl, ty - 4 * s }, { cxl, ty + th + 4 * s }, C.white, math.max(1, 1.2 * s));

    -- the fish's inventory icon (hourglass fallback) or a pulsing red "!" (a monster)
    local fx = tx + tw * g.fish_x;
    local fy = ty + th / 2;
    local hh = 34 * s;
    if (g.monster) then
        draw_alert(dl, fx, fy, hh * 0.45, g.t);
    else
        local icon = item_texture(g.item);
        if (icon ~= nil) then
            local r = hh * 0.5;
            dl:AddCircleFilled({ fx, fy }, hh * 0.62, C.glow, 24);
            dl:AddImage(tex_id(icon), { fx - r, fy - r }, { fx + r, fy + r });
        else
            draw_hourglass(dl, fx, fy, hh, 1);
        end
    end
    if (g.legendary) then
        dl:AddCircle({ fx, fy }, hh * 0.62, C.gold, 24, 1.5);
    end

    -- catch meter (fills left to right under the track)
    local my, mh = ty + th + 10 * s, 8 * s;
    dl:AddRectFilled({ tx, my }, { tx + tw, my + mh }, C.track, 4 * s);
    dl:AddRectFilled({ tx + 1 * s, my + 1 * s }, { tx + 1 * s + (tw - 2 * s) * g.meter, my + mh - 1 * s }, lerp_col(C.meterLo, C.meterHi, g.meter), 3 * s);
    dl:AddRect({ tx, my }, { tx + tw, my + mh }, C.edge, 4 * s, 0, 1);

    -- texts
    local tlx = x0 + 18 * s;
    ftext(dl, 'title', 15 * s, { tlx, y0 + 5 * s }, g.monster and C.red or C.muted, g.monster and 'Monster!' or (g.practice and 'Practice' or 'Reel it in'));
    local hint = 'LEFT / RIGHT: steer   ESC: give up';
    if (g.done == 'win') then hint = g.perfect and 'Perfect!' or 'Caught!'; end
    if (g.done == 'lose') then hint = 'It got away...'; end
    if (g.done == 'giveup') then hint = 'You give up.'; end
    ftext(dl, 'body', 14 * s, { x0 + W - 18 * s - text_w(hint, 'body', 14 * s), y0 + 6 * s }, (g.done == 'win' and g.perfect) and C.gold or C.text, hint);
end

-- "Something is on the line!" box for items and chests: inventory icon in a framed slot (hourglass for
-- chests), the item's name, ENTER / ESC keycaps and a time-left bar.
local function keycap(dl, x, y, s, label)
    local w = text_w(label, 'medium', 13 * s) + 14 * s;
    local h = 18 * s;
    dl:AddRectFilled({ x, y }, { x + w, y + h }, col(34, 42, 60, 1), 4 * s);
    dl:AddRectFilled({ x, y + h - 3 * s }, { x + w, y + h }, col(70, 82, 112, 1), 4 * s);
    dl:AddRect({ x, y }, { x + w, y + h }, col(90, 103, 136, 1), 4 * s, 0, 1);
    ftext(dl, 'medium', 13 * s, { x + 7 * s, y + 1 * s }, C.text, label);
    return x + w;
end

local function draw_pending(p, now, left)
    local sw, sh = screen();
    local s = cfg.scale or 1.0;
    local W, H = 360 * s, 80 * s;
    local x0, y0 = sw * 0.5 - W * 0.5, sh * 0.5 - H * 0.5;
    local dl = imgui.GetForegroundDrawList();
    local t = now - p.start;
    dl:AddRectFilled({ x0, y0 }, { x0 + W, y0 + H }, C.panel, 10 * s);
    dl:AddRect({ x0, y0 }, { x0 + W, y0 + H }, C.edge, 10 * s, 0, 1.5);

    -- icon slot with a soft pulsing gold glow
    local pulse = 0.5 + 0.5 * math.sin(t * math.pi * 1.25);
    local sx, sy, ss = x0 + 14 * s, y0 + 12 * s, 52 * s;
    dl:AddRectFilled({ sx - 3 * s, sy - 3 * s }, { sx + ss + 3 * s, sy + ss + 3 * s }, col(232, 195, 90, 0.10 + 0.25 * pulse), 10 * s);
    dl:AddRectFilled({ sx, sy }, { sx + ss, sy + ss }, col(14, 20, 32, 1), 8 * s);
    dl:AddRect({ sx, sy }, { sx + ss, sy + ss }, C.gold, 8 * s, 0, 1.5);
    local cx, cy = sx + ss / 2, sy + ss / 2 - 2 * s * math.sin(t * math.pi * 1.25);
    local icon = item_texture(p.item);
    if (icon ~= nil) then
        local r = 20 * s;
        dl:AddImage(tex_id(icon), { cx - r, cy - r }, { cx + r, cy + r });
    else
        draw_hourglass(dl, cx, cy, 36 * s, 1);
    end

    -- text
    local tx = sx + ss + 14 * s;
    ftext(dl, 'body', 14 * s, { tx, y0 + 9 * s }, C.muted, 'Something is on the line!');
    if (p.name ~= nil) then
        if (fonts_ok()) then
            ftext(dl, 'title', 16 * s, { tx, y0 + 26 * s }, C.gold, p.name);
        else
            dl:AddText(imgui.GetFont(), imgui.GetFontSize() * 1.2, { tx, y0 + 27 * s }, C.gold, p.name);   -- as in 2.9
        end
    end
    local kx = keycap(dl, tx, y0 + 50 * s, s, 'ENTER');
    ftext(dl, 'body', 14 * s, { kx + 6 * s, y0 + 50 * s }, C.text, 'Reel in');
    kx = keycap(dl, kx + 6 * s + text_w('Reel in', 'body', 14 * s) + 18 * s, y0 + 50 * s, s, 'ESC');
    ftext(dl, 'body', 14 * s, { kx + 6 * s, y0 + 50 * s }, C.text, 'Release');

    -- time left: blue, then amber, then red
    local f = math.max(0, math.min(1, left / p.time_limit));
    local bc = f > 0.3 and col(127, 196, 232, 1) or (f > 0.15 and col(232, 176, 74, 1) or C.red);
    dl:AddRectFilled({ x0 + 2 * s, y0 + H - 5 * s }, { x0 + W - 2 * s, y0 + H - 2 * s }, col(14, 20, 32, 1), 1);
    dl:AddRectFilled({ x0 + 2 * s, y0 + H - 5 * s }, { x0 + 2 * s + (W - 4 * s) * f, y0 + H - 2 * s }, bc, 1);
end

----------------------------------------------------------------------------
-- Events
----------------------------------------------------------------------------
ashita.events.register('load', 'tfish_load', function ()
    if (not UF.load(imgui)) then
        print(chat.header(addon.name):append(chat.message('Using the default font (' .. tostring(UF.error) .. ').')));
    end
    math.randomseed(os.time());
    hello_at = os.clock() + 2.0;
end);

ashita.events.register('packet_in', 'tfish_packet_in', function (e)
    if (debug) then
        if (e.id == 0x0115) then
            local m, k = struct.unpack('<HB', e.data_modified, 0x04 + 1);
            dbg('IN  0x115 hook: magic=%04X kind=%d', m, k);
        elseif (e.id == 0x0052) then
            dbg('IN  0x052 release mode=%d', struct.unpack('B', e.data_modified, 0x04 + 1));
        elseif (e.id == 0x0037) then
            local a = struct.unpack('B', e.data_modified, 0x30 + 1);
            if (a ~= (debug_lastanim or -1)) then debug_lastanim = a; dbg('IN  0x037 animation=%d', a); end
        elseif (e.id == 0x0036 or e.id == 0x002A or e.id == 0x0027) then
            dbg('IN  0x%03X message', e.id);
        end
    end

    -- The server refused a cast because it doesn't know about this add-on (e.g. it was restarted):
    -- say hello now so the next cast works.
    if (e.id == 0x0017 and e.data_modified:find('timelessfishing add%-on', 1) ~= nil) then
        dbg('server asked for the add-on: sending hello');
        send_hello();
    end
    -- Zone in: say hello again (the server forgets add-on players on zone-out).
    if (e.id == 0x000A) then
        hello_at = os.clock() + 3.0;
        game = nil;
        pending = nil;
        return;
    end

    if (e.id ~= 0x0115) then return; end
    local magic = struct.unpack('<H', e.data_modified, 0x04 + 1);
    if (magic ~= MAGIC and magic ~= MAGIC_V3) then return; end     -- server without Timeless Fishing: native game

    e.blocked = true;                        -- never open the arrow game
    local kind, beh = struct.unpack('<BB', e.data_modified, 0x06 + 1);
    local d, bar, fill, drain, tl = struct.unpack('<HHHHH', e.data_modified, 0x08 + 1);
    local item = 0;
    if (magic == MAGIC_V3) then
        fill, drain = struct.unpack('<BB', e.data_modified, 0x0C + 1);
        item = struct.unpack('<H', e.data_modified, 0x0E + 1);
    end
    local flags, count = struct.unpack('<BB', e.data_modified, 0x12 + 1);
    local special = struct.unpack('<I', e.data_modified, 0x14 + 1);

    if (kind == 1) then
        -- Items, chests: no bar. The game has already shown its hook text; wait for ENTER / ESC.
        local name = nil;
        if (bit.band(flags, 8) ~= 0) then
            name = 'Treasure Chest';
        elseif (item > 0) then
            local res = AshitaCore:GetResourceManager():GetItemById(item);
            if (res ~= nil and res.Name ~= nil) then name = res.Name[1]; end
        end
        pending = { special = special, start = os.clock(), time_limit = (tl > 0) and tl or 60, warned = false, item = item, name = name };
        return;
    end

    pose_sent, pose_sent_at = POSE_CENTER, 0;
    game = new_round({
        difficulty = d, behavior = beh, bar = bar / 1000, fill = fill / 1000, drain = drain / 1000,
        time_limit = tl, legendary = bit.band(flags, 1) ~= 0, monster = bit.band(flags, 4) ~= 0,
        special = special, count = count, item = item,
    });
end);

ashita.events.register('packet_out', 'tfish_packet_out', function (e)
    -- Casting a line (action 0x0E). Never blocked: the hello was already sent on zone-in.
    if (e.id == 0x001A) then
        local action = struct.unpack('<H', e.data_modified, 0x0A + 1);
        if (action == 0x0E) then
            dbg('OUT 0x01A cast');
        end
        return;
    end

    if (e.id ~= 0x0110 and e.id ~= 0x0066) then return; end
    local mode = struct.unpack('b', e.data_modified, 0x0E + 1);
    dbg('OUT 0x%03X mode=%d para=%d injected=%s round=%s', e.id, mode, struct.unpack('<i', e.data_modified, 0x08 + 1), tostring(e.injected), game and 'yes' or (pending and 'instant' or 'no'));
    if (e.injected) then return; end
    if (mode == 4) then released = true; return; end
    -- While our round runs, the client's own end/timeout reports are not wanted.
    if (((game ~= nil and not game.practice and game.done == nil) or pending ~= nil) and (mode == 3 or mode == 5)) then
        e.blocked = true;
    end
end);

local function round_active()
    return game ~= nil and game.done == nil;
end

local function reel_in()
    if (pending == nil) then return; end
    send_fishing(3, 0, pending.special);         -- caught
    pending = nil;
    released = false;
    release_at = os.clock() + 3.0;
end

local function give_up()
    if (pending ~= nil) then
        send_fishing(3, 200, pending.special);   -- "You give up."
        pending = nil;
        released = false;
        release_at = os.clock() + 3.0;
    elseif (round_active()) then
        if (game.practice) then game = nil; else finish(game, 'giveup'); end
    end
end

-- DirectInput keyboard state (what FFXI reads for movement): read the steering keys and
-- hide them (and ESC) from the game while a round runs, so the character doesn't turn.
ashita.events.register('key_state', 'tfish_key_state', function (e)
    if (not round_active() and pending == nil) then
        input.left, input.right, input.esc = false, false, false;
        return;
    end
    local ptr = ffi.cast('uint8_t*', e.data_raw);
    if (ptr == nil) then return; end
    local l, r = false, false;
    for _, k in ipairs(DIK_LEFT_KEYS) do if (bit.band(ptr[k], 0x80) ~= 0) then l = true; end ptr[k] = 0; end
    for _, k in ipairs(DIK_RIGHT_KEYS) do if (bit.band(ptr[k], 0x80) ~= 0) then r = true; end ptr[k] = 0; end
    local esc = bit.band(ptr[DIK_ESCAPE], 0x80) ~= 0;
    ptr[DIK_ESCAPE] = 0;
    local enter = false;
    if (pending ~= nil) then
        for _, k in ipairs(DIK_ENTER_KEYS) do if (bit.band(ptr[k], 0x80) ~= 0) then enter = true; end ptr[k] = 0; end
    end
    if (esc and not input.esc) then give_up(); end
    if (enter and not input.enter) then reel_in(); end
    input.left, input.right, input.esc, input.enter = l, r, esc, enter;
end);

-- Buffered DirectInput keys: swallow the steering keys and ESC during a round too.
ashita.events.register('key_data', 'tfish_key_data', function (e)
    if (not round_active() and pending == nil) then return; end
    if (STEER_DIK[e.key] or e.key == DIK_ESCAPE) then e.blocked = true; end
    if (pending ~= nil and (e.key == 0x1C or e.key == 0x9C)) then e.blocked = true; end
end);

-- Window keyboard messages: same keys (backup for ESC, and keeps chat/menus from seeing them).
ashita.events.register('key', 'tfish_key', function (e)
    if (not round_active() and pending == nil) then return; end
    if (VK_LEFT_KEYS[e.wparam] or VK_RIGHT_KEYS[e.wparam]) then
        e.blocked = true;
    elseif (e.wparam == VK_ESCAPE) then
        e.blocked = true;
        if (bit.band(e.lparam, 0x80000000) == 0) then give_up(); end
    elseif (e.wparam == VK_RETURN and pending ~= nil) then
        e.blocked = true;
        if (bit.band(e.lparam, 0x80000000) == 0) then reel_in(); end
    end
end);

-- Rod pose pulls AGAINST the fish: fish on the right half -> rod held left, fish on the left -> rod
-- held right, the middle 10% of the bar (0.45-0.55) is the neutral pose. A small dead band
-- (enter a side past 5%, come back to neutral inside 4%) stops it flickering on the edge.
-- Sent only when it changes, at most ~4 times a second.
local function update_pose(now)
    if (game == nil or game.practice or game.done ~= nil) then return; end
    local off = game.fish_x - 0.5;
    local pose = pose_sent;
    -- NOTE: in game, server pose "left" (para 7, animation 52) shows the rod held to the RIGHT
    -- and para 8 (53) shows it held LEFT, so the paras are swapped here (owner, 2026-11-07).
    if (off > 0.05) then
        pose = POSE_RIGHT;   -- fish on the right -> rod held left
    elseif (off < -0.05) then
        pose = POSE_LEFT;    -- fish on the left -> rod held right
    elseif (math.abs(off) < 0.04) then
        pose = POSE_CENTER;
    end
    if (pose ~= pose_sent and now - pose_sent_at >= 0.25) then
        send_fishing(5, pose, 0);
        pose_sent, pose_sent_at = pose, now;
    end
end

-- Drawing errors are reported once and never stop the round (the server still gets its result).
local draw_err_shown = false;
local function safe_draw(fn, ...)
    local ok, err = pcall(fn, ...);
    if (not ok and not draw_err_shown) then
        draw_err_shown = true;
        print(chat.header(addon.name):append(chat.message('Drawing error (the catch still works): ' .. tostring(err))));
    end
end

ashita.events.register('d3d_present', 'tfish_present', function ()
    UF.capture_default(imgui);
    local now = os.clock();
    local dt = math.min(0.05, math.max(0, now - last_clock));
    last_clock = now;


    if (hello_at ~= nil and now >= hello_at) then
        hello_at = nil;
        send_hello();
    end
    if (release_at ~= nil and now >= release_at) then
        release_at = nil;
        if (not released) then send_fishing(4, 0, 0); end
    end

    if (pending ~= nil) then
        local left = pending.time_limit - (now - pending.start);
        if (left <= 10 and not pending.warned) then
            pending.warned = true;
            send_fishing(5, 5, 0);   -- "You don't know how much longer you can keep this one on the line..."
        end
        if (left <= 0) then
            send_fishing(3, 300, pending.special);   -- waited too long: "You lost your catch."
            pending = nil;
            released = false;
            release_at = now + 3.0;
        else
            safe_draw(draw_pending, pending, now, left);
        end
    end

    if (game == nil) then return; end
    -- fixed small sub-steps keep the physics the same at any frame rate
    local n = math.max(1, math.ceil(dt / 0.01));
    local dir = (input.right and 1 or 0) - (input.left and 1 or 0);
    for _ = 1, n do step(game, dt / n, dir); end
    update_pose(now);
    safe_draw(draw, game);
    if (game.done ~= nil and game.t - game.done_t > 1.5) then
        game = nil;
        input.left, input.right = false, false;
        pose_sent = POSE_CENTER;
    end
end);

ashita.events.register('command', 'tfish_command', function (e)
    local args = e.command:args();
    if (#args == 0 or (args[1] ~= '/tfish' and args[1] ~= '/timelessfishing')) then return; end
    e.blocked = true;

    if (args[2] == 'debug') then
        debug = not debug;
        print(chat.header(addon.name):append(chat.message('Debug: ' .. (debug and 'on' or 'off'))));
        return;
    end
    if (args[2] == 'practice') then
        local d = tonumber(args[3] or '40') or 40;
        local b = 0;
        for k, v in pairs(BEHAVIORS) do if (v == args[4]) then b = k; end end
        -- the same formulas as the server, for a fish at your skill with this difficulty
        local fill  = 0.20 - 0.0012 * d;
        local drain = 0.06 + 0.0016 * d;
        game = new_round({ practice = true, difficulty = d, behavior = b, bar = 0.28, fill = fill, drain = drain,
                           monster = (args[5] == 'monster' or args[4] == 'monster') });
        return;
    end
    if (args[2] == 'pos' and args[4] ~= nil) then
        cfg.x, cfg.y = tonumber(args[3]) or -1, tonumber(args[4]) or -1;
        settings.save();
        return;
    end
    if (args[2] == 'font') then
        if (args[3] == 'on' or args[3] == 'off') then cfg.font = (args[3] == 'on'); else cfg.font = not (cfg.font ~= false); end
        settings.save();
        print(chat.header(addon.name):append(chat.message('Website fonts: ' .. ((cfg.font ~= false) and 'on' or 'off') ..
            ((cfg.font ~= false and not UF.loaded) and (' (not loaded: ' .. tostring(UF.error) .. ')') or ''))));
        return;
    end
    if (args[2] == 'textfont') then
        local v = (args[3] or ''):lower();
        local m = (v ~= '' and UF.set_text(v)) and ('Text font: ' .. UF.text_label()) or ('Text font is ' .. UF.text_label() .. '. Choose: /tfish textfont ' .. table.concat(UF.TEXT_ORDER, ' | '));
        print(chat.header(addon.name):append(chat.message(m)));
        return;
    end
    if (args[2] == 'titlefont') then
        local v = (args[3] or ''):lower();
        local m = (v ~= '' and UF.set_title(v)) and ('Title font: ' .. UF.title_label()) or ('Title font is ' .. UF.title_label() .. '. Choose: /tfish titlefont ' .. table.concat(UF.TITLE_ORDER, ' | '));
        print(chat.header(addon.name):append(chat.message(m)));
        return;
    end
    if (args[2] == 'scale' and args[3] ~= nil) then
        cfg.scale = math.max(0.5, math.min(3, tonumber(args[3]) or 1));
        settings.save();
        return;
    end
    print(chat.header(addon.name):append(chat.message('Steer with LEFT / RIGHT (A / D, arrows or numpad 4 / 6) to keep the fish in your zone; ESC gives up. /tfish practice [0-100] [mixed|smooth|sinker|floater|dart] [monster], /tfish pos <x> <y>, /tfish scale <n>, /tfish font [on|off].')));
end);
