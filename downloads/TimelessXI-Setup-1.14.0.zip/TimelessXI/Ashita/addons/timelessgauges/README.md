# Job Gauges (timelessgauges)

Your job's own meters on screen. A small bar shows the gauges of your main job: Faith, Beast Essence and Unleash, Ki, Hot Streak and the rest of the TimelessXI job perks. Full or ready gauges glow. Hover a gauge to see what it does. Drag the bar where you like.

Jobs without a gauge (Paladin, Puppetmaster) show nothing.

## What each job shows

| Job | Gauges |
|---|---|
| Warrior | Never Yield (cooldown), Champion's Challenge, Unyielding |
| Monk | Ki, Pressure Points on your target |
| White Mage | Faith (Miracle ready at 100) |
| Black Mage | Attunement (stacks and element), Last Ember |
| Red Mage | Exploit Weakness, Crimson Surge |
| Thief | From the Shadows, Thieves' Crew |
| Dark Knight | Chain Reaper |
| Beastmaster | Wild Bond, Blood Scent on your target |
| Bard | Encore |
| Ranger | Focus, Mark Prey, Camouflage ambush |
| Samurai | Hasso, Meditate's draw, Code of Bushido |
| Ninja | Shadow Step, Elemental Wheel (with the next element) |
| Dragoon | Bonded Pair |
| Summoner | Pact Bond with your avatar, Pact Weaving (cooldown) |
| Blue Mage | Beast Essence / Unleash, Spell Weaving, Azure Chain |
| Corsair | Hot Streak |

## Kinds of gauge

| Kind | Looks like |
|---|---|
| Meter | A bar that fills (Faith, Ki, Essence) |
| Stacks | Boxes that light up (Weave, Wild Bond, Hot Streak). A window that's running out shows its seconds |
| Timer | A bar that empties as something active runs out (Unleash, Blood Scent) |
| Cooldown | A bar that fills up to **Ready** (Never Yield, Pact Weaving) |
| On/off | Lit while it's active (Last Ember, Code of Bushido) |

## Commands

| Command | Does |
|---|---|
| `/gauges` | Show or hide the bar (`/gauge` also works) |
| `/gauges lock` / `/gauges unlock` | Lock it in place, or unlock it to drag |
| `/gauges width <n>` | Gauge width, 100 to 400 (170 by default) |
| `/gauges scale <n>` | Size, 0.7 to 2.0 |
| `/gauges opacity <n>` | Background, 0 to 1 |
| `/gauges labels` | Show or hide the labels |
| `/gauges job` | Show or hide the job name |
| `/gauges demo` | Sample gauges, to place the bar without a fight (again to go back) |
| `/gauges update` | Ask the server for everything again |

It's also a card in TimelessMenu (`/tm`), with Lock, Move and Demo buttons.

## How it gets its data

The addon asks the server with a packet, not chat ("ga on" in the companions addon packet). From then on the server looks at your gauges about once a second and sends only what changed. The lines are hidden from your chat log. Timers count down on your side, so a running timer isn't sent every second.

The addon says "still here" every 20 seconds and asks for everything again after zoning. When it's unloaded, or you log out, the server stops sending within a minute, so players without the addon never see these lines.

## Needs

The server's `gauges` module, and the companions module's addon packet (`companions_commands.lua` with `xi.addonActions`). Players without the addon can type `!gauges` to see their gauges in chat.

## Files

- `timelessgauges.lua`: events, commands, when to ask.
- `protocol.lua`: reads the `GA1|...` feed (no game code; tested on its own).
- `ui.lua`: draws the bar.
- `action.lua`: the request packet.
- `theme.lua`: the shared TimelessXI look.
- `tests/addon_test.lua`: offline checks (`luajit tests/addon_test.lua` from this folder).
