--[[
* timelessgauges - your job's own meters on screen: Faith, Beast Essence and Unleash, Ki, Hot
* Streak, Shadow Step, Attunement and the rest of the TimelessXI job perks.
*
* A small bar shows the gauges of your main job (jobs without any, like Paladin, show nothing).
* Full or ready gauges glow. Hover a gauge to see what it does. Drag the bar where you like.
*
* The server sends only what changes, about once a second, and only while this addon is loaded:
* it asks with a packet (not chat) and the lines are hidden from the chat log. Needs the server's
* gauges module.
*
* Commands:
*   /gauges               show or hide the bar
*   /gauges lock          lock or unlock its position
*   /gauges width <n>     gauge width (100-400)
*   /gauges scale <n>     text and size (0.7-2.0)
*   /gauges labels        show or hide the labels
*   /gauges job           show or hide the job name
*   /gauges opacity <n>   background (0-1)
*   /gauges demo          sample gauges, to place the bar without a fight
*   /gauges update        ask the server for everything again
--]]

addon.name    = 'timelessgauges';
addon.author  = 'TimelessXI';
addon.version = '1.0';
addon.desc    = 'Your job\'s own meters (Faith, Essence, Ki, ...) on screen.';
addon.link    = '';

require('common');
local chat     = require('chat');
local settings = require('settings');
local action   = require('action');
local protocol = require('protocol');
local ui       = require('ui');

local defaults = T{
    visible     = true,
    locked      = false,
    width       = 170,
    scale       = 1.0,
    opacity     = 0.85,
    show_labels = true,
    show_job    = true,
};

local ga = {
    settings  = settings.load(defaults),
    model     = protocol.new_model(),
    next_beat = 0,    -- os.clock() of the next "ga on"
    full_at   = nil,  -- os.clock() of a scheduled "ga on full"
    zone      = nil,
    demo      = nil,  -- the real model while showing the demo
};

ga.state = {
    settings = ga.settings,
};

-- Seconds between "still here" requests (the server stops after 60 s without one)
local BEAT = 20;

local function msg(text)
    print(chat.header(addon.name):append(chat.message(text)));
end

local function in_game()
    local party = AshitaCore:GetMemoryManager():GetParty();
    return party ~= nil and party:GetMemberServerId(0) ~= 0;
end

local function ask(full)
    if (not in_game()) then
        return;
    end
    action.send(full and 'ga on full' or 'ga on');
    ga.next_beat = os.clock() + BEAT;
end

local function ask_full_soon(seconds)
    local at = os.clock() + seconds;
    if (ga.full_at == nil or at < ga.full_at) then
        ga.full_at = at;
    end
end

settings.register('settings', 'settings_update', function(s)
    if (s ~= nil) then
        ga.settings = s;
        ga.state.settings = s;
    end
end);

ashita.events.register('load', 'load_cb', function()
    ask_full_soon(1.0);
end);

ashita.events.register('unload', 'unload_cb', function()
    -- Tell the server to stop now (it would anyway, a minute later)
    if (in_game()) then
        action.send('ga off');
    end
    settings.save();
end);

-- Read the feed and hide it from the chat log
ashita.events.register('text_in', 'text_in_cb', function(e)
    local line = protocol.extract(e.message_modified) or protocol.extract(e.message);
    if (line == nil) then
        return;
    end
    e.blocked = true;
    protocol.feed(ga.demo or ga.model, line, os.clock());
end);

-- Zoning in: the server's timers may have stopped; ask for everything again
ashita.events.register('packet_in', 'packet_in_cb', function(e)
    if (e.id == 0x00A) then
        ask_full_soon(3.0);
    end
end);

local function demo_model()
    local m = protocol.new_model();
    local now = os.clock();
    protocol.feed(m, 'GA1|J|16|n=3', now);
    protocol.feed(m, 'GA1|G|1|k=ess,l=Essence,t=bar,v=72,m=100,h=0,s=,c=purple,tot=1,left=0', now);
    protocol.feed(m, 'GA1|G|2|k=weave,l=Weave,t=pips,v=2,m=3,h=0,s=,c=teal,tot=30,left=24', now);
    protocol.feed(m, 'GA1|G|3|k=azure,l=Azure Chain,t=timer,v=0,m=1,h=1,s=Burst!,c=blue,tot=8,left=6', now);
    return m;
end

local function clamp(n, lo, hi)
    return math.max(lo, math.min(hi, n));
end

ashita.events.register('command', 'command_cb', function(e)
    local args = e.command:args();
    if (#args == 0 or not (args[1]:any('/gauges') or args[1]:any('/gauge') or args[1]:any('/timelessgauges'))) then
        return;
    end
    e.blocked = true;

    local s   = ga.settings;
    local sub = (args[2] or ''):lower();
    local n   = tonumber(args[3]);
    if (sub == '') then
        s.visible = not s.visible;
        msg(s.visible and 'Gauges shown.' or 'Gauges hidden (/gauges to show them).');
        if (s.visible) then
            ask(true);
        end
    elseif (sub == 'lock' or sub == 'unlock') then
        s.locked = (sub == 'lock');
        msg(s.locked and 'Gauge bar locked.' or 'Gauge bar unlocked: drag it where you like.');
    elseif (sub == 'width' and n ~= nil) then
        s.width = clamp(n, 100, 400);
    elseif (sub == 'scale' and n ~= nil) then
        s.scale = clamp(n, 0.7, 2.0);
    elseif (sub == 'opacity' and n ~= nil) then
        s.opacity = clamp(n, 0, 1);
    elseif (sub == 'labels') then
        s.show_labels = not s.show_labels;
    elseif (sub == 'job') then
        s.show_job = not s.show_job;
    elseif (sub == 'demo') then
        if (ga.demo == nil) then
            ga.demo = ga.model;
            ga.model = demo_model();
            ga.state.demo = true;
            msg('Demo gauges shown. /gauges demo again to go back.');
        else
            ga.model = ga.demo;
            ga.demo = nil;
            ga.state.demo = false;
        end
    elseif (sub == 'update' or sub == 'refresh') then
        ask(true);
    else
        msg('/gauges | lock | width <n> | scale <n> | opacity <n> | labels | job | demo | update');
        return;
    end
    settings.save();
end);

ashita.events.register('d3d_present', 'present_cb', function()
    if (not in_game()) then
        return;
    end

    local now = os.clock();

    -- Zoning (also seen here, in case the packet was missed)
    local party = AshitaCore:GetMemoryManager():GetParty();
    local zone = party and party:GetMemberZone(0) or 0;
    if (ga.zone ~= nil and zone ~= 0 and zone ~= ga.zone) then
        ask_full_soon(3.0);
    end
    if (zone ~= 0) then
        ga.zone = zone;
    end

    if (ga.full_at ~= nil and now >= ga.full_at) then
        ga.full_at = nil;
        ask(true);
    elseif (now >= ga.next_beat) then
        ask(false);
    end

    if (not ga.settings.visible) then
        return;
    end

    ga.state.now = now;
    -- The demo model's timers keep running: refresh it when they run out
    if (ga.state.demo and now - ga.model.received > 30) then
        ga.model = demo_model();
    end
    ui.render(ga.model, ga.state);
end);
