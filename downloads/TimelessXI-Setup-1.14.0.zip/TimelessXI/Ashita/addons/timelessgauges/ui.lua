--[[
* timelessgauges - ui.lua
*
* Draws the gauge bar: a small window with your main job's name and one row per gauge.
*   bar    a meter that fills (Faith, Ki, Beast Essence)
*   pips   stacks (Spell Weaving, Wild Bond, Hot Streak); a window running out shows its seconds
*   timer  something active that runs out (Unleash, Blood Scent)
*   cd     a cooldown that fills up to Ready (Never Yield, Pact Weaving)
*   flag   on or off (Last Ember, Code of Bushido)
* A gauge that is full or ready glows.
--]]

local imgui    = require('imgui');
local theme    = require('theme');
local protocol = require('protocol');

local ui = {};

ui.ROW_H   = 15;  -- gauge height
ui.LABEL_W = 108; -- room for labels
ui.PIP_GAP = 3;

-- Colour names the server uses
ui.COLORS = {
    gold   = { 0.97, 0.80, 0.38, 1.0 },
    purple = { 0.72, 0.48, 0.98, 1.0 },
    teal   = { 0.32, 0.86, 0.80, 1.0 },
    blue   = { 0.42, 0.66, 1.00, 1.0 },
    green  = { 0.48, 0.88, 0.48, 1.0 },
    orange = { 1.00, 0.62, 0.28, 1.0 },
    red    = { 0.96, 0.38, 0.38, 1.0 },
    white  = { 0.92, 0.94, 0.98, 1.0 },
    elem1  = { 1.00, 0.42, 0.25, 1.0 }, -- Fire
    elem2  = { 0.55, 0.85, 1.00, 1.0 }, -- Ice
    elem3  = { 0.45, 0.92, 0.55, 1.0 }, -- Wind
    elem4  = { 0.85, 0.68, 0.38, 1.0 }, -- Earth
    elem5  = { 0.80, 0.55, 1.00, 1.0 }, -- Thunder
    elem6  = { 0.35, 0.55, 1.00, 1.0 }, -- Water
    elem7  = { 1.00, 0.98, 0.80, 1.0 }, -- Light
    elem8  = { 0.55, 0.40, 0.70, 1.0 }, -- Dark
};

local BACK   = { 0.10, 0.11, 0.15, 0.95 };
local EDGE   = { 0.30, 0.32, 0.41, 0.70 };
local EMPTY  = { 0.17, 0.18, 0.24, 1.00 };
local TEXT   = { 0.97, 0.97, 1.00, 1.00 };
local SHADOW = { 0.00, 0.00, 0.00, 0.85 };

-- What each gauge does, for its tooltip: [job id .. ':' .. key]
ui.TIPS = {
    ['3:faith']    = 'Faith builds as you heal and cleanse others. At 100 your next Cure, Raise or Banish is a Miracle.',
    ['16:ess']     = 'Beast Essence builds from blue magic, hits and weapon skills. At 100 the beast is Unleashed for 30 seconds.',
    ['16:weave']   = 'Alternate physical and magical blue magic: +5% a stack, up to 3.',
    ['16:azure']   = 'A physical spell under Chain Affinity opened a window: your next magical blue spell bursts.',
    ['4:attune']   = 'Nuking the same element stacks Attunement (+5% a stack). A different element starts over.',
    ['4:ember']    = 'Below a quarter of your MP: nukes +15% and black magic costs half.',
    ['10:encore']  = 'Every few songs in a fight, the next one is an Encore: cast twice as fast and one Crescendo stack higher.',
    ['9:bond']     = 'Wild Bond: grows with every worthy kill your pet makes with you.',
    ['9:scent']    = 'Blood Scent on your target: you and your pet deal more damage to it.',
    ['17:streak']  = 'Hot Streak: lucky rolls in a row. Three in two minutes and Fortune smiles on you.',
    ['14:bond']    = 'Bonded Pair: you and your wyvern grow stronger the longer you fight together.',
    ['2:ki']       = 'Ki builds from hits, kicks and counters. Chakra and Chi Blast spend it; full Ki makes your next weapon skill hit harder.',
    ['2:pp']       = 'Pressure Points on your target: when it fills, your next weapon skill strikes it.',
    ['13:step']    = 'Shadow Step: Innin from behind builds it. At 5 your next weapon skill strikes unseen.',
    ['13:wheel']   = 'Cast elemental ninjutsu around the wheel (Fire, Ice, Wind, Earth, Thunder, Water). The sixth in a row completes it.',
    ['5:exploit']  = 'Exploit Weakness: every enfeeble on your target adds to your damage, up to +15%.',
    ['5:surge']    = 'Crimson Surge: spells left that are free and fast after Convert.',
    ['11:focus']   = 'Focus: sweet-spot shots build it. At 5 your next shot is a sure critical hit.',
    ['11:prey']    = 'Mark Prey: your damage to your prey grows the longer you hunt it.',
    ['11:ambush']  = 'Camouflage ambush: your next shot deals +50% and adds no enmity.',
    ['12:hasso']   = 'Hasso: your attack grows every round you stay in it.',
    ['12:draw']    = 'Meditate\'s draw: your next weapon skill is an Iaijutsu.',
    ['12:bushido'] = 'Code of Bushido: fighting one on one gives accuracy and critical hit rate.',
    ['15:bond']    = 'Pact Bond with your avatar: grows with every worthy kill it shares with you.',
    ['15:weave']   = 'Pact Weaving: release your avatar soon after its Blood Pact for a lingering spirit.',
    ['6:shadows']  = 'From the Shadows: Hide readied a free Sneak Attack, and your first round adds no enmity.',
    ['6:crew']     = 'Honor Amongst Thieves: more Thieves in the alliance mean more gil and Treasure Hunter.',
    ['1:never']    = 'Never Yield: once every 5 minutes a killing blow leaves you at 1 HP.',
    ['1:duel']     = 'Champion\'s Challenge: you called out a notorious monster.',
    ['1:unyield']  = 'Unyielding: at 25% HP or less, Double Attack and attack go up.',
    ['8:chain']    = 'Chain Reaper: worthy kills in quick succession stack attack.',
};

local function u32(c)
    return imgui.GetColorU32(c);
end

local function mix(a, b, t)
    return { a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t, a[3] + (b[3] - a[3]) * t, a[4] + (b[4] - a[4]) * t };
end

local function dim(c, f)
    return { c[1] * f, c[2] * f, c[3] * f, c[4] };
end

-- A slow pulse (0..1) for things that are ready
local function pulse(now)
    return 0.5 + 0.5 * math.sin((now or 0) * 5.0);
end

local function rounded()
    return rawget(_G, 'ImDrawFlags_RoundCornersAll') or rawget(_G, 'ImDrawCornerFlags_All') or 0;
end

local function centered_text(draw, x, y, w, h, text)
    if (text == nil or text == '') then
        return;
    end
    local tw, th = imgui.CalcTextSize(text);
    th = th or 13;
    local tx = x + math.max(2, (w - (tw or 0)) / 2);
    local ty = y + (h - th) / 2;
    draw:AddText({ tx + 1, ty + 1 }, u32(SHADOW), text);
    draw:AddText({ tx, ty }, u32(TEXT), text);
end

-- One gauge at the cursor, w wide
function ui.draw_gauge(g, now, w, id)
    local h = ui.ROW_H;
    local x, y = imgui.GetCursorScreenPos();
    imgui.InvisibleButton('##gauge' .. id, { w, h });
    local hovered = imgui.IsItemHovered();

    local draw  = imgui.GetWindowDrawList();
    local color = ui.COLORS[g.c or ''] or ui.COLORS.gold;
    local ready = protocol.ready(g, now);
    local glow  = ready and pulse(now) or 0;
    local edge  = ready and mix(EDGE, color, 0.45 + 0.55 * glow) or EDGE;
    local text  = protocol.text(g, now);

    if (g.t == 'pips') then
        local m   = math.max(1, g.m or 1);
        local gap = ui.PIP_GAP;
        local pw  = (w - gap * (m - 1)) / m;
        local v   = g.v or 0;
        for i = 1, m do
            local px = x + (i - 1) * (pw + gap);
            local fill = i <= v and (ready and mix(color, TEXT, 0.25 * glow) or color) or EMPTY;
            draw:AddRectFilled({ px, y }, { px + pw, y + h }, u32(fill), 3.0, rounded());
            draw:AddRect({ px, y }, { px + pw, y + h }, u32(edge), 3.0, rounded(), ready and 1.5 or 1.0);
        end
        centered_text(draw, x, y, w, h, text);
    else
        local frac = protocol.fill(g, now);
        draw:AddRectFilled({ x, y }, { x + w, y + h }, u32(BACK), 3.0, rounded());
        if (frac > 0) then
            local fill = ready and mix(color, TEXT, 0.25 * glow) or ((g.t == 'cd') and dim(color, 0.6) or color);
            draw:AddRectFilled({ x, y }, { x + math.max(3, w * frac), y + h }, u32(fill), 3.0, rounded());
        end
        draw:AddRect({ x, y }, { x + w, y + h }, u32(edge), 3.0, rounded(), ready and 1.5 or 1.0);
        centered_text(draw, x, y, w, h, text);
    end

    return hovered;
end

--[[
* Draws the window. Returns false when the player closed it (not used: it has no close button).
--]]
function ui.render(model, state)
    local s = state.settings;
    local gauges = protocol.list(model);
    if (#gauges == 0) then
        return true;
    end

    local now   = state.now or 0;
    local flags = (rawget(_G, 'ImGuiWindowFlags_NoTitleBar') or 0)
        + (rawget(_G, 'ImGuiWindowFlags_AlwaysAutoResize') or 0)
        + (rawget(_G, 'ImGuiWindowFlags_NoScrollbar') or 0)
        + (rawget(_G, 'ImGuiWindowFlags_NoCollapse') or 0)
        + (rawget(_G, 'ImGuiWindowFlags_NoFocusOnAppearing') or 0)
        + (rawget(_G, 'ImGuiWindowFlags_NoNav') or 0);
    if (s.locked) then
        flags = flags + (rawget(_G, 'ImGuiWindowFlags_NoMove') or 0);
    end

    -- imgui remembers where it was dragged; this is only the first spot
    imgui.SetNextWindowPos({ 400, 600 }, rawget(_G, 'ImGuiCond_FirstUseEver'));
    imgui.SetNextWindowBgAlpha(s.opacity or 0.85);

    local shown = theme.begin_window('Job Gauges##timelessgauges', nil, nil, flags);
    if (shown) then
        pcall(function() imgui.SetWindowFontScale(s.scale or 1.0); end);

        if (s.show_job) then
            imgui.TextColored(theme.COLOR.gold, protocol.job_name(model));
            if (state.demo) then
                imgui.SameLine();
                imgui.TextColored(theme.COLOR.faint, '(demo)');
            end
        end

        for i, g in ipairs(gauges) do
            if (s.show_labels) then
                imgui.TextColored(theme.COLOR.dim, g.l or '');
                imgui.SameLine(ui.LABEL_W * (s.scale or 1.0));
            end
            local hovered = ui.draw_gauge(g, now, (s.width or 170) * (s.scale or 1.0), i);
            if (hovered) then
                local tip = ui.TIPS[tostring(model.job) .. ':' .. (g.k or '')];
                theme.tip((g.l or '') .. (tip and ('\n' .. tip) or ''));
            end
        end

    end
    theme.end_window();
    return true;
end

return ui;
