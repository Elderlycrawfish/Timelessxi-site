# TimelessMenu (timelessmenu)

One menu for every TimelessXI addon. Open it with the small **Timeless** button on screen, or `/tm`.
(It used to be called phoenixmenu; the old `/px` still works.)

## What's in it

| Addon | Opens with | Tab buttons |
|---|---|---|
| Companion Manager | `/cm` | Party, Call, Kept, Presets, Settings |
| Companion View | `/cv` | (one window) |
| Journal | `/ql` | Missions, Quests, Retail, Tracker |
| Job Gauges | `/gauges` | Lock, Move, Demo |
| Craftbook | `/craft` | Status, Mog House, Champions, Garden |

Each entry says what the addon does and has an **Open / close** button plus a button for each tab. Hover any button to see what it does and the command it runs.

**Server row:** buttons for the status commands people use most (`!welcome`, `!companion status`, `!guild`, `!expedition`, `!dig`, `!chocobo`, `!journal`). Their answers appear in chat.

**Loading:** an addon that isn't loaded yet is loaded the first time you open it from the menu, so you don't have to turn it on in the launcher first. If it was already loaded, Ashita may print a one-line "already loaded" note; that's harmless.

## Commands

| Command | Does |
|---|---|
| `/tm` | Show or hide the menu (`/timelessmenu` and `/px` also work) |
| `/tm button` | Show or hide the small on-screen button |
| `/tm cm`, `/tm cv`, `/tm ql`, `/tm gauges`, `/tm craft` | Open one addon directly |

The on-screen button can be dragged anywhere, and its position is remembered. The checkbox at the bottom of the menu also hides it.

## Adding an addon

Add an entry to `ADDONS` at the top of `timelessmenu.lua`:

```lua
{
    name  = 'myaddon',          -- the folder name (what /addon load takes)
    title = 'My Addon',
    cmd   = '/my',              -- shows or hides its window
    desc  = 'What it does.',
    tabs  = { { 'Tab', '/my tab', 'Tooltip.' } },
},
```

## Loading it

Turn it on in the launcher (Plugins & Addons), or type `/addon load timelessmenu`.
