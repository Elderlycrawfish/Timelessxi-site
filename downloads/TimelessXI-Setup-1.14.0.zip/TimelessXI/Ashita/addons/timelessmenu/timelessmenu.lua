--[[
* timelessmenu - TimelessMenu: one menu for every TimelessXI addon.
*
* A window listing the server's own addons (Companion Manager, Companion View, Journal, Craftbook) with what
* each does, a button to open it and buttons for its tabs. An addon that isn't loaded yet is loaded
* first, so nothing has to be turned on in the launcher beforehand. A row of server buttons shows the
* most-used status commands (!welcome, !guild, !expedition, ...).
*
* A small "Timeless" button stays on screen (drag it anywhere) and opens the menu. Hide it with the
* checkbox at the bottom of the menu, or /tm button.
*
* Commands:
*   /tm                  show or hide the menu (/timelessmenu and the old /px also work)
*   /tm button           show or hide the small on-screen button
*   /tm <addon>          open an addon by name or command: cm, cv, ql, craft
*
* To add an addon later, add an entry to ADDONS below.
--]]

addon.name    = 'timelessmenu';
addon.author  = 'TimelessXI';
addon.version = '1.2';
addon.desc    = 'TimelessMenu: one menu for every TimelessXI addon. Open them and jump to their tabs.';
addon.link    = '';

require('common');
local chat     = require('chat');
local imgui    = require('imgui');
local settings = require('settings');
local theme    = require('theme');

-----------------------------------
-- The addons, in the order the menu shows them
--   name   the addon's folder (what /addon load takes)
--   cmd    the command that shows or hides its window
--   tabs   buttons that open it on a tab: { label, command, tooltip }
-----------------------------------
local ADDONS = {
    {
        name  = 'companionmanager',
        title = 'Companion Manager',
        cmd   = '/cm',
        desc  = 'Call, keep, save and manage your companions: who\'s with you, every job\'s cooldown, kept companions and their bond, presets and settings.',
        tabs  = {
            { 'Party',    '/cm party',    'Who\'s with you: keep, two-hour, dismiss, raise.' },
            { 'Call',     '/cm call',     'Every job, ready or cooling down. Click one to call it.' },
            { 'Kept',     '/cm kept',     'Your kept companions, their bond and where they are.' },
            { 'Presets',  '/cm presets',  'Load, save and build party line-ups.' },
            { 'Settings', '/cm settings', 'Weapon skill mode, engage, Treasure Hunter, roles and sub jobs.' },
        },
    },
    {
        name  = 'companionview',
        title = 'Companion View',
        cmd   = '/cv',
        desc  = 'Your companions\' equipment, job, combat stats and HP/MP/TP, with the Treasure Hunter and role switches.',
        tabs  = {},
    },
    {
        name  = 'questlog',
        title = 'Journal',
        cmd   = '/ql',
        desc  = 'Your missions and quests: where to go and what to do next for your nation, Zilart, Promathia and Aht Urhgan, plus the server\'s custom quests. Spoiler-free unless you ask, with an optional on-screen tracker.',
        tabs  = {
            { 'Missions', '/ql missions', 'Every storyline\'s current mission and next step.' },
            { 'Quests',   '/ql quests',   'Custom quests in progress and ones you can start.' },
            { 'Retail',   '/ql retail',   'Retail quests you have accepted.' },
            { 'Tracker',  '/ql tracker',  'Show or hide the small on-screen tracker.' },
        },
    },
    {
        name  = 'timelessgauges',
        title = 'Job Gauges',
        cmd   = '/gauges',
        desc  = 'Your job\'s own meters on screen: Faith, Beast Essence and Unleash, Ki, Hot Streak, Shadow Step, Attunement and the rest. Full or ready gauges glow; hover one to see what it does. Drag the bar where you like.',
        tabs  = {
            { 'Lock',  '/gauges lock',   'Lock the bar where it is.' },
            { 'Move',  '/gauges unlock', 'Unlock the bar so you can drag it.' },
            { 'Demo',  '/gauges demo',   'Sample gauges, to place the bar without a fight.' },
        },
    },
    {
        name  = 'craftbook',
        title = 'Craftbook',
        cmd   = '/craft',
        desc  = 'Every recipe, coloured for your skills, with ingredients and auction house prices. Also your crafts, Mog House hearth, Champions record and garden.',
        tabs  = {
            { 'Status',    '/craft status',    'Your crafts, rested synths, lessons, craft orders and mastery.' },
            { 'Mog House', '/craft mog',       'Your furniture\'s hearth bonuses and the pieces worth making.' },
            { 'Champions', '/craft champions', 'Your Champion record, the Bestiary and the trophy exchange.' },
            { 'Garden',    '/craft garden',    'Your gardening level, crossbreeds, crystals and flowerpots.' },
        },
    },
};

-- Server status commands for the bottom row: { label, chat command, tooltip }
local SERVER = {
    { 'Welcome',    '!welcome',          'What happened while you were away.' },
    { 'Companions', '!companion status', 'Job cooldowns and any downed companions.' },
    { 'Guild',      '!guild',            'Guild standing, commissions and open requests.' },
    { 'Expedition', '!expedition',       'The current expedition, its chance and your Everglass.' },
    { 'Digging',    '!dig',              'Your digging level, finds left today and conditions.' },
    { 'Chocobo',    '!chocobo',          'Your chocobo\'s stage, stats and care plan.' },
    { 'Journal',    '!journal',          'Your custom quests.' },
};

local COLOR = theme.colors();

local LOAD_WAIT = 1.0; -- seconds between loading an addon and opening it

local defaults = T{
    show_button = true,
};

local menu = {
    settings = settings.load(defaults),
    visible  = { false },
    loaded   = {},  -- addons this menu has loaded (or seen opened) this session
    pending  = {},  -- commands waiting for an addon to finish loading: { at, command }
};

local function msg(text)
    print(chat.header(addon.name):append(chat.message(text)));
end

local function in_game()
    local party = AshitaCore:GetMemoryManager():GetParty();
    return party ~= nil and party:GetMemberServerId(0) ~= 0;
end

local function run(command)
    AshitaCore:GetChatManager():QueueCommand(1, command);
end

-- Runs one of an addon's commands, loading the addon first if this menu hasn't yet. Loading an addon
-- that's already loaded (by the launcher, say) only makes Ashita say so; the command still works.
local function open(entry, command)
    command = command or entry.cmd;
    if (menu.loaded[entry.name]) then
        run(command);
        return;
    end

    menu.loaded[entry.name] = true;
    run('/addon load ' .. entry.name);
    table.insert(menu.pending, { at = os.clock() + LOAD_WAIT, command = command });
end

local function find(word)
    word = (word or ''):lower():gsub('^/', '');
    for _, entry in ipairs(ADDONS) do
        if (entry.name == word or entry.cmd:sub(2) == word or entry.title:lower():gsub(' ', '') == word) then
            return entry;
        end
    end
    return nil;
end

local function tooltip(text)
    if (text ~= nil and imgui.IsItemHovered()) then
        if (imgui.BeginTooltip() ~= false) then
            imgui.TextUnformatted(tostring(text));
            imgui.EndTooltip();
        end
    end
end

-----------------------------------
-- Drawing
-----------------------------------
local CARD_WIDTH = 520;

-- One card per addon: its name and command, what it does, then Open and its tabs
local function draw_addon(entry)
    theme.card('##card_' .. entry.name, function()
        imgui.TextColored(COLOR.gold, entry.title);
        imgui.SameLine();
        imgui.TextColored(COLOR.faint, entry.cmd);

        imgui.PushTextWrapPos(CARD_WIDTH - 24);
        imgui.TextColored(COLOR.dim, entry.desc);
        imgui.PopTextWrapPos();
        imgui.Spacing();

        if (theme.button('Open##' .. entry.name, 'primary', true, ('Shows or hides %s (%s).'):fmt(entry.title, entry.cmd))) then
            open(entry);
        end

        for _, tab in ipairs(entry.tabs) do
            imgui.SameLine();
            if (theme.button(tab[1] .. '##' .. entry.name, nil, true, tab[3] .. '\n' .. tab[2])) then
                open(entry, tab[2]);
            end
        end
    end, CARD_WIDTH);
    imgui.Spacing();
end

local function draw_menu()
    imgui.SetNextWindowPos({ 120, 160 }, ImGuiCond_FirstUseEver);
    local shown = theme.begin_window('TimelessMenu', menu.visible, { CARD_WIDTH + 28, 0 },
        bit.bor(ImGuiWindowFlags_NoCollapse, ImGuiWindowFlags_AlwaysAutoResize));
    if (shown) then
        theme.section('Addons', 'open a window, or jump straight to a tab');
        for _, entry in ipairs(ADDONS) do
            draw_addon(entry);
        end

        theme.section('Server', 'answers appear in chat');
        for i, cmd in ipairs(SERVER) do
            if ((i - 1) % 4 ~= 0) then
                imgui.SameLine();
            end
            if (theme.button(cmd[1] .. '##server', nil, true, cmd[3] .. '\n' .. cmd[2])) then
                run('/say ' .. cmd[2]);
            end
        end

        imgui.Spacing();
        imgui.Separator();
        local show = { menu.settings.show_button };
        if (imgui.Checkbox('Show the Timeless button on screen', show)) then
            menu.settings.show_button = show[1];
            settings.save();
        end
        theme.tip('A small button that opens this menu. Drag it anywhere. /tm button also toggles it.');
    end
    theme.end_window();
end

local function draw_button()
    imgui.SetNextWindowPos({ 20, 220 }, ImGuiCond_FirstUseEver);
    local pushed = theme.push();
    imgui.PushStyleVar(ImGuiStyleVar_WindowPadding, { 5, 5 });
    imgui.PushStyleVar(ImGuiStyleVar_FramePadding, { 12, 6 });
    imgui.PushStyleColor(ImGuiCol_WindowBg, { 0.075, 0.082, 0.110, 0.75 });
    imgui.PushStyleColor(ImGuiCol_Button, { 0.330, 0.270, 0.140, 0.95 });
    imgui.PushStyleColor(ImGuiCol_ButtonHovered, { 0.470, 0.380, 0.180, 1.0 });
    imgui.PushStyleColor(ImGuiCol_Text, { 1.0, 0.94, 0.78, 1.0 });

    local flags = bit.bor(ImGuiWindowFlags_NoTitleBar, ImGuiWindowFlags_NoResize, ImGuiWindowFlags_NoScrollbar,
        ImGuiWindowFlags_AlwaysAutoResize, ImGuiWindowFlags_NoFocusOnAppearing);
    if (imgui.Begin('##timelessmenu_button', { true }, flags)) then
        if (imgui.Button(menu.visible[1] and 'Timeless  -' or 'Timeless  +')) then
            menu.visible[1] = not menu.visible[1];
        end
        theme.tip('TimelessMenu: addons and server status (/tm). Drag the dark edge around it to move it.');
    end
    imgui.End();

    imgui.PopStyleColor(4);
    imgui.PopStyleVar(2);
    theme.pop(pushed);
end

-----------------------------------
-- Events
-----------------------------------
settings.register('settings', 'settings_update', function(s)
    if (s ~= nil) then
        menu.settings = s;
    end
end);

ashita.events.register('unload', 'unload_cb', function()
    settings.save();
end);

ashita.events.register('command', 'command_cb', function(e)
    local args = e.command:args();
    if (#args == 0 or not (args[1]:any('/tm') or args[1]:any('/timelessmenu') or args[1]:any('/px'))) then
        return;
    end
    e.blocked = true;

    local sub = (args[2] or ''):lower();
    if (sub == '') then
        menu.visible[1] = not menu.visible[1];
    elseif (sub == 'button') then
        menu.settings.show_button = not menu.settings.show_button;
        settings.save();
        msg(menu.settings.show_button and 'The Timeless button is on screen.' or 'The Timeless button is hidden. /tm opens the menu.');
    elseif (find(sub) ~= nil) then
        open(find(sub));
    else
        local names = {};
        for _, entry in ipairs(ADDONS) do
            table.insert(names, entry.cmd:sub(2));
        end
        msg('/tm | /tm button | /tm <addon>: ' .. table.concat(names, ', '));
    end
end);

ashita.events.register('d3d_present', 'present_cb', function()
    -- Commands waiting for an addon to finish loading
    if (#menu.pending > 0) then
        local now = os.clock();
        for i = #menu.pending, 1, -1 do
            if (now >= menu.pending[i].at) then
                local item = table.remove(menu.pending, i);
                run(item.command);
            end
        end
    end

    if (not in_game()) then
        return;
    end

    if (menu.settings.show_button) then
        draw_button();
    end

    if (menu.visible[1]) then
        draw_menu();
    end
end);
